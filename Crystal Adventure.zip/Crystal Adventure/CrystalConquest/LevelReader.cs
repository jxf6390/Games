﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CrystalConquest
{
    class LevelReader
    {
        public string[,] result;
        private string[][] textOfLevel;
        public string[,] startLevel;

        public void levelArray(int levelNum)
        {
            textOfLevel = File.ReadLines("../../../../../lvltxt.rtf").Select(textOfLevel => textOfLevel.Split('\n')).ToArray();
            int tNum = -1; //used to find which level to get the data for

            if (levelNum == 2) //T2
            {
                tNum = 1;
            }
            else if (levelNum == 6) // T1
            {
                tNum = 6;
            }
            else if (levelNum == 10) // Center
            {
                tNum = 12;
            }
            else if (levelNum == 14) // B1
            {
                tNum = 18;
            }
            else if (levelNum == 18) // B2
            {
                tNum = 24;
            }
            else if (levelNum == 4) // L2
            {
                tNum = 30;
            }
            else if (levelNum == 7) // L1
            {
                tNum = 36;
            }
            else if (levelNum == 13) // R1
            {
                tNum = 42;
            }
            else if (levelNum == 16) // R2
            {
                tNum = 48;
            }

            result = new string[8, 6];
            string s;
            for (int i = 0; i < 6; i++)
            {
                s = textOfLevel[i + tNum][0];
                result[0, i] = s.Substring(0, 1);
                result[1, i] = s.Substring(1, 1);
                result[2, i] = s.Substring(2, 1);
                result[3, i] = s.Substring(3, 1);
                result[4, i] = s.Substring(4, 1);
                result[5, i] = s.Substring(5, 1);
                result[6, i] = s.Substring(6, 1);
                result[7, i] = s.Substring(7, 1);
            }
        }

        //finds the level that you started out at
        public int levelStartFinder()
        {
            textOfLevel = File.ReadLines("../../../../../lvltxt.rtf").Select(textOfLevel => textOfLevel.Split('\n')).ToArray();
            string s = "";
            startLevel = new string[8, 54];
            for (int i = 0; i < 54; i++)
            {
                s = textOfLevel[i][0];
                startLevel[0, i] = s.Substring(0, 1);
                startLevel[1, i] = s.Substring(1, 1);
                startLevel[2, i] = s.Substring(2, 1);
                startLevel[3, i] = s.Substring(3, 1);
                startLevel[4, i] = s.Substring(4, 1);
                startLevel[5, i] = s.Substring(5, 1);
                startLevel[6, i] = s.Substring(6, 1);
                startLevel[7, i] = s.Substring(7, 1);
            }

            for (int i = 0; i < 8; i++) //rows
            {
                for (int h = 0; h < 54; h++) //cols
                {
                    if (startLevel[i, h] == "H")
                    {
                        if (h <= 6)
                        {
                            return 2;
                        }
                        else if (h <= 12)
                        {
                            return 6;
                        }
                        else if (h <= 18)
                        {
                            return 10;
                        }
                        else if (h <= 24)
                        {
                            return 14;
                        }
                        else if (h <= 30)
                        {
                            return 18;
                        }
                        else if (h <= 36)
                        {
                            return 4;
                        }
                        else if (h <= 42)
                        {
                            return 7;
                        }
                        else if (h <= 48)
                        {
                            return 13;
                        }
                        else
                        {
                            return 16;
                        }
                    }
                }
            }
            return 0;
        }
    }
}
