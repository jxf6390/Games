﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Threading;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.IO;

namespace CrystalConquest
{

    /// <summary>
    /// This is the main type for your game.
    /// </summary>

    enum GameState {Menu, Game, Story, Instructions, Victory, GameOver};
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        GameState gameState;
        GameTime gameTime;
        SpriteFont arial16;
        bool firstRun;
        bool[] levelVisited;
        //menus
        Texture2D tex;
        Texture2D tex2;
        Texture2D instructions;
        Texture2D startMenu;
        Texture2D gameOverMenu;
        //window sizes
        int windowWidth = 960;
        int windowHeight = 720;

        //Player fields
        Player player;
        int chosenPlayerX;
        int chosenPlayerY;
        //Vector2 playerPosition;
        Vector2 playerVelocity;

        //keyboard fields
        KeyboardState currentKBState;
        KeyboardState prevKBState;

        //Level Editor field
        LevelReader lr;
        int levelNum = 18; //center screen
        int heroDrawCheck = 0; //checks to see if hero needs to be spawned
        int eCount = 0; //how many enemies drawn to screen

        bool[,] checkedTiles = new bool[8, 6];
        //Enemy fields
        EnemyManager enemyManager;
        Enemy testEnemy;
        Texture2D slimeSprite;
        List<Texture2D> enemySprites;
        SlimeSprite slime;
        int msPerFrame = 70;


        // Crystal Fields
        CrystalSprite crystal;
        Texture2D movingSlime;
        Texture2D crystalSprite;

        // Bullet fields
        List<Bullet> bullets = new List<Bullet>();
        KeyboardState pastKey;
        float rotation;
        Texture2D fireballSimple;
        Bullet bullet;
        // PlayerState
        private PlayerState playerState;
        private PlayerState previousPlayerState;
        //bullstate
        BulletState bulletState;

        //Moveable Object
        MoveableObjects mo;

        //floor/wall textures
        Texture2D wall;
        Texture2D hole;
        Texture2D grayFloor;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferWidth = 960;
            graphics.PreferredBackBufferHeight = 720;

            graphics.ApplyChanges();
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            //for(int i = 0; i < 20; i++)
            //{
            //    bullets.Add(new Bullet(new Rectangle(0, 0, 50, 50)));
            //}

            gameState = GameState.Menu;
            player = new Player(100, 5, new Rectangle(0, 0, 16, 20), gameTime);
            testEnemy = new Enemy(10, 10, new Rectangle(windowWidth / 2, windowHeight / 2, 50, 50));
            bullet = new Bullet(player, new Rectangle(0, 0, 5, 5));
            enemySprites = new List<Texture2D>();
            gameState = GameState.Menu;
            slime = new SlimeSprite(movingSlime, new Point(100, 100), 10, 1, 10, msPerFrame);
            
            //load in the menuscreens
            mo = new MoveableObjects(new Rectangle(200, 200, 50, 50), player);
            eCount = 0;
            lr = new LevelReader();
            levelVisited = new bool[9];
            for(int i = 0; i < 9; i++)
            {
                levelVisited[i] = false;
            }

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            //player.texture = Content.Load<Texture2D>("brickwall");
            player.texture = Content.Load<Texture2D>("coleSpritesheet2");
            instructions = Content.Load<Texture2D>("Instructions");
            arial16 = Content.Load<SpriteFont>("Arial16");
            slimeSprite = Content.Load<Texture2D>("slimeSpreadsheetBest");
            movingSlime = Content.Load<Texture2D>("slimeSpreadsheetBest");
            crystalSprite = Content.Load<Texture2D>("crystalSpreadsheetBest");
            //fireballSimple = Content.Load<Texture2D>("fireballSimple");
            bullet.texture = Content.Load<Texture2D>("fireballSimple");
            wall = Content.Load<Texture2D>("MossyFloor");
            tex = Content.Load<Texture2D>("MenuScreen");
            tex2 = Content.Load<Texture2D>("DeathScreen");
            mo.texture = Content.Load<Texture2D>("brickwall");
            grayFloor = Content.Load<Texture2D>("GrayFloor");
            hole = Content.Load<Texture2D>("HoleTile");
            startMenu = Content.Load<Texture2D>("startMenu");
            gameOverMenu = Content.Load<Texture2D>("gameOver");
            // TODO: use this.Content to load your game content here
            crystal = new CrystalSprite(crystalSprite, new Point(230, 260), 20, 4, 5, msPerFrame);
            enemySprites.Add(slimeSprite);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            //gets keyboard state
            prevKBState = Keyboard.GetState();
            prevKBState = currentKBState;

            currentKBState = Keyboard.GetState();

            previousPlayerState = playerState;

            //playerState = PlayerState.ShootLeft;

            //playerPosition = playerVelocity + playerPosition;

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here
            if (gameState == GameState.Menu)
            {
                firstRun = true;
                if (currentKBState.IsKeyDown(Keys.Tab))
                {
                    //editor.Show();
                }
                if (currentKBState.IsKeyDown(Keys.Enter) && currentKBState != prevKBState)
                {
                    //editor.SaveText();
                    gameState = GameState.Game;
                    //lr.levelArray();
                }
                if(currentKBState.IsKeyDown(Keys.X) )
                {
                    gameState = GameState.Instructions;
                }
                if (currentKBState.IsKeyDown(Keys.S))
                {
                    gameState = GameState.Story;
                }

            }
            if(gameState == GameState.Story)
            {
                if (currentKBState.IsKeyDown(Keys.Enter))
                {
                    gameState = GameState.Instructions;
                }
            }
            if(gameState == GameState.Instructions)
            {
                if (currentKBState.IsKeyDown(Keys.Enter) && prevKBState.IsKeyUp(Keys.Enter))
                {
                    //editor.SaveText();
                    gameState = GameState.Menu;
                    
                }
            }
            if (gameState == GameState.Game)
            {
                if (firstRun == true)
                {
                    lr.levelArray(lr.levelStartFinder());
                    enemyManager = new EnemyManager(enemySprites);
                    firstRun = false;
                }
                bool pUCheck = false;
                if (lr.result != null)
                {
                    for (int i = 0; i < 8; i++) //rows
                    {
                        for (int h = 0; h < 6; h++) //cols
                        {
                            if (lr.result[i, h] == "W")
                            {
                                if (player.Position.X <= (i * 120 + 15) && player.Position.X >= (i * 120 - 15) && player.Position.Y > h * 120 && player.Position.Y < (h * 120 + 120))
                                {
                                    player.PlayerUpdate(currentKBState, prevKBState, 1); //can't move right
                                    i += 8;
                                    h += 6;
                                    pUCheck = true;
                                }
                                else if (player.Position.X <= (i * 120 + 135) && player.Position.X >= (i * 120 + 105) && player.Position.Y > h * 120 && player.Position.Y < (h * 120 + 120))
                                {
                                    player.PlayerUpdate(currentKBState, prevKBState, 2); //can't move left
                                    i += 8;
                                    h += 6;
                                    pUCheck = true;
                                }
                                else if (player.Position.X > i * 120 && player.Position.X < (i * 120 + 120) && player.Position.Y <= (h * 120 + 135) && player.Position.Y >= (h * 120 + 105))
                                {
                                    player.PlayerUpdate(currentKBState, prevKBState, 3); //can't move up
                                    i += 8;
                                    h += 6;
                                    pUCheck = true;
                                }
                                else if (player.Position.X > i * 120 && player.Position.X < (i * 120 + 120) && player.Position.Y <= (h * 120 + 15) && player.Position.Y >= (h * 120 - 15))
                                {
                                    player.PlayerUpdate(currentKBState, prevKBState, 4); //can't move down
                                    i += 8;
                                    h += 6;
                                    pUCheck = true;
                                }
                            }
                            else if (lr.result[i, h] == "O")
                            {
                                if (player.Position.X <= (i * 120 + 15) && player.Position.X >= (i * 120 - 15) && player.Position.Y > h * 120 && player.Position.Y < (h * 120 + 120))
                                {
                                    player.Health -= 100;
                                }
                                else if (player.Position.X <= (i * 120 + 135) && player.Position.X >= (i * 120 + 105) && player.Position.Y > h * 120 && player.Position.Y < (h * 120 + 120))
                                {
                                    player.Health -= 100;
                                }
                                else if (player.Position.X > i * 120 && player.Position.X < (i * 120 + 120) && player.Position.Y <= (h * 120 + 135) && player.Position.Y >= (h * 120 + 105))
                                {
                                    player.Health -= 100;
                                }
                                else if (player.Position.X > i * 120 && player.Position.X < (i * 120 + 120) && player.Position.Y <= (h * 120 + 15) && player.Position.Y >= (h * 120 - 15))
                                {
                                    player.Health -= 100;
                                }
                            }
                            else if (lr.result[i, h] == "C")
                            {
                                if (player.Position.X <= (i * 120 + 15) && player.Position.X >= (i * 120 - 15) && player.Position.Y > h * 120 && player.Position.Y < (h * 120 + 120))
                                {
                                    gameState = GameState.Victory;
                                }
                                else if (player.Position.X <= (i * 120 + 135) && player.Position.X >= (i * 120 + 105) && player.Position.Y > h * 120 && player.Position.Y < (h * 120 + 120))
                                {
                                    gameState = GameState.Victory;
                                }
                                else if (player.Position.X > i * 120 && player.Position.X < (i * 120 + 120) && player.Position.Y <= (h * 120 + 135) && player.Position.Y >= (h * 120 + 105))
                                {
                                    gameState = GameState.Victory;
                                }
                                else if (player.Position.X > i * 120 && player.Position.X < (i * 120 + 120) && player.Position.Y <= (h * 120 + 15) && player.Position.Y >= (h * 120 - 15))
                                {
                                    gameState = GameState.Victory;
                                }
                            }
                        }
                    }
                }

                if (pUCheck == false)
                {
                    player.PlayerUpdate(currentKBState, prevKBState, 0);
                    enemyManager.Update(player, gameTime);
                }

                foreach (Enemy e in enemyManager.EnemyList)
                {
                    player.Attack(e, bullet);
                    player.TakeDamage(e, gameTime);
                }
                while (bullets.Count() < 20)
                {
                    bullets.Add(bullet);
                }
                
                //player.Attack(testEnemy, bullet);
                player.PlayerPush(mo);


                if (player.Health <= 0)
                {
                    gameState = GameState.GameOver;
                }
                if (currentKBState.IsKeyDown(Keys.Space) && prevKBState.IsKeyUp(Keys.Space))
                {
                    
                    foreach (Bullet bullet in bullets)
                    {
                        bullet.position = player.position;
                        bullet.Update(player);
                    }

                    //fireBullet();
                }
                if(currentKBState.IsKeyDown(Keys.L))
                {
                    gameState = GameState.GameOver;
                }
                //loads in all the enemies if the room has not been visited yet
                if (lr.result != null)
                {
                    for (int i = 0; i < 8; i++) //rows
                    {
                        for (int h = 0; h < 6; h++) //cols
                        {
                            if (lr.result[i, h] == "E")
                            {
                                if (levelNum == 2 && levelVisited[0] == false)
                                {
                                    eCount++;
                                }
                                else if (levelNum == 6 && levelVisited[1] == false)
                                {
                                    eCount++;
                                }
                                else if (levelNum == 6 && levelVisited[2] == false)
                                {
                                    eCount++;
                                }
                                else if (levelNum == 6 && levelVisited[3] == false)
                                {
                                    eCount++;
                                }
                                else if (levelNum == 6 && levelVisited[4] == false)
                                {
                                    eCount++;
                                }
                                else if (levelNum == 6 && levelVisited[4] == false)
                                {
                                    eCount++;
                                }
                                else if (levelNum == 6 && levelVisited[4] == false)
                                {
                                    eCount++;
                                }
                                else if (levelNum == 6 && levelVisited[4] == false)
                                {
                                    eCount++;
                                }
                                else if (levelNum == 6 && levelVisited[4] == false)
                                {
                                    eCount++;
                                }
                            }
                        }
                    }
                }
                if(eCount > 0)
                {
                    
                }
                eCount = 0;
                //switches to the next screen if the player is at the edge
                if (player.position.X > GraphicsDevice.Viewport.Width)
                {
                    levelNum += 3; //switches to the screen to the right
                    lr.levelArray(levelNum);
                    player.position.X = 50;
                    if (levelNum == 13 && levelVisited[7] == false)
                    {
                        levelVisited[7] = true;
                    }
                    else if(levelNum == 16 && levelVisited[8] == false)
                    {
                        levelVisited[8] = true;
                    }
                }
                else if (player.position.X < 0)
                {
                    levelNum -= 3; //switches to the screen to the left
                    lr.levelArray(levelNum);
                    player.position.X = GraphicsDevice.Viewport.Width - 50;
                    if (levelNum == 4 && levelVisited[5] == false)
                    {
                        levelVisited[5] = true;
                    }
                    else if (levelNum == 7 && levelVisited[6] == false)
                    {
                        levelVisited[6] = true;
                    }
                }
                else if (player.position.Y > GraphicsDevice.Viewport.Height)
                {
                    levelNum += 4; //switches to the screen down
                    player.position.Y = 50;
                    lr.levelArray(levelNum);
                    if(levelNum == 2 && levelVisited[0] == false)
                    {
                        levelVisited[0] = true;
                    }
                    else if(levelNum == 6 && levelVisited[1] == false)
                    {
                        levelVisited[1] = true;
                    }
                    else if (levelNum == 6 && levelVisited[2] == false)
                    {
                        levelVisited[2] = true;
                    }
                    else if (levelNum == 6 && levelVisited[3] == false)
                    {
                        levelVisited[3] = true;
                    }
                    else if (levelNum == 6 && levelVisited[4] == false)
                    {
                        levelVisited[4] = true;
                    }
                }
                else if (player.position.Y <= 0)
                {
                    levelNum -= 4; //switches to the screen up
                    player.position.Y = GraphicsDevice.Viewport.Height - 50;
                    lr.levelArray(levelNum);
                    if (levelNum == 2 && levelVisited[0] == false)
                    {
                        levelVisited[0] = true;
                    }
                    else if (levelNum == 6 && levelVisited[1] == false)
                    {
                        levelVisited[1] = true;
                    }
                    else if (levelNum == 6 && levelVisited[2] == false)
                    {
                        levelVisited[2] = true;
                    }
                    else if (levelNum == 6 && levelVisited[3] == false)
                    {
                        levelVisited[3] = true;
                    }
                    else if (levelNum == 6 && levelVisited[4] == false)
                    {
                        levelVisited[4] = true;
                    }
                }
            }
            if (gameState == GameState.Victory)
            {
                player.Reset(chosenPlayerX, chosenPlayerY);
                levelNum = 18;
                if (currentKBState.IsKeyDown(Keys.Enter))
                {
                    gameState = GameState.Menu;
                }
            }
            if (gameState == GameState.GameOver)
            {
                player.Reset(chosenPlayerX,chosenPlayerY);
                levelNum = 14;
                if (currentKBState.IsKeyDown(Keys.Enter))
                {
                    gameState = GameState.Menu;
                }
                if(currentKBState.IsKeyDown(Keys.R))
                {
                    gameState = GameState.Game;
                }
            }

           // slime.Update(gameTime);
            crystal.Update(gameTime);

            //base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            if (gameState == GameState.Menu)
            {
                spriteBatch.Draw(startMenu, new Rectangle(0, 0, windowWidth, windowHeight), Color.White);
            }
            if(gameState == GameState.Victory)
            {
                spriteBatch.Draw(instructions, new Rectangle(0, 0, windowWidth, windowHeight), Color.White);
                spriteBatch.DrawString(arial16, "Congradulations, you won the Game", new Vector2(420, 150), Color.White);
                spriteBatch.DrawString(arial16, "Press Enter to return to the Main Menu", new Vector2(280, 560), Color.White);
            }
            if(gameState == GameState.Story)
            {
                spriteBatch.Draw(instructions, new Rectangle(0, 0, windowWidth, windowHeight), Color.White);
                spriteBatch.DrawString(arial16, "Story", new Vector2(420, 150), Color.White);
                spriteBatch.DrawString(arial16, "Somwhere, inside the Stonehedge Maze lies the Crystal of Power.", new Vector2(130, 210), Color.White);
                spriteBatch.DrawString(arial16, "Legend holds that the one who finds it will have their greatest desire granted.", new Vector2(130, 260), Color.White);
                spriteBatch.DrawString(arial16, "For centuries, the ancient Staff of Heroes, needed to complete the maze", new Vector2(130, 310), Color.White);
                spriteBatch.DrawString(arial16, "had been lost, until you managed to find it. Equipped with nothing but the", new Vector2(130, 360), Color.White);
                spriteBatch.DrawString(arial16, "Staff and a Sword, you must battle your way past the enemies, find the Crystal,", new Vector2(130, 410), Color.White);
                spriteBatch.DrawString(arial16, "and use it's wish to save your best friend Keela who is dying of a terminal illness.", new Vector2(130, 460), Color.White);
                spriteBatch.DrawString(arial16, "Press Enter to return to the Main Menu", new Vector2(280, 560), Color.White);
            }
            if(gameState == GameState.Instructions)
            {
                spriteBatch.Draw(instructions, new Rectangle(0, 0, windowWidth, windowHeight), Color.White);
                spriteBatch.DrawString(arial16, "Controls", new Vector2(420, 150), Color.White);
                spriteBatch.DrawString(arial16, "Up, Down, Left, Right:                          Four Directional Buttons", new Vector2(200, 210), Color.White);
                spriteBatch.DrawString(arial16, "Meele Attack:                                       Z", new Vector2(200, 260), Color.White);
                spriteBatch.DrawString(arial16, "Crystal Attack:                                     Space Bar", new Vector2(200, 310), Color.White);
                spriteBatch.DrawString(arial16, "End Game:                                           L", new Vector2(200, 360), Color.White);
                spriteBatch.DrawString(arial16, "Press Enter to Return to the Menu", new Vector2(320, 410), Color.White);
            }
            if (gameState == GameState.Game)
            {
                for (int i = 0; i < 8; i++) //rows
                {
                    for (int h = 0; h < 6; h++) //cols
                    {
                        if (lr.result[i, h] == "W")
                        {
                            Wall w = new Wall(new Rectangle(i * 120, h * 120, windowWidth / 8, windowHeight / 6), player);
                            player.PlayerWallCollide(w);
                            spriteBatch.Draw(wall, new Rectangle(i * 120, h * 120, windowWidth / 8, windowHeight / 6), Color.White);
                        }
                        else if (lr.result[i, h] == "E")
                        {
                            
                            spriteBatch.Draw(grayFloor, new Rectangle(i * 120, h * 120, windowWidth / 8, windowHeight / 6), Color.White);
                            if(checkedTiles[i, h] == false)
                            {
                                enemyManager.Initalize(i * 120, h * 120);
                            }
                            //testEnemy.position.X = i * 120;
                            //testEnemy.position.Y = h * 120;
                            enemyManager.Draw(spriteBatch, arial16,gameTime);
                            checkedTiles[i, h] = true;
                        }
                        else if (lr.result[i, h] == "H")
                        {
                            spriteBatch.Draw(grayFloor, new Rectangle(i * 120, h * 120, windowWidth / 8, windowHeight / 6), Color.White);
                            if (heroDrawCheck == 0) //it only goes through this if statement once and it's to see if the hero needs to be drawn in the spawn position
                            {
                                chosenPlayerX = i * 120;
                                chosenPlayerY = h * 120;
                                player.position.X = i * 120;
                                player.position.Y = h * 120;
                                heroDrawCheck++;
                            }
                            player.Draw(spriteBatch, arial16);
                        }
                        else if (lr.result[i, h] == "O")
                        {
                            Wall w = new Wall(new Rectangle(i * 120, h * 120, windowWidth / 8, windowHeight / 6), player);
                            player.PlayerWallCollide(w);
                            spriteBatch.Draw(hole, new Rectangle(i * 120, h * 120, windowWidth / 8, windowHeight / 6), Color.White);
                        }
                        else if (lr.result[i, h] == "C")
                        {
                            spriteBatch.Draw(grayFloor, new Rectangle(i * 120, h * 120, windowWidth / 8, windowHeight / 6), Color.White);
                            Wall w = new Wall(new Rectangle(i * 120, h * 120, windowWidth / 8, windowHeight / 6), player);
                            player.PlayerWallCollide(w);
                            crystal.Draw(gameTime, spriteBatch, new Vector2(i*120, h*120));
                        }
                        else //regular walking area
                        {
                            spriteBatch.Draw(grayFloor, new Rectangle(i * 120, h * 120, windowWidth / 8, windowHeight / 6), Color.White);
                        }
                    }
                }

                player.Draw(spriteBatch, arial16);
                //testEnemy.Draw(spriteBatch, arial16);
                //mo.Draw(spriteBatch);
                ///slime.Draw(gameTime, spriteBatch);
                //crystal.Draw(gameTime, spriteBatch);

                if (bullet.Shot == true)
                {
                    foreach (Bullet bullet in bullets)
                    {
                        bullet.Draw(spriteBatch);
                    }
                }


                //player.Draw(spriteBatch);
                
                if (playerState == PlayerState.Dead)
                {
                    gameState = GameState.GameOver;
                }
            }
            if (gameState == GameState.GameOver)
            {
                spriteBatch.Draw(gameOverMenu, new Rectangle(0, 0, windowWidth, windowHeight), Color.White);
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }

        public void UpdateBullets()
        {
            /*
            foreach (Bullet bullet in bullets)
            {
                Vector2 playerPosition = new Vector2(player.position.X, player.position.Y);
                bullet.position += bullet.velocity;
                if (Vector2.Distance(bullet.position, playerPosition) > 500)
                {
                    bullet.isVisible = false;
                }
                for (int i = 0; i < bullets.Count; i++)
                {
                    if (!bullets[i].isVisible)
                    {
                        bullets.RemoveAt(i);
                        i--;
                    }
                }
            }
            */
            
            foreach (Bullet bullet in bullets)
            {
                Vector2 playerPosition = new Vector2(player.position.X, player.position.Y);
                //player.PlayerUpdate(currentKBState, prevKBState);
                //prevKBState = playerState;
                //Vector2 screenSize = new Vector2(GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width, GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height);
                // Shoot fireball right
                player.fireBullet(bullet);
                //if (currentKBState.IsKeyDown(Keys.Down) == true || prevKBState.IsKeyDown(Keys.Down) == true)
                //{
                //    bullet.position.Y += 5;
                //}
                if (Vector2.Distance(new Vector2(bullet.position.X,bullet.position.Y), playerPosition) > 1000)
                //if (bullet.position == screenSize)
                {
                    bullet.isVisible = false;
                }

                //if (Vector2.Distance(bullet.position, screenSize) > 1)
                //{
                //    bullet.isVisible = false;
                //}
            }
            for (int i = 0; i < bullets.Count; i++)
            {
                if (!bullets[i].isVisible)
                {
                    bullets.RemoveAt(i);
                    i--;
                }
            }
            
        }

        /*
        public void fireBullet()
        {
            Vector2 playerPosition = new Vector2(player.position.X, player.position.Y);
            Bullet newBullet = new Bullet(player, fireballSimple, new Rectangle(0, 0, 10, 10));
            newBullet.velocity = new Vector2((int)Math.Cos(rotation), (int)Math.Sin(rotation)) * 5;// + playerVelocity;
            //if (playerState == PlayerState.FacingRight || previousPlayerState == PlayerState.FacingRight)
            //{
                newBullet.position.X += (int)newBullet.velocity.X + player.position.X;
                newBullet.position.Y += (int)(player.Position.Y);
            //}
            
            //newBullet.position = playerPosition + newBullet.velocity * 5;
            newBullet.isVisible = true;

            if(bullets.Count() < 20)
            {
                bullets.Add(newBullet);
            }
        }
        */
        /*
        public void fireBullet()
        {
            Vector2 playerPosition = new Vector2(player.position.X, player.position.Y);
            Bullet newBullet = new Bullet(new Rectangle(0, 0, 10, 10), fireballSimple);
            newBullet.speed = new Vector2((float)Math.Cos(rotation), (float)Math.Sin(rotation)) * 5;
            newBullet.position = (playerPosition) + (newBullet.speed * 5);
            newBullet.isVisible = true;

            if (bullets.Count() < 100)
            {
                bullets.Add(newBullet);
            }
        }
        */
    }
}

