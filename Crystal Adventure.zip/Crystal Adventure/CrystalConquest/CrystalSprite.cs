﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace CrystalConquest
{
    class CrystalSprite
    {
        // attributes
        private Texture2D image;
        private int frame;
        private Point frameSize;
        private int numFrames;
        private int rows, cols;
        private int timeSinceLastFrame;
        private int millisecondsPerFrame;
        private Point currentFrame;
        private Vector2 position;

        public int MillisecondsPerFrame
        {
            set { millisecondsPerFrame = value; }
        }

        // constructor
        public CrystalSprite(Texture2D img, Point size, int frames, int rws, int cls, int msPerFrame)
        {
            image = img;
            frameSize = size;
            numFrames = frames;
            rows = rws;
            cols = cls;
            millisecondsPerFrame = msPerFrame;
            currentFrame.X = 0;
            currentFrame.Y = 0;
            position.X = 200;
            position.Y = 200;
        }

        public void Update(GameTime gameTime)
        {
            timeSinceLastFrame += gameTime.ElapsedGameTime.Milliseconds;

            if (timeSinceLastFrame > millisecondsPerFrame)
            {
                timeSinceLastFrame = 0;
                frame++;

                if (frame >= numFrames)
                {
                    frame = 0;
                }

                switch (frame)
                {
                    case 0:
                        currentFrame.X = 1;
                        currentFrame.Y = 1;
                        break;
                    case 1:
                        currentFrame.X = 233;
                        currentFrame.Y = 1;
                        break;
                    case 2:
                        currentFrame.X = 465;
                        currentFrame.Y = 1;
                        break;
                    case 3:
                        currentFrame.X = 697;
                        currentFrame.Y = 1;
                        break;
                    case 4:
                        currentFrame.X = 929;
                        currentFrame.Y = 1;
                        break;

                    case 5:
                        currentFrame.X = 1;
                        currentFrame.Y = 263;
                        break;
                    case 6:
                        currentFrame.X = 233;
                        currentFrame.Y = 263;
                        break;
                    case 7:
                        currentFrame.X = 465;
                        currentFrame.Y = 263;
                        break;
                    case 8:
                        currentFrame.X = 697;
                        currentFrame.Y = 263;
                        break;
                    case 9:
                        currentFrame.X = 929;
                        currentFrame.Y = 263;
                        break;

                    case 10:
                        currentFrame.X = 1;
                        currentFrame.Y = 525;
                        break;
                    case 11:
                        currentFrame.X = 233;
                        currentFrame.Y = 525;
                        break;
                    case 12:
                        currentFrame.X = 465;
                        currentFrame.Y = 525;
                        break;
                    case 13:
                        currentFrame.X = 697;
                        currentFrame.Y = 525;
                        break;
                    case 14:
                        currentFrame.X = 929;
                        currentFrame.Y = 525;
                        break;

                    case 15:
                        currentFrame.X = 1;
                        currentFrame.Y = 787;
                        break;
                    case 16:
                        currentFrame.X = 233;
                        currentFrame.Y = 787;
                        break;
                    case 17:
                        currentFrame.X = 465;
                        currentFrame.Y = 787;
                        break;
                    case 18:
                        currentFrame.X = 697;
                        currentFrame.Y = 787;
                        break;
                    case 19:
                        currentFrame.X = 929;
                        currentFrame.Y = 787;
                        break;
                }
            }
        }

        public void Draw(GameTime gameTime, SpriteBatch spriteBatch, Vector2 pos)
        {
            spriteBatch.Draw(image, pos, new Rectangle(currentFrame.X, currentFrame.Y, frameSize.X, frameSize.Y),
                Color.White, 0, Vector2.Zero, 0.1f, SpriteEffects.None, 0);
        }
    }
}

