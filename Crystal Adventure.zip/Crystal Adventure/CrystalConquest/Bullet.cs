﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.IO;

namespace CrystalConquest
{
    public enum BulletState
    {
        Right,
        Left,
        Down,
        Up
    }
    class Bullet : GameObjects
    {
        Player player;
        BulletState bulletState;
        public Texture2D texture;

        public Rectangle position;
        public Vector2 velocity;
        public Vector2 origin;
        public bool shot;
        public int damage;
        
        public bool Shot
        {
            get { return shot; }
            set { shot = value; }
        }
        public bool isVisible;

        // constructor
        public Bullet (Player player, Rectangle bulletRectangle) : base(bulletRectangle)
        {
            bulletState = BulletState.Right;
            this.player = player;
            position = player.Position;
            damage = 10;
            isVisible = false;
            shot = false;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            if(shot == true)
            {
                if(bulletState == BulletState.Right)
                {
                    position.X += 2;
                    spriteBatch.Draw(texture, position, Color.White);
                }
                if(bulletState == BulletState.Left)
                {
                    position.X -= 2;
                    spriteBatch.Draw(texture, position, Color.White);
                }
                if (bulletState == BulletState.Down)
                {
                    position.Y += 2;
                    spriteBatch.Draw(texture, position, Color.White);
                }
                if (bulletState == BulletState.Up)
                {
                    position.Y -= 2;
                    spriteBatch.Draw(texture, position, Color.White);
                }
            }
        }

        public void Update(Player player)
        {
            if (player.fireBullet(this) == "right")
            {
                bulletState = BulletState.Right;
            }
            if (player.fireBullet(this) == "left")
            {
                bulletState = BulletState.Left;
            }
            if (player.fireBullet(this) == "up")
            {
                bulletState = BulletState.Up;
            }
            if (player.fireBullet(this) == "down")
            {
                bulletState = BulletState.Down;
            }
        }
        //Player player;
        /*
        public Texture2D bulletTexture;

        public Vector2 position;
        public Vector2 speed;
        public Vector2 origin;

        //Bullets
        //List<Bullet> bullets = new List<Bullet>();
        //Bullet bullet;
        //float rotation;
        //Texture2D fireballSimple;

        public bool isVisible;

        public Bullet(Rectangle bulletRectangle, Texture2D bTexture) : base(bulletRectangle)
        {
            bulletTexture = bTexture;
            isVisible = false;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(bulletTexture, position, null, Color.White, 0f, origin, 1f, SpriteEffects.None, 1);
        }
        */
    }
}
