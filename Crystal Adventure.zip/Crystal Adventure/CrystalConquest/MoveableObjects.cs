﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace CrystalConquest
{
    class MoveableObjects : GameObjects
    {
        Player player;
        private PlayerState playerState;
        public bool passable;

        public bool Passable
        {
            get { return passable; }
        }
        const int windowWidth = 960;
        const int windowHeight = 720;
        public MoveableObjects(Rectangle OPos, Player player) :base(OPos)
        {
            this.player = player;
            passable = false;
        }

        public bool Push()
        {
            if(position.Intersects(player.position))
            {
                CheckBounds();
                return true;
            }
            return false;
        }
        private void CheckBounds()
        {
            //checks for xBounds
            if (position.X <= 0)
            {
                position.X = 0;
            }
            //checking if it exceeds the window size
            else if (position.X >= windowWidth - position.Width)
            {
                position.X = windowWidth - position.Width;
            }

            //checks for yBounds
            if (position.Y <= 0)
            {
                position.Y = 0;
            }
            else if (position.Y >= windowHeight - position.Height)
            {
                position.Y = windowHeight - position.Height;
            }
        }
        public void Draw(SpriteBatch sb)
        {
            sb.Draw(texture, position, Color.White);
        }
    }
   
}
