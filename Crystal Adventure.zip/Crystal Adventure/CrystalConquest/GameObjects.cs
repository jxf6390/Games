﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace CrystalConquest
{
    class GameObjects
    {
        //game object fields
        public Texture2D texture;
        public Rectangle position;
        
        //public properities
        public Texture2D Texture
        {
            get { return texture; }
            set { texture = value; }
        }

        //allows us to get and set the values of the collision rectangle for the gameobject
        public Rectangle Position
        {
            get { return position; }
            set
            {
                position.X = value.X;
                position.Y = value.Y;
                position = value;
            }
        }
        //public constructor
        public GameObjects(Rectangle _position)
        {
            position = _position;
        }

        //methods 

    }
}
