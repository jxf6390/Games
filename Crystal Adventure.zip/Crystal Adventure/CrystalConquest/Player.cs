﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace CrystalConquest
{
    //acts as a child class which creates the player object
    #region Player Enum
    enum PlayerState
    {
        FacingLeft = 0,
        FacingRight = 1,
        FacingUp = 2,
        FacingDown = 3,
        WalkingLeft = 4,
        WalkingRight = 5,
        WalkingUp = 6,
        WalkingDown = 7,
        ShootLeft = 8,
        ShootRight = 9,
        ShootUp = 10,
        ShootDown = 11,
        AttackLeft = 12,
        AttackRight = 13,
        AttackUp = 14,
        AttackDown = 15,
        Dead = 16
        #endregion

    }
    class Player : Character
    {
        #region Fields
        private PlayerState playerState;
        private PlayerState prevPlayerState;

        //TakeDamageMethod fields
        private bool invincible;
        private float timer;

        //player animation (I'll fix this soon)
        private int frame;
        private Point frameSize;
        private int numFrames;
        private int rows, cols;
        private int timeSinceLastFrame;
        private int millisecondsPerFrame;
        private Point currentFrame;

        private Wall w;
        private bool wallCollide;

        Bullet bullet;

        // property to allow us to change display time
        public int MillisecondsPerFrame
        {
            set { millisecondsPerFrame = value; }
        }

        //window size
        const int windowWidth = 960;
        const int windowHeight = 720;

        #endregion
        #region PlayerConstructor
        public Player(int Phealth, int Pdamage, Rectangle Pposition, GameTime gameTime) : base(Phealth, Pdamage, Pposition)
        {
            playerState = PlayerState.FacingRight;
            invincible = false;
            timer = 0;
            Point frameSize = new Point(16, 20);
            //int numFrames = 2;
            //int rows = 4;
            //int cols = 2;
            //millisecondsPerFrame = msPerFrame;
            currentFrame.X = 0;
            currentFrame.Y = 0;
        }
        #endregion
        //methods
        #region Methods
        #region PlayerUpdateMethod
        public void PlayerUpdate(KeyboardState kbState, KeyboardState prevKBState, int movementCheck)
        {
            prevPlayerState = playerState;
            #region PlayerMovementChecks
            if (kbState.IsKeyDown(Keys.Right))
            {
                if (movementCheck != 1)
                {
                    position.X += 5;
                }
                //CheckBounds();
                playerState = PlayerState.WalkingRight;
            }
            if (kbState.IsKeyDown(Keys.Left))
            {
                if (movementCheck != 2)
                {
                    position.X -= 5;
                }
                //CheckBounds();
                playerState = PlayerState.WalkingLeft;
            }
            if (kbState.IsKeyDown(Keys.Up))
            {
                if (movementCheck != 3)
                {
                    position.Y -= 5;
                }
                // CheckBounds();
                playerState = PlayerState.WalkingUp;
            }
            if (kbState.IsKeyDown(Keys.Down))
            {
                if (movementCheck != 4)
                {
                    position.Y += 5;
                }
                //CheckBounds();
                playerState = PlayerState.WalkingDown;
            }
            #endregion
            #region PlayerFacingChecks
            if ((prevPlayerState == PlayerState.WalkingRight || prevPlayerState == PlayerState.AttackRight) && (kbState.IsKeyUp(Keys.Up) && kbState.IsKeyUp(Keys.Left) && kbState.IsKeyUp(Keys.Down) && kbState.IsKeyUp(Keys.Right)))
            {
                playerState = PlayerState.FacingRight;
            }
            if ((prevPlayerState == PlayerState.WalkingLeft || prevPlayerState == PlayerState.AttackLeft) && (kbState.IsKeyUp(Keys.Up) && kbState.IsKeyUp(Keys.Left) && kbState.IsKeyUp(Keys.Down) && kbState.IsKeyUp(Keys.Right)))
            {
                playerState = PlayerState.FacingLeft;
            }
            if ((prevPlayerState == PlayerState.WalkingUp || prevPlayerState == PlayerState.AttackUp) && (kbState.IsKeyUp(Keys.Up) && kbState.IsKeyUp(Keys.Left) && kbState.IsKeyUp(Keys.Down) && kbState.IsKeyUp(Keys.Right)))
            {
                playerState = PlayerState.FacingUp;
            }
            if ((prevPlayerState == PlayerState.WalkingDown || prevPlayerState == PlayerState.AttackDown) && (kbState.IsKeyUp(Keys.Up) && kbState.IsKeyUp(Keys.Left) && kbState.IsKeyUp(Keys.Down) && kbState.IsKeyUp(Keys.Right)))
            {
                playerState = PlayerState.FacingDown;
            }
            #endregion
            #region PlayerAttackChecks
            if (kbState.IsKeyDown(Keys.Z)) //&& prevKBState.IsKeyUp(Keys.Z))
            {
                switch (playerState)
                {
                    case PlayerState.WalkingRight:
                    case PlayerState.FacingRight:
                        playerState = PlayerState.AttackRight;
                        break;
                    case PlayerState.WalkingLeft:
                    case PlayerState.FacingLeft:
                        playerState = PlayerState.AttackLeft;
                        break;
                    case PlayerState.WalkingUp:
                    case PlayerState.FacingUp:
                        playerState = PlayerState.AttackUp;
                        break;
                    case PlayerState.WalkingDown:
                    case PlayerState.FacingDown:
                        playerState = PlayerState.AttackDown;
                        break;
                }
            }
            if (kbState.IsKeyDown(Keys.Space))// && prevKBState.IsKeyUp(Keys.Space))
            {
                switch (playerState)
                {
                    case PlayerState.WalkingRight:
                    case PlayerState.FacingRight:
                        playerState = PlayerState.ShootRight;
                        break;
                    case PlayerState.WalkingLeft:
                    case PlayerState.FacingLeft:
                        playerState = PlayerState.ShootLeft;
                        break;
                    case PlayerState.WalkingUp:
                    case PlayerState.FacingUp:
                        playerState = PlayerState.ShootUp;
                        break;
                    case PlayerState.WalkingDown:
                    case PlayerState.FacingDown:
                        playerState = PlayerState.ShootDown;
                        break;
                }
            }
            #endregion
            #region DeathCheck
            if (Health <= 0)
            {
                playerState = PlayerState.Dead;
            }
            #endregion
        }
        #endregion
        #region CheckBoundsMethod
        private void CheckBounds()
        {
            //checks for xBounds
            if (position.X <= 0)
            {
                position.X = 0;
            }
            //checking if it exceeds the window size
            else if (position.X >= windowWidth - position.Width)
            {
                position.X = windowWidth - position.Width;
            }

            //checks for yBounds
            if (position.Y <= 0)
            {
                position.Y = 0;
            }
            else if (position.Y >= windowHeight - position.Height)
            {
                position.Y = windowHeight - position.Height;
            }
        }
        #endregion
        #region PlayerDrawMethod
        public void Draw(SpriteBatch sb, SpriteFont sf)
        {
            if (playerState == PlayerState.FacingRight)
            {
                DrawColeFacingRight(sb);
            }
            if (playerState == PlayerState.FacingLeft)
            {
                DrawColeFacingLeft(sb);
            }
            if (playerState == PlayerState.FacingUp)
            {
                DrawColeFacingUp(sb);
            }
            if (playerState == PlayerState.FacingDown)
            {
                DrawColeFacingDown(sb);
            }
            if (playerState == PlayerState.WalkingRight)
            {
                DrawColeWalkingRight(sb);
            }
            if (playerState == PlayerState.WalkingLeft)
            {
                DrawColeWalkingLeft(sb);
            }
            if (playerState == PlayerState.WalkingUp)
            {
                DrawColeWalkingUp(sb);
            }
            if (playerState == PlayerState.WalkingDown)
            {
                DrawColeWalkingDown(sb);
            }
            if (playerState == PlayerState.AttackRight)
            {
                DrawColeAttackingRight(sb);
            }
            if (playerState == PlayerState.AttackLeft)
            {
                DrawColeAttackingLeft(sb);
            }
            if (playerState == PlayerState.AttackUp)
            {
                DrawColeAttackingUp(sb);
            }
            if (playerState == PlayerState.AttackDown)
            {
                DrawColeAttackingDown(sb);
            }
            if (playerState == PlayerState.ShootRight)
            {
                DrawColeShootingRight(sb);
            }
            if (playerState == PlayerState.ShootLeft)
            {
                DrawColeShootingLeft(sb);
            }
            if (playerState == PlayerState.ShootUp)
            {
                DrawColeShootingUp(sb);
            }
            if (playerState == PlayerState.ShootDown)
            {
                DrawColeShootingDown(sb);
            }
            //sb.Draw(texture, position, Color.White);
            //sb.DrawString(sf, playerState.ToString(), new Vector2(0, 0), Color.White);
            //sb.DrawString(sf, position.X.ToString() + " ," + position.Y.ToString(), new Vector2(0, 20), Color.White);
            sb.DrawString(sf, "Health: " + health.ToString(), new Vector2(0, 0), Color.White);
            //sb.DrawString(sf, "Invincible: " + invincible.ToString(), new Vector2(0, 60), Color.White);

            //Draws player when hurt 
            if (invincible == true)
            {
                if (playerState == PlayerState.FacingRight)
                {
                    sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(1, 22, 16, 20),
                Color.Red, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
                }
                if (playerState == PlayerState.FacingLeft)
                {
                    sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(1, 43, 16, 20),
                Color.Red, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
                }
                if (playerState == PlayerState.FacingUp)
                {
                    sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(1, 64, 16, 20),
                Color.Red, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
                }
                if (playerState == PlayerState.FacingDown)
                {
                    sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(1, 1, 16, 20),
                Color.Red, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
                }
                if (playerState == PlayerState.WalkingRight)
                {
                    sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(19, 22, 16, 20),
                Color.Red, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
                }
                if (playerState == PlayerState.WalkingLeft)
                {
                    sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(19, 43, 16, 20),
                Color.Red, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
                }
                if (playerState == PlayerState.WalkingUp)
                {
                    sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(1, 64, 16, 20),
                Color.Red, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
                }
                if (playerState == PlayerState.WalkingDown)
                {
                    sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(19, 1, 16, 20),
                Color.Red, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
                }
                if (playerState == PlayerState.AttackRight)
                {
                    sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(96, 29, 22, 20),
                Color.Red, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
                }
                if (playerState == PlayerState.AttackLeft)
                {
                    sb.Draw(texture, new Vector2(position.X - 6, position.Y), new Rectangle(96, 29, 22, 20),
                Color.Red, 0, Vector2.Zero, 1f, SpriteEffects.FlipHorizontally, 0);
                }
                if (playerState == PlayerState.AttackUp)
                {
                    sb.Draw(texture, new Vector2(position.X, position.Y - 9), new Rectangle(96, 71, 16, 28),
                Color.Red, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
                }
                if (playerState == PlayerState.AttackDown)
                {
                    sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(96, 1, 16, 27),
                Color.Red, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
                }
            }
        }
        #endregion
        public void PlayerWallCollide(Wall w)
        {
            if(w.CheckCollision() == true)
            {
                wallCollide = true;
            }
            else
            {
                wallCollide = false;
            }
        }
        #region MovingObjectsMethod
        //player moving objects
        public void PlayerPush(MoveableObjects mo)
        {
            if (mo.Push() == true)
            {
                if (playerState == PlayerState.WalkingLeft || playerState == PlayerState.FacingLeft)
                {
                    mo.position.X -= 5;
                }
                if (playerState == PlayerState.WalkingRight || playerState == PlayerState.FacingRight)
                {
                    mo.position.X += 5;
                }
                if (playerState == PlayerState.WalkingUp || playerState == PlayerState.FacingUp)
                {
                    mo.position.Y -= 5;
                }
                if (playerState == PlayerState.WalkingDown || playerState == PlayerState.FacingDown)
                {
                    mo.position.Y += 5;
                }
            }
        }
        #endregion
        #region TakeDamageMethod
        //Handles enimies damage to the player
        //Takes damage only when they are not invincible
        public void TakeDamage(Enemy enemy, GameTime gameTime)
        {
            if (invincible == false)
            {
                if (position.Intersects(enemy.position))
                {
                    health -= enemy.Damage;
                    invincible = true;
                }
            }
            else
            {
                //once a second has passed the player will lose invincibility
                timer += (float)gameTime.ElapsedGameTime.TotalSeconds;
                if (timer >= 1)
                {
                    invincible = false;
                    timer = 0;
                }
            }
        }
        #endregion
        #region AttackMethod
        //Handles players damage to enemies
        //if the player is attacking in any direction and intersects with the enemy then the enemy takes damage
        public void Attack(Enemy enemy, Bullet bullet)
        {
            if (playerState == PlayerState.AttackDown || playerState == PlayerState.AttackLeft || playerState == PlayerState.AttackRight || playerState == PlayerState.AttackUp)
            {
                if (position.Intersects(enemy.position))
                {
                    enemy.Health -= damage;
                }
            }
            if (playerState == PlayerState.ShootDown || playerState == PlayerState.ShootLeft || playerState == PlayerState.ShootRight || playerState == PlayerState.ShootUp)
            {
                if (bullet.position.Intersects(enemy.position))
                {
                    enemy.Health -= bullet.damage;
                }
            }
            //if (bullet.position.Intersects(enemy.position))
            //{
            //   enemy.Health -= damage;
            //}
        }
        #endregion
        #region PlayerResetMethod
        public void Reset(int x, int y)
        {
            health = 100;
            position = new Rectangle(x, y, 16, 20);
        }
        #endregion
        #region SpriteSheetAnimationMethods
        private void DrawColeFacingDown(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(1, 1, 16, 20),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
        }
        private void DrawColeFacingRight(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(1, 22, 16, 20),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
        }
        private void DrawColeFacingLeft(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(1, 43, 16, 20),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
        }
        private void DrawColeFacingUp(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(19, 64, 16, 20),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
        }
        private void DrawColeWalkingDown(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(19, 1, 16, 20),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
        }
        private void DrawColeWalkingRight(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(19, 22, 16, 20),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
        }
        private void DrawColeWalkingLeft(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(19, 43, 16, 20),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
        }
        private void DrawColeWalkingUp(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(1, 64, 16, 20),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
        }
        private void DrawColeShootingDown(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(73, 1, 16, 27),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
        }
        private void DrawColeShootingRight(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(73, 29, 22, 20),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
        }
        private void DrawColeShootingLeft(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X - 6, position.Y), new Rectangle(73, 29, 22, 20),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.FlipHorizontally, 0);
        }
        private void DrawColeShootingUp(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X, position.Y - 2), new Rectangle(73, 71, 16, 22),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
        }
        private void DrawColeAttackingDown(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(96, 1, 16, 27),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
        }
        private void DrawColeAttackingRight(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X, position.Y), new Rectangle(96, 29, 22, 20),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
        }
        private void DrawColeAttackingLeft(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X - 6, position.Y), new Rectangle(96, 29, 22, 20),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.FlipHorizontally, 0);
        }
        private void DrawColeAttackingUp(SpriteBatch sb)
        {
            sb.Draw(texture, new Vector2(position.X, position.Y - 9), new Rectangle(96, 71, 16, 28),
                Color.White, 0, Vector2.Zero, 1f, SpriteEffects.None, 0);
        }


        #endregion
        public string fireBullet(Bullet bullet)
        {
            bullet.Shot = true;

            if (playerState == PlayerState.ShootRight)
            {
                return "right";
            }
            if (playerState == PlayerState.ShootLeft)
            {
                return "left";
            }
            if (playerState == PlayerState.ShootDown)
            {
                return "down";
            }
            if (playerState == PlayerState.ShootUp)
            {
                return "up";
            }
            return "";
        }

    }
}
#endregion