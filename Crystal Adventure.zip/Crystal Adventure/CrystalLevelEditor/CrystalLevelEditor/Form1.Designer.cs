﻿namespace CrystalLevelEditor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.button97 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.button101 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.button103 = new System.Windows.Forms.Button();
            this.button104 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.button106 = new System.Windows.Forms.Button();
            this.button107 = new System.Windows.Forms.Button();
            this.button108 = new System.Windows.Forms.Button();
            this.button109 = new System.Windows.Forms.Button();
            this.button110 = new System.Windows.Forms.Button();
            this.button111 = new System.Windows.Forms.Button();
            this.button112 = new System.Windows.Forms.Button();
            this.button113 = new System.Windows.Forms.Button();
            this.button114 = new System.Windows.Forms.Button();
            this.button115 = new System.Windows.Forms.Button();
            this.button116 = new System.Windows.Forms.Button();
            this.button117 = new System.Windows.Forms.Button();
            this.button118 = new System.Windows.Forms.Button();
            this.button119 = new System.Windows.Forms.Button();
            this.button120 = new System.Windows.Forms.Button();
            this.button121 = new System.Windows.Forms.Button();
            this.button122 = new System.Windows.Forms.Button();
            this.button123 = new System.Windows.Forms.Button();
            this.button124 = new System.Windows.Forms.Button();
            this.button125 = new System.Windows.Forms.Button();
            this.button126 = new System.Windows.Forms.Button();
            this.button127 = new System.Windows.Forms.Button();
            this.button128 = new System.Windows.Forms.Button();
            this.button129 = new System.Windows.Forms.Button();
            this.button130 = new System.Windows.Forms.Button();
            this.button131 = new System.Windows.Forms.Button();
            this.button132 = new System.Windows.Forms.Button();
            this.button133 = new System.Windows.Forms.Button();
            this.button134 = new System.Windows.Forms.Button();
            this.button135 = new System.Windows.Forms.Button();
            this.button136 = new System.Windows.Forms.Button();
            this.button137 = new System.Windows.Forms.Button();
            this.button138 = new System.Windows.Forms.Button();
            this.button139 = new System.Windows.Forms.Button();
            this.button140 = new System.Windows.Forms.Button();
            this.button141 = new System.Windows.Forms.Button();
            this.button142 = new System.Windows.Forms.Button();
            this.button143 = new System.Windows.Forms.Button();
            this.button144 = new System.Windows.Forms.Button();
            this.button145 = new System.Windows.Forms.Button();
            this.button146 = new System.Windows.Forms.Button();
            this.button147 = new System.Windows.Forms.Button();
            this.button148 = new System.Windows.Forms.Button();
            this.button149 = new System.Windows.Forms.Button();
            this.button150 = new System.Windows.Forms.Button();
            this.button151 = new System.Windows.Forms.Button();
            this.button152 = new System.Windows.Forms.Button();
            this.button153 = new System.Windows.Forms.Button();
            this.button154 = new System.Windows.Forms.Button();
            this.button155 = new System.Windows.Forms.Button();
            this.button156 = new System.Windows.Forms.Button();
            this.button157 = new System.Windows.Forms.Button();
            this.button158 = new System.Windows.Forms.Button();
            this.button159 = new System.Windows.Forms.Button();
            this.button160 = new System.Windows.Forms.Button();
            this.button161 = new System.Windows.Forms.Button();
            this.button162 = new System.Windows.Forms.Button();
            this.button163 = new System.Windows.Forms.Button();
            this.button164 = new System.Windows.Forms.Button();
            this.button165 = new System.Windows.Forms.Button();
            this.button166 = new System.Windows.Forms.Button();
            this.button167 = new System.Windows.Forms.Button();
            this.button168 = new System.Windows.Forms.Button();
            this.button169 = new System.Windows.Forms.Button();
            this.button170 = new System.Windows.Forms.Button();
            this.button171 = new System.Windows.Forms.Button();
            this.button172 = new System.Windows.Forms.Button();
            this.button173 = new System.Windows.Forms.Button();
            this.button174 = new System.Windows.Forms.Button();
            this.button175 = new System.Windows.Forms.Button();
            this.button176 = new System.Windows.Forms.Button();
            this.button177 = new System.Windows.Forms.Button();
            this.button178 = new System.Windows.Forms.Button();
            this.button179 = new System.Windows.Forms.Button();
            this.button180 = new System.Windows.Forms.Button();
            this.button181 = new System.Windows.Forms.Button();
            this.button182 = new System.Windows.Forms.Button();
            this.button183 = new System.Windows.Forms.Button();
            this.button184 = new System.Windows.Forms.Button();
            this.button185 = new System.Windows.Forms.Button();
            this.button186 = new System.Windows.Forms.Button();
            this.button187 = new System.Windows.Forms.Button();
            this.button188 = new System.Windows.Forms.Button();
            this.button189 = new System.Windows.Forms.Button();
            this.button190 = new System.Windows.Forms.Button();
            this.button191 = new System.Windows.Forms.Button();
            this.button192 = new System.Windows.Forms.Button();
            this.button193 = new System.Windows.Forms.Button();
            this.button194 = new System.Windows.Forms.Button();
            this.button195 = new System.Windows.Forms.Button();
            this.button196 = new System.Windows.Forms.Button();
            this.button197 = new System.Windows.Forms.Button();
            this.button198 = new System.Windows.Forms.Button();
            this.button199 = new System.Windows.Forms.Button();
            this.button200 = new System.Windows.Forms.Button();
            this.button201 = new System.Windows.Forms.Button();
            this.button202 = new System.Windows.Forms.Button();
            this.button203 = new System.Windows.Forms.Button();
            this.button204 = new System.Windows.Forms.Button();
            this.button205 = new System.Windows.Forms.Button();
            this.button206 = new System.Windows.Forms.Button();
            this.button207 = new System.Windows.Forms.Button();
            this.button208 = new System.Windows.Forms.Button();
            this.button209 = new System.Windows.Forms.Button();
            this.button210 = new System.Windows.Forms.Button();
            this.button211 = new System.Windows.Forms.Button();
            this.button212 = new System.Windows.Forms.Button();
            this.button213 = new System.Windows.Forms.Button();
            this.button214 = new System.Windows.Forms.Button();
            this.button215 = new System.Windows.Forms.Button();
            this.button216 = new System.Windows.Forms.Button();
            this.button217 = new System.Windows.Forms.Button();
            this.button218 = new System.Windows.Forms.Button();
            this.button219 = new System.Windows.Forms.Button();
            this.button220 = new System.Windows.Forms.Button();
            this.button221 = new System.Windows.Forms.Button();
            this.button222 = new System.Windows.Forms.Button();
            this.button223 = new System.Windows.Forms.Button();
            this.button224 = new System.Windows.Forms.Button();
            this.button225 = new System.Windows.Forms.Button();
            this.button226 = new System.Windows.Forms.Button();
            this.button227 = new System.Windows.Forms.Button();
            this.button228 = new System.Windows.Forms.Button();
            this.button229 = new System.Windows.Forms.Button();
            this.button230 = new System.Windows.Forms.Button();
            this.button231 = new System.Windows.Forms.Button();
            this.button232 = new System.Windows.Forms.Button();
            this.button233 = new System.Windows.Forms.Button();
            this.button234 = new System.Windows.Forms.Button();
            this.button235 = new System.Windows.Forms.Button();
            this.button236 = new System.Windows.Forms.Button();
            this.button237 = new System.Windows.Forms.Button();
            this.button238 = new System.Windows.Forms.Button();
            this.button239 = new System.Windows.Forms.Button();
            this.button240 = new System.Windows.Forms.Button();
            this.button241 = new System.Windows.Forms.Button();
            this.button242 = new System.Windows.Forms.Button();
            this.button243 = new System.Windows.Forms.Button();
            this.button244 = new System.Windows.Forms.Button();
            this.button245 = new System.Windows.Forms.Button();
            this.button246 = new System.Windows.Forms.Button();
            this.button247 = new System.Windows.Forms.Button();
            this.button248 = new System.Windows.Forms.Button();
            this.button249 = new System.Windows.Forms.Button();
            this.button250 = new System.Windows.Forms.Button();
            this.button251 = new System.Windows.Forms.Button();
            this.button252 = new System.Windows.Forms.Button();
            this.button253 = new System.Windows.Forms.Button();
            this.button254 = new System.Windows.Forms.Button();
            this.button255 = new System.Windows.Forms.Button();
            this.button256 = new System.Windows.Forms.Button();
            this.button257 = new System.Windows.Forms.Button();
            this.button258 = new System.Windows.Forms.Button();
            this.button259 = new System.Windows.Forms.Button();
            this.button260 = new System.Windows.Forms.Button();
            this.button261 = new System.Windows.Forms.Button();
            this.button262 = new System.Windows.Forms.Button();
            this.button263 = new System.Windows.Forms.Button();
            this.button264 = new System.Windows.Forms.Button();
            this.button265 = new System.Windows.Forms.Button();
            this.button266 = new System.Windows.Forms.Button();
            this.button267 = new System.Windows.Forms.Button();
            this.button268 = new System.Windows.Forms.Button();
            this.button269 = new System.Windows.Forms.Button();
            this.button270 = new System.Windows.Forms.Button();
            this.button271 = new System.Windows.Forms.Button();
            this.button272 = new System.Windows.Forms.Button();
            this.button273 = new System.Windows.Forms.Button();
            this.button274 = new System.Windows.Forms.Button();
            this.button275 = new System.Windows.Forms.Button();
            this.button276 = new System.Windows.Forms.Button();
            this.button277 = new System.Windows.Forms.Button();
            this.button278 = new System.Windows.Forms.Button();
            this.button279 = new System.Windows.Forms.Button();
            this.button280 = new System.Windows.Forms.Button();
            this.button281 = new System.Windows.Forms.Button();
            this.button282 = new System.Windows.Forms.Button();
            this.button283 = new System.Windows.Forms.Button();
            this.button284 = new System.Windows.Forms.Button();
            this.button285 = new System.Windows.Forms.Button();
            this.button286 = new System.Windows.Forms.Button();
            this.button287 = new System.Windows.Forms.Button();
            this.button288 = new System.Windows.Forms.Button();
            this.button289 = new System.Windows.Forms.Button();
            this.button290 = new System.Windows.Forms.Button();
            this.button291 = new System.Windows.Forms.Button();
            this.button292 = new System.Windows.Forms.Button();
            this.button293 = new System.Windows.Forms.Button();
            this.button294 = new System.Windows.Forms.Button();
            this.button295 = new System.Windows.Forms.Button();
            this.button296 = new System.Windows.Forms.Button();
            this.button297 = new System.Windows.Forms.Button();
            this.button298 = new System.Windows.Forms.Button();
            this.button299 = new System.Windows.Forms.Button();
            this.button300 = new System.Windows.Forms.Button();
            this.button301 = new System.Windows.Forms.Button();
            this.button302 = new System.Windows.Forms.Button();
            this.button303 = new System.Windows.Forms.Button();
            this.button304 = new System.Windows.Forms.Button();
            this.button305 = new System.Windows.Forms.Button();
            this.button306 = new System.Windows.Forms.Button();
            this.button307 = new System.Windows.Forms.Button();
            this.button308 = new System.Windows.Forms.Button();
            this.button309 = new System.Windows.Forms.Button();
            this.button310 = new System.Windows.Forms.Button();
            this.button311 = new System.Windows.Forms.Button();
            this.button312 = new System.Windows.Forms.Button();
            this.button313 = new System.Windows.Forms.Button();
            this.button314 = new System.Windows.Forms.Button();
            this.button315 = new System.Windows.Forms.Button();
            this.button316 = new System.Windows.Forms.Button();
            this.button317 = new System.Windows.Forms.Button();
            this.button318 = new System.Windows.Forms.Button();
            this.button319 = new System.Windows.Forms.Button();
            this.button320 = new System.Windows.Forms.Button();
            this.button321 = new System.Windows.Forms.Button();
            this.button322 = new System.Windows.Forms.Button();
            this.button323 = new System.Windows.Forms.Button();
            this.button324 = new System.Windows.Forms.Button();
            this.button325 = new System.Windows.Forms.Button();
            this.button326 = new System.Windows.Forms.Button();
            this.button327 = new System.Windows.Forms.Button();
            this.button328 = new System.Windows.Forms.Button();
            this.button329 = new System.Windows.Forms.Button();
            this.button330 = new System.Windows.Forms.Button();
            this.button331 = new System.Windows.Forms.Button();
            this.button332 = new System.Windows.Forms.Button();
            this.button333 = new System.Windows.Forms.Button();
            this.button334 = new System.Windows.Forms.Button();
            this.button335 = new System.Windows.Forms.Button();
            this.button336 = new System.Windows.Forms.Button();
            this.button337 = new System.Windows.Forms.Button();
            this.button338 = new System.Windows.Forms.Button();
            this.button339 = new System.Windows.Forms.Button();
            this.button340 = new System.Windows.Forms.Button();
            this.button341 = new System.Windows.Forms.Button();
            this.button342 = new System.Windows.Forms.Button();
            this.button343 = new System.Windows.Forms.Button();
            this.button344 = new System.Windows.Forms.Button();
            this.button345 = new System.Windows.Forms.Button();
            this.button346 = new System.Windows.Forms.Button();
            this.button347 = new System.Windows.Forms.Button();
            this.button348 = new System.Windows.Forms.Button();
            this.button349 = new System.Windows.Forms.Button();
            this.button350 = new System.Windows.Forms.Button();
            this.button351 = new System.Windows.Forms.Button();
            this.button352 = new System.Windows.Forms.Button();
            this.button353 = new System.Windows.Forms.Button();
            this.button354 = new System.Windows.Forms.Button();
            this.button355 = new System.Windows.Forms.Button();
            this.button356 = new System.Windows.Forms.Button();
            this.button357 = new System.Windows.Forms.Button();
            this.button358 = new System.Windows.Forms.Button();
            this.button359 = new System.Windows.Forms.Button();
            this.button360 = new System.Windows.Forms.Button();
            this.button361 = new System.Windows.Forms.Button();
            this.button362 = new System.Windows.Forms.Button();
            this.button363 = new System.Windows.Forms.Button();
            this.button364 = new System.Windows.Forms.Button();
            this.button365 = new System.Windows.Forms.Button();
            this.button366 = new System.Windows.Forms.Button();
            this.button367 = new System.Windows.Forms.Button();
            this.button368 = new System.Windows.Forms.Button();
            this.button369 = new System.Windows.Forms.Button();
            this.button370 = new System.Windows.Forms.Button();
            this.button371 = new System.Windows.Forms.Button();
            this.button372 = new System.Windows.Forms.Button();
            this.button373 = new System.Windows.Forms.Button();
            this.button374 = new System.Windows.Forms.Button();
            this.button375 = new System.Windows.Forms.Button();
            this.button376 = new System.Windows.Forms.Button();
            this.button377 = new System.Windows.Forms.Button();
            this.button378 = new System.Windows.Forms.Button();
            this.button379 = new System.Windows.Forms.Button();
            this.button380 = new System.Windows.Forms.Button();
            this.button381 = new System.Windows.Forms.Button();
            this.button382 = new System.Windows.Forms.Button();
            this.button383 = new System.Windows.Forms.Button();
            this.button384 = new System.Windows.Forms.Button();
            this.button385 = new System.Windows.Forms.Button();
            this.button386 = new System.Windows.Forms.Button();
            this.button387 = new System.Windows.Forms.Button();
            this.button388 = new System.Windows.Forms.Button();
            this.button389 = new System.Windows.Forms.Button();
            this.button390 = new System.Windows.Forms.Button();
            this.button391 = new System.Windows.Forms.Button();
            this.button392 = new System.Windows.Forms.Button();
            this.button393 = new System.Windows.Forms.Button();
            this.button394 = new System.Windows.Forms.Button();
            this.button395 = new System.Windows.Forms.Button();
            this.button396 = new System.Windows.Forms.Button();
            this.button397 = new System.Windows.Forms.Button();
            this.button398 = new System.Windows.Forms.Button();
            this.button399 = new System.Windows.Forms.Button();
            this.button400 = new System.Windows.Forms.Button();
            this.button401 = new System.Windows.Forms.Button();
            this.button402 = new System.Windows.Forms.Button();
            this.button403 = new System.Windows.Forms.Button();
            this.button404 = new System.Windows.Forms.Button();
            this.button405 = new System.Windows.Forms.Button();
            this.button406 = new System.Windows.Forms.Button();
            this.button407 = new System.Windows.Forms.Button();
            this.button408 = new System.Windows.Forms.Button();
            this.button409 = new System.Windows.Forms.Button();
            this.button410 = new System.Windows.Forms.Button();
            this.button411 = new System.Windows.Forms.Button();
            this.button412 = new System.Windows.Forms.Button();
            this.button413 = new System.Windows.Forms.Button();
            this.button414 = new System.Windows.Forms.Button();
            this.button415 = new System.Windows.Forms.Button();
            this.button416 = new System.Windows.Forms.Button();
            this.button417 = new System.Windows.Forms.Button();
            this.button418 = new System.Windows.Forms.Button();
            this.button419 = new System.Windows.Forms.Button();
            this.button420 = new System.Windows.Forms.Button();
            this.button421 = new System.Windows.Forms.Button();
            this.button422 = new System.Windows.Forms.Button();
            this.button423 = new System.Windows.Forms.Button();
            this.button424 = new System.Windows.Forms.Button();
            this.button425 = new System.Windows.Forms.Button();
            this.button426 = new System.Windows.Forms.Button();
            this.button427 = new System.Windows.Forms.Button();
            this.button428 = new System.Windows.Forms.Button();
            this.button429 = new System.Windows.Forms.Button();
            this.button430 = new System.Windows.Forms.Button();
            this.button431 = new System.Windows.Forms.Button();
            this.button432 = new System.Windows.Forms.Button();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(539, 15);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(30, 33);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(569, 15);
            this.button2.Margin = new System.Windows.Forms.Padding(0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(30, 33);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(599, 15);
            this.button3.Margin = new System.Windows.Forms.Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(30, 33);
            this.button3.TabIndex = 2;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(629, 15);
            this.button4.Margin = new System.Windows.Forms.Padding(0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(30, 33);
            this.button4.TabIndex = 3;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(659, 15);
            this.button5.Margin = new System.Windows.Forms.Padding(0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(30, 33);
            this.button5.TabIndex = 4;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(689, 15);
            this.button6.Margin = new System.Windows.Forms.Padding(0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(30, 33);
            this.button6.TabIndex = 5;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(719, 15);
            this.button7.Margin = new System.Windows.Forms.Padding(0);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(30, 33);
            this.button7.TabIndex = 6;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(749, 15);
            this.button8.Margin = new System.Windows.Forms.Padding(0);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(30, 33);
            this.button8.TabIndex = 7;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(539, 48);
            this.button9.Margin = new System.Windows.Forms.Padding(0);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(30, 33);
            this.button9.TabIndex = 8;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(569, 48);
            this.button10.Margin = new System.Windows.Forms.Padding(0);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(30, 33);
            this.button10.TabIndex = 9;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(599, 48);
            this.button11.Margin = new System.Windows.Forms.Padding(0);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(30, 33);
            this.button11.TabIndex = 10;
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(629, 48);
            this.button12.Margin = new System.Windows.Forms.Padding(0);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(30, 33);
            this.button12.TabIndex = 11;
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(659, 48);
            this.button13.Margin = new System.Windows.Forms.Padding(0);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(30, 33);
            this.button13.TabIndex = 12;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(689, 48);
            this.button14.Margin = new System.Windows.Forms.Padding(0);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(30, 33);
            this.button14.TabIndex = 13;
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(719, 48);
            this.button15.Margin = new System.Windows.Forms.Padding(0);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(30, 33);
            this.button15.TabIndex = 14;
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(749, 48);
            this.button16.Margin = new System.Windows.Forms.Padding(0);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(30, 33);
            this.button16.TabIndex = 15;
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(539, 81);
            this.button17.Margin = new System.Windows.Forms.Padding(0);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(30, 33);
            this.button17.TabIndex = 16;
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(569, 81);
            this.button18.Margin = new System.Windows.Forms.Padding(0);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(30, 33);
            this.button18.TabIndex = 17;
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(599, 81);
            this.button19.Margin = new System.Windows.Forms.Padding(0);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(30, 33);
            this.button19.TabIndex = 18;
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(629, 81);
            this.button20.Margin = new System.Windows.Forms.Padding(0);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(30, 33);
            this.button20.TabIndex = 19;
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(659, 81);
            this.button21.Margin = new System.Windows.Forms.Padding(0);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(30, 33);
            this.button21.TabIndex = 20;
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(689, 81);
            this.button22.Margin = new System.Windows.Forms.Padding(0);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(30, 33);
            this.button22.TabIndex = 21;
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(719, 81);
            this.button23.Margin = new System.Windows.Forms.Padding(0);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(30, 33);
            this.button23.TabIndex = 22;
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(749, 81);
            this.button24.Margin = new System.Windows.Forms.Padding(0);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(30, 33);
            this.button24.TabIndex = 23;
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(539, 114);
            this.button25.Margin = new System.Windows.Forms.Padding(0);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(30, 33);
            this.button25.TabIndex = 24;
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(569, 114);
            this.button26.Margin = new System.Windows.Forms.Padding(0);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(30, 33);
            this.button26.TabIndex = 25;
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(599, 114);
            this.button27.Margin = new System.Windows.Forms.Padding(0);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(30, 33);
            this.button27.TabIndex = 26;
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(629, 114);
            this.button28.Margin = new System.Windows.Forms.Padding(0);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(30, 33);
            this.button28.TabIndex = 27;
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(659, 114);
            this.button29.Margin = new System.Windows.Forms.Padding(0);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(30, 33);
            this.button29.TabIndex = 28;
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(689, 114);
            this.button30.Margin = new System.Windows.Forms.Padding(0);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(30, 33);
            this.button30.TabIndex = 29;
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(719, 114);
            this.button31.Margin = new System.Windows.Forms.Padding(0);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(30, 33);
            this.button31.TabIndex = 30;
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(749, 114);
            this.button32.Margin = new System.Windows.Forms.Padding(0);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(30, 33);
            this.button32.TabIndex = 31;
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(539, 147);
            this.button33.Margin = new System.Windows.Forms.Padding(0);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(30, 33);
            this.button33.TabIndex = 32;
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(569, 147);
            this.button34.Margin = new System.Windows.Forms.Padding(0);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(30, 33);
            this.button34.TabIndex = 33;
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(599, 147);
            this.button35.Margin = new System.Windows.Forms.Padding(0);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(30, 33);
            this.button35.TabIndex = 34;
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(629, 147);
            this.button36.Margin = new System.Windows.Forms.Padding(0);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(30, 33);
            this.button36.TabIndex = 35;
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(659, 147);
            this.button37.Margin = new System.Windows.Forms.Padding(0);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(30, 33);
            this.button37.TabIndex = 36;
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(689, 147);
            this.button38.Margin = new System.Windows.Forms.Padding(0);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(30, 33);
            this.button38.TabIndex = 37;
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(719, 147);
            this.button39.Margin = new System.Windows.Forms.Padding(0);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(30, 33);
            this.button39.TabIndex = 38;
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(749, 147);
            this.button40.Margin = new System.Windows.Forms.Padding(0);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(30, 33);
            this.button40.TabIndex = 39;
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(539, 180);
            this.button41.Margin = new System.Windows.Forms.Padding(0);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(30, 33);
            this.button41.TabIndex = 40;
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(569, 180);
            this.button42.Margin = new System.Windows.Forms.Padding(0);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(30, 33);
            this.button42.TabIndex = 41;
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(599, 180);
            this.button43.Margin = new System.Windows.Forms.Padding(0);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(30, 33);
            this.button43.TabIndex = 42;
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(629, 180);
            this.button44.Margin = new System.Windows.Forms.Padding(0);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(30, 33);
            this.button44.TabIndex = 42;
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(659, 180);
            this.button45.Margin = new System.Windows.Forms.Padding(0);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(30, 33);
            this.button45.TabIndex = 43;
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(689, 180);
            this.button46.Margin = new System.Windows.Forms.Padding(0);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(30, 33);
            this.button46.TabIndex = 44;
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(719, 180);
            this.button47.Margin = new System.Windows.Forms.Padding(0);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(30, 33);
            this.button47.TabIndex = 45;
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(749, 180);
            this.button48.Margin = new System.Windows.Forms.Padding(0);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(30, 33);
            this.button48.TabIndex = 46;
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(8, 180);
            this.saveButton.Margin = new System.Windows.Forms.Padding(0);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(96, 60);
            this.saveButton.TabIndex = 47;
            this.saveButton.Text = "Save and Exit";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(9, 46);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(46, 17);
            this.radioButton1.TabIndex = 48;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Wall";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(9, 23);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(57, 17);
            this.radioButton2.TabIndex = 49;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Enemy";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(9, 92);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(48, 17);
            this.radioButton3.TabIndex = 50;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Hero";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(539, 222);
            this.button49.Margin = new System.Windows.Forms.Padding(0);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(30, 33);
            this.button49.TabIndex = 98;
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(569, 222);
            this.button50.Margin = new System.Windows.Forms.Padding(0);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(30, 33);
            this.button50.TabIndex = 97;
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(599, 222);
            this.button51.Margin = new System.Windows.Forms.Padding(0);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(30, 33);
            this.button51.TabIndex = 96;
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Click += new System.EventHandler(this.button51_Click);
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(629, 222);
            this.button52.Margin = new System.Windows.Forms.Padding(0);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(30, 33);
            this.button52.TabIndex = 95;
            this.button52.UseVisualStyleBackColor = true;
            this.button52.Click += new System.EventHandler(this.button52_Click);
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(659, 222);
            this.button53.Margin = new System.Windows.Forms.Padding(0);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(30, 33);
            this.button53.TabIndex = 94;
            this.button53.UseVisualStyleBackColor = true;
            this.button53.Click += new System.EventHandler(this.button53_Click);
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(689, 222);
            this.button54.Margin = new System.Windows.Forms.Padding(0);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(30, 33);
            this.button54.TabIndex = 93;
            this.button54.UseVisualStyleBackColor = true;
            this.button54.Click += new System.EventHandler(this.button54_Click);
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(719, 222);
            this.button55.Margin = new System.Windows.Forms.Padding(0);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(30, 33);
            this.button55.TabIndex = 92;
            this.button55.UseVisualStyleBackColor = true;
            this.button55.Click += new System.EventHandler(this.button55_Click);
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(749, 222);
            this.button56.Margin = new System.Windows.Forms.Padding(0);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(30, 33);
            this.button56.TabIndex = 91;
            this.button56.UseVisualStyleBackColor = true;
            this.button56.Click += new System.EventHandler(this.button56_Click);
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(539, 255);
            this.button57.Margin = new System.Windows.Forms.Padding(0);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(30, 33);
            this.button57.TabIndex = 90;
            this.button57.UseVisualStyleBackColor = true;
            this.button57.Click += new System.EventHandler(this.button57_Click);
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(569, 255);
            this.button58.Margin = new System.Windows.Forms.Padding(0);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(30, 33);
            this.button58.TabIndex = 89;
            this.button58.UseVisualStyleBackColor = true;
            this.button58.Click += new System.EventHandler(this.button58_Click);
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(599, 255);
            this.button59.Margin = new System.Windows.Forms.Padding(0);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(30, 33);
            this.button59.TabIndex = 88;
            this.button59.UseVisualStyleBackColor = true;
            this.button59.Click += new System.EventHandler(this.button59_Click);
            // 
            // button60
            // 
            this.button60.Location = new System.Drawing.Point(629, 255);
            this.button60.Margin = new System.Windows.Forms.Padding(0);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(30, 33);
            this.button60.TabIndex = 87;
            this.button60.UseVisualStyleBackColor = true;
            this.button60.Click += new System.EventHandler(this.button60_Click);
            // 
            // button61
            // 
            this.button61.Location = new System.Drawing.Point(659, 255);
            this.button61.Margin = new System.Windows.Forms.Padding(0);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(30, 33);
            this.button61.TabIndex = 86;
            this.button61.UseVisualStyleBackColor = true;
            this.button61.Click += new System.EventHandler(this.button61_Click);
            // 
            // button62
            // 
            this.button62.Location = new System.Drawing.Point(689, 255);
            this.button62.Margin = new System.Windows.Forms.Padding(0);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(30, 33);
            this.button62.TabIndex = 85;
            this.button62.UseVisualStyleBackColor = true;
            this.button62.Click += new System.EventHandler(this.button62_Click);
            // 
            // button63
            // 
            this.button63.Location = new System.Drawing.Point(719, 255);
            this.button63.Margin = new System.Windows.Forms.Padding(0);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(30, 33);
            this.button63.TabIndex = 84;
            this.button63.UseVisualStyleBackColor = true;
            this.button63.Click += new System.EventHandler(this.button63_Click);
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(749, 255);
            this.button64.Margin = new System.Windows.Forms.Padding(0);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(30, 33);
            this.button64.TabIndex = 83;
            this.button64.UseVisualStyleBackColor = true;
            this.button64.Click += new System.EventHandler(this.button64_Click);
            // 
            // button65
            // 
            this.button65.Location = new System.Drawing.Point(539, 288);
            this.button65.Margin = new System.Windows.Forms.Padding(0);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(30, 33);
            this.button65.TabIndex = 82;
            this.button65.UseVisualStyleBackColor = true;
            this.button65.Click += new System.EventHandler(this.button65_Click);
            // 
            // button66
            // 
            this.button66.Location = new System.Drawing.Point(569, 288);
            this.button66.Margin = new System.Windows.Forms.Padding(0);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(30, 33);
            this.button66.TabIndex = 81;
            this.button66.UseVisualStyleBackColor = true;
            this.button66.Click += new System.EventHandler(this.button66_Click);
            // 
            // button67
            // 
            this.button67.Location = new System.Drawing.Point(599, 288);
            this.button67.Margin = new System.Windows.Forms.Padding(0);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(30, 33);
            this.button67.TabIndex = 80;
            this.button67.UseVisualStyleBackColor = true;
            this.button67.Click += new System.EventHandler(this.button67_Click);
            // 
            // button68
            // 
            this.button68.Location = new System.Drawing.Point(629, 288);
            this.button68.Margin = new System.Windows.Forms.Padding(0);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(30, 33);
            this.button68.TabIndex = 79;
            this.button68.UseVisualStyleBackColor = true;
            this.button68.Click += new System.EventHandler(this.button68_Click);
            // 
            // button69
            // 
            this.button69.Location = new System.Drawing.Point(659, 288);
            this.button69.Margin = new System.Windows.Forms.Padding(0);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(30, 33);
            this.button69.TabIndex = 78;
            this.button69.UseVisualStyleBackColor = true;
            this.button69.Click += new System.EventHandler(this.button69_Click);
            // 
            // button70
            // 
            this.button70.Location = new System.Drawing.Point(689, 288);
            this.button70.Margin = new System.Windows.Forms.Padding(0);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(30, 33);
            this.button70.TabIndex = 77;
            this.button70.UseVisualStyleBackColor = true;
            this.button70.Click += new System.EventHandler(this.button70_Click);
            // 
            // button71
            // 
            this.button71.Location = new System.Drawing.Point(719, 288);
            this.button71.Margin = new System.Windows.Forms.Padding(0);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(30, 33);
            this.button71.TabIndex = 76;
            this.button71.UseVisualStyleBackColor = true;
            this.button71.Click += new System.EventHandler(this.button71_Click);
            // 
            // button72
            // 
            this.button72.Location = new System.Drawing.Point(749, 288);
            this.button72.Margin = new System.Windows.Forms.Padding(0);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(30, 33);
            this.button72.TabIndex = 75;
            this.button72.UseVisualStyleBackColor = true;
            this.button72.Click += new System.EventHandler(this.button72_Click);
            // 
            // button73
            // 
            this.button73.Location = new System.Drawing.Point(539, 321);
            this.button73.Margin = new System.Windows.Forms.Padding(0);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(30, 33);
            this.button73.TabIndex = 74;
            this.button73.UseVisualStyleBackColor = true;
            this.button73.Click += new System.EventHandler(this.button73_Click);
            // 
            // button74
            // 
            this.button74.Location = new System.Drawing.Point(569, 321);
            this.button74.Margin = new System.Windows.Forms.Padding(0);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(30, 33);
            this.button74.TabIndex = 73;
            this.button74.UseVisualStyleBackColor = true;
            this.button74.Click += new System.EventHandler(this.button74_Click);
            // 
            // button75
            // 
            this.button75.Location = new System.Drawing.Point(599, 321);
            this.button75.Margin = new System.Windows.Forms.Padding(0);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(30, 33);
            this.button75.TabIndex = 72;
            this.button75.UseVisualStyleBackColor = true;
            this.button75.Click += new System.EventHandler(this.button75_Click);
            // 
            // button76
            // 
            this.button76.Location = new System.Drawing.Point(629, 321);
            this.button76.Margin = new System.Windows.Forms.Padding(0);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(30, 33);
            this.button76.TabIndex = 71;
            this.button76.UseVisualStyleBackColor = true;
            this.button76.Click += new System.EventHandler(this.button76_Click);
            // 
            // button77
            // 
            this.button77.Location = new System.Drawing.Point(659, 321);
            this.button77.Margin = new System.Windows.Forms.Padding(0);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(30, 33);
            this.button77.TabIndex = 70;
            this.button77.UseVisualStyleBackColor = true;
            this.button77.Click += new System.EventHandler(this.button77_Click);
            // 
            // button78
            // 
            this.button78.Location = new System.Drawing.Point(689, 321);
            this.button78.Margin = new System.Windows.Forms.Padding(0);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(30, 33);
            this.button78.TabIndex = 69;
            this.button78.UseVisualStyleBackColor = true;
            this.button78.Click += new System.EventHandler(this.button78_Click);
            // 
            // button79
            // 
            this.button79.Location = new System.Drawing.Point(719, 321);
            this.button79.Margin = new System.Windows.Forms.Padding(0);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(30, 33);
            this.button79.TabIndex = 68;
            this.button79.UseVisualStyleBackColor = true;
            this.button79.Click += new System.EventHandler(this.button79_Click);
            // 
            // button80
            // 
            this.button80.Location = new System.Drawing.Point(749, 321);
            this.button80.Margin = new System.Windows.Forms.Padding(0);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(30, 33);
            this.button80.TabIndex = 67;
            this.button80.UseVisualStyleBackColor = true;
            this.button80.Click += new System.EventHandler(this.button80_Click);
            // 
            // button81
            // 
            this.button81.Location = new System.Drawing.Point(539, 354);
            this.button81.Margin = new System.Windows.Forms.Padding(0);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(30, 33);
            this.button81.TabIndex = 66;
            this.button81.UseVisualStyleBackColor = true;
            this.button81.Click += new System.EventHandler(this.button81_Click);
            // 
            // button82
            // 
            this.button82.Location = new System.Drawing.Point(569, 354);
            this.button82.Margin = new System.Windows.Forms.Padding(0);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(30, 33);
            this.button82.TabIndex = 65;
            this.button82.UseVisualStyleBackColor = true;
            this.button82.Click += new System.EventHandler(this.button82_Click);
            // 
            // button83
            // 
            this.button83.Location = new System.Drawing.Point(599, 354);
            this.button83.Margin = new System.Windows.Forms.Padding(0);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(30, 33);
            this.button83.TabIndex = 64;
            this.button83.UseVisualStyleBackColor = true;
            this.button83.Click += new System.EventHandler(this.button83_Click);
            // 
            // button84
            // 
            this.button84.Location = new System.Drawing.Point(629, 354);
            this.button84.Margin = new System.Windows.Forms.Padding(0);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(30, 33);
            this.button84.TabIndex = 63;
            this.button84.UseVisualStyleBackColor = true;
            this.button84.Click += new System.EventHandler(this.button84_Click);
            // 
            // button85
            // 
            this.button85.Location = new System.Drawing.Point(659, 354);
            this.button85.Margin = new System.Windows.Forms.Padding(0);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(30, 33);
            this.button85.TabIndex = 62;
            this.button85.UseVisualStyleBackColor = true;
            this.button85.Click += new System.EventHandler(this.button85_Click);
            // 
            // button86
            // 
            this.button86.Location = new System.Drawing.Point(689, 354);
            this.button86.Margin = new System.Windows.Forms.Padding(0);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(30, 33);
            this.button86.TabIndex = 61;
            this.button86.UseVisualStyleBackColor = true;
            this.button86.Click += new System.EventHandler(this.button86_Click);
            // 
            // button87
            // 
            this.button87.Location = new System.Drawing.Point(719, 354);
            this.button87.Margin = new System.Windows.Forms.Padding(0);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(30, 33);
            this.button87.TabIndex = 60;
            this.button87.UseVisualStyleBackColor = true;
            this.button87.Click += new System.EventHandler(this.button87_Click);
            // 
            // button88
            // 
            this.button88.Location = new System.Drawing.Point(749, 354);
            this.button88.Margin = new System.Windows.Forms.Padding(0);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(30, 33);
            this.button88.TabIndex = 59;
            this.button88.UseVisualStyleBackColor = true;
            this.button88.Click += new System.EventHandler(this.button88_Click);
            // 
            // button89
            // 
            this.button89.Location = new System.Drawing.Point(539, 387);
            this.button89.Margin = new System.Windows.Forms.Padding(0);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(30, 33);
            this.button89.TabIndex = 58;
            this.button89.UseVisualStyleBackColor = true;
            this.button89.Click += new System.EventHandler(this.button89_Click);
            // 
            // button90
            // 
            this.button90.Location = new System.Drawing.Point(569, 387);
            this.button90.Margin = new System.Windows.Forms.Padding(0);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(30, 33);
            this.button90.TabIndex = 57;
            this.button90.UseVisualStyleBackColor = true;
            this.button90.Click += new System.EventHandler(this.button90_Click);
            // 
            // button91
            // 
            this.button91.Location = new System.Drawing.Point(599, 387);
            this.button91.Margin = new System.Windows.Forms.Padding(0);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(30, 33);
            this.button91.TabIndex = 56;
            this.button91.UseVisualStyleBackColor = true;
            this.button91.Click += new System.EventHandler(this.button91_Click);
            // 
            // button92
            // 
            this.button92.Location = new System.Drawing.Point(629, 387);
            this.button92.Margin = new System.Windows.Forms.Padding(0);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(30, 33);
            this.button92.TabIndex = 55;
            this.button92.UseVisualStyleBackColor = true;
            this.button92.Click += new System.EventHandler(this.button92_Click);
            // 
            // button93
            // 
            this.button93.Location = new System.Drawing.Point(659, 387);
            this.button93.Margin = new System.Windows.Forms.Padding(0);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(30, 33);
            this.button93.TabIndex = 54;
            this.button93.UseVisualStyleBackColor = true;
            this.button93.Click += new System.EventHandler(this.button93_Click);
            // 
            // button94
            // 
            this.button94.Location = new System.Drawing.Point(689, 387);
            this.button94.Margin = new System.Windows.Forms.Padding(0);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(30, 33);
            this.button94.TabIndex = 53;
            this.button94.UseVisualStyleBackColor = true;
            this.button94.Click += new System.EventHandler(this.button94_Click);
            // 
            // button95
            // 
            this.button95.Location = new System.Drawing.Point(719, 387);
            this.button95.Margin = new System.Windows.Forms.Padding(0);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(30, 33);
            this.button95.TabIndex = 52;
            this.button95.UseVisualStyleBackColor = true;
            this.button95.Click += new System.EventHandler(this.button95_Click);
            // 
            // button96
            // 
            this.button96.Location = new System.Drawing.Point(749, 387);
            this.button96.Margin = new System.Windows.Forms.Padding(0);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(30, 33);
            this.button96.TabIndex = 51;
            this.button96.UseVisualStyleBackColor = true;
            this.button96.Click += new System.EventHandler(this.button96_Click);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(9, 69);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(48, 17);
            this.radioButton4.TabIndex = 99;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Floor";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // button97
            // 
            this.button97.Location = new System.Drawing.Point(539, 436);
            this.button97.Margin = new System.Windows.Forms.Padding(0);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(30, 33);
            this.button97.TabIndex = 147;
            this.button97.UseVisualStyleBackColor = true;
            this.button97.Click += new System.EventHandler(this.button97_Click);
            // 
            // button98
            // 
            this.button98.Location = new System.Drawing.Point(569, 436);
            this.button98.Margin = new System.Windows.Forms.Padding(0);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(30, 33);
            this.button98.TabIndex = 146;
            this.button98.UseVisualStyleBackColor = true;
            this.button98.Click += new System.EventHandler(this.button98_Click);
            // 
            // button99
            // 
            this.button99.Location = new System.Drawing.Point(599, 436);
            this.button99.Margin = new System.Windows.Forms.Padding(0);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(30, 33);
            this.button99.TabIndex = 145;
            this.button99.UseVisualStyleBackColor = true;
            this.button99.Click += new System.EventHandler(this.button99_Click);
            // 
            // button100
            // 
            this.button100.Location = new System.Drawing.Point(629, 436);
            this.button100.Margin = new System.Windows.Forms.Padding(0);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(30, 33);
            this.button100.TabIndex = 144;
            this.button100.UseVisualStyleBackColor = true;
            this.button100.Click += new System.EventHandler(this.button100_Click);
            // 
            // button101
            // 
            this.button101.Location = new System.Drawing.Point(659, 436);
            this.button101.Margin = new System.Windows.Forms.Padding(0);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(30, 33);
            this.button101.TabIndex = 143;
            this.button101.UseVisualStyleBackColor = true;
            this.button101.Click += new System.EventHandler(this.button101_Click);
            // 
            // button102
            // 
            this.button102.Location = new System.Drawing.Point(689, 436);
            this.button102.Margin = new System.Windows.Forms.Padding(0);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(30, 33);
            this.button102.TabIndex = 142;
            this.button102.UseVisualStyleBackColor = true;
            this.button102.Click += new System.EventHandler(this.button102_Click);
            // 
            // button103
            // 
            this.button103.Location = new System.Drawing.Point(719, 436);
            this.button103.Margin = new System.Windows.Forms.Padding(0);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(30, 33);
            this.button103.TabIndex = 141;
            this.button103.UseVisualStyleBackColor = true;
            this.button103.Click += new System.EventHandler(this.button103_Click);
            // 
            // button104
            // 
            this.button104.Location = new System.Drawing.Point(749, 436);
            this.button104.Margin = new System.Windows.Forms.Padding(0);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(30, 33);
            this.button104.TabIndex = 140;
            this.button104.UseVisualStyleBackColor = true;
            this.button104.Click += new System.EventHandler(this.button104_Click);
            // 
            // button105
            // 
            this.button105.Location = new System.Drawing.Point(539, 469);
            this.button105.Margin = new System.Windows.Forms.Padding(0);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(30, 33);
            this.button105.TabIndex = 139;
            this.button105.UseVisualStyleBackColor = true;
            this.button105.Click += new System.EventHandler(this.button105_Click);
            // 
            // button106
            // 
            this.button106.Location = new System.Drawing.Point(569, 469);
            this.button106.Margin = new System.Windows.Forms.Padding(0);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(30, 33);
            this.button106.TabIndex = 138;
            this.button106.UseVisualStyleBackColor = true;
            this.button106.Click += new System.EventHandler(this.button106_Click);
            // 
            // button107
            // 
            this.button107.Location = new System.Drawing.Point(599, 469);
            this.button107.Margin = new System.Windows.Forms.Padding(0);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(30, 33);
            this.button107.TabIndex = 137;
            this.button107.UseVisualStyleBackColor = true;
            this.button107.Click += new System.EventHandler(this.button107_Click);
            // 
            // button108
            // 
            this.button108.Location = new System.Drawing.Point(629, 469);
            this.button108.Margin = new System.Windows.Forms.Padding(0);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(30, 33);
            this.button108.TabIndex = 136;
            this.button108.UseVisualStyleBackColor = true;
            this.button108.Click += new System.EventHandler(this.button108_Click);
            // 
            // button109
            // 
            this.button109.Location = new System.Drawing.Point(659, 469);
            this.button109.Margin = new System.Windows.Forms.Padding(0);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(30, 33);
            this.button109.TabIndex = 135;
            this.button109.UseVisualStyleBackColor = true;
            this.button109.Click += new System.EventHandler(this.button109_Click);
            // 
            // button110
            // 
            this.button110.Location = new System.Drawing.Point(689, 469);
            this.button110.Margin = new System.Windows.Forms.Padding(0);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(30, 33);
            this.button110.TabIndex = 134;
            this.button110.UseVisualStyleBackColor = true;
            this.button110.Click += new System.EventHandler(this.button110_Click);
            // 
            // button111
            // 
            this.button111.Location = new System.Drawing.Point(719, 469);
            this.button111.Margin = new System.Windows.Forms.Padding(0);
            this.button111.Name = "button111";
            this.button111.Size = new System.Drawing.Size(30, 33);
            this.button111.TabIndex = 133;
            this.button111.UseVisualStyleBackColor = true;
            this.button111.Click += new System.EventHandler(this.button111_Click);
            // 
            // button112
            // 
            this.button112.Location = new System.Drawing.Point(749, 469);
            this.button112.Margin = new System.Windows.Forms.Padding(0);
            this.button112.Name = "button112";
            this.button112.Size = new System.Drawing.Size(30, 33);
            this.button112.TabIndex = 132;
            this.button112.UseVisualStyleBackColor = true;
            this.button112.Click += new System.EventHandler(this.button112_Click);
            // 
            // button113
            // 
            this.button113.Location = new System.Drawing.Point(539, 502);
            this.button113.Margin = new System.Windows.Forms.Padding(0);
            this.button113.Name = "button113";
            this.button113.Size = new System.Drawing.Size(30, 33);
            this.button113.TabIndex = 131;
            this.button113.UseVisualStyleBackColor = true;
            this.button113.Click += new System.EventHandler(this.button113_Click);
            // 
            // button114
            // 
            this.button114.Location = new System.Drawing.Point(569, 502);
            this.button114.Margin = new System.Windows.Forms.Padding(0);
            this.button114.Name = "button114";
            this.button114.Size = new System.Drawing.Size(30, 33);
            this.button114.TabIndex = 130;
            this.button114.UseVisualStyleBackColor = true;
            this.button114.Click += new System.EventHandler(this.button114_Click);
            // 
            // button115
            // 
            this.button115.Location = new System.Drawing.Point(599, 502);
            this.button115.Margin = new System.Windows.Forms.Padding(0);
            this.button115.Name = "button115";
            this.button115.Size = new System.Drawing.Size(30, 33);
            this.button115.TabIndex = 129;
            this.button115.UseVisualStyleBackColor = true;
            this.button115.Click += new System.EventHandler(this.button115_Click);
            // 
            // button116
            // 
            this.button116.Location = new System.Drawing.Point(629, 502);
            this.button116.Margin = new System.Windows.Forms.Padding(0);
            this.button116.Name = "button116";
            this.button116.Size = new System.Drawing.Size(30, 33);
            this.button116.TabIndex = 128;
            this.button116.UseVisualStyleBackColor = true;
            this.button116.Click += new System.EventHandler(this.button116_Click);
            // 
            // button117
            // 
            this.button117.Location = new System.Drawing.Point(659, 502);
            this.button117.Margin = new System.Windows.Forms.Padding(0);
            this.button117.Name = "button117";
            this.button117.Size = new System.Drawing.Size(30, 33);
            this.button117.TabIndex = 127;
            this.button117.UseVisualStyleBackColor = true;
            this.button117.Click += new System.EventHandler(this.button117_Click);
            // 
            // button118
            // 
            this.button118.Location = new System.Drawing.Point(689, 502);
            this.button118.Margin = new System.Windows.Forms.Padding(0);
            this.button118.Name = "button118";
            this.button118.Size = new System.Drawing.Size(30, 33);
            this.button118.TabIndex = 126;
            this.button118.UseVisualStyleBackColor = true;
            this.button118.Click += new System.EventHandler(this.button118_Click);
            // 
            // button119
            // 
            this.button119.Location = new System.Drawing.Point(719, 502);
            this.button119.Margin = new System.Windows.Forms.Padding(0);
            this.button119.Name = "button119";
            this.button119.Size = new System.Drawing.Size(30, 33);
            this.button119.TabIndex = 125;
            this.button119.UseVisualStyleBackColor = true;
            this.button119.Click += new System.EventHandler(this.button119_Click);
            // 
            // button120
            // 
            this.button120.Location = new System.Drawing.Point(749, 502);
            this.button120.Margin = new System.Windows.Forms.Padding(0);
            this.button120.Name = "button120";
            this.button120.Size = new System.Drawing.Size(30, 33);
            this.button120.TabIndex = 124;
            this.button120.UseVisualStyleBackColor = true;
            this.button120.Click += new System.EventHandler(this.button120_Click);
            // 
            // button121
            // 
            this.button121.Location = new System.Drawing.Point(539, 535);
            this.button121.Margin = new System.Windows.Forms.Padding(0);
            this.button121.Name = "button121";
            this.button121.Size = new System.Drawing.Size(30, 33);
            this.button121.TabIndex = 123;
            this.button121.UseVisualStyleBackColor = true;
            this.button121.Click += new System.EventHandler(this.button121_Click);
            // 
            // button122
            // 
            this.button122.Location = new System.Drawing.Point(569, 535);
            this.button122.Margin = new System.Windows.Forms.Padding(0);
            this.button122.Name = "button122";
            this.button122.Size = new System.Drawing.Size(30, 33);
            this.button122.TabIndex = 122;
            this.button122.UseVisualStyleBackColor = true;
            this.button122.Click += new System.EventHandler(this.button122_Click);
            // 
            // button123
            // 
            this.button123.Location = new System.Drawing.Point(599, 535);
            this.button123.Margin = new System.Windows.Forms.Padding(0);
            this.button123.Name = "button123";
            this.button123.Size = new System.Drawing.Size(30, 33);
            this.button123.TabIndex = 121;
            this.button123.UseVisualStyleBackColor = true;
            this.button123.Click += new System.EventHandler(this.button123_Click);
            // 
            // button124
            // 
            this.button124.Location = new System.Drawing.Point(629, 535);
            this.button124.Margin = new System.Windows.Forms.Padding(0);
            this.button124.Name = "button124";
            this.button124.Size = new System.Drawing.Size(30, 33);
            this.button124.TabIndex = 120;
            this.button124.UseVisualStyleBackColor = true;
            this.button124.Click += new System.EventHandler(this.button124_Click);
            // 
            // button125
            // 
            this.button125.Location = new System.Drawing.Point(659, 535);
            this.button125.Margin = new System.Windows.Forms.Padding(0);
            this.button125.Name = "button125";
            this.button125.Size = new System.Drawing.Size(30, 33);
            this.button125.TabIndex = 119;
            this.button125.UseVisualStyleBackColor = true;
            this.button125.Click += new System.EventHandler(this.button125_Click);
            // 
            // button126
            // 
            this.button126.Location = new System.Drawing.Point(689, 535);
            this.button126.Margin = new System.Windows.Forms.Padding(0);
            this.button126.Name = "button126";
            this.button126.Size = new System.Drawing.Size(30, 33);
            this.button126.TabIndex = 118;
            this.button126.UseVisualStyleBackColor = true;
            this.button126.Click += new System.EventHandler(this.button126_Click);
            // 
            // button127
            // 
            this.button127.Location = new System.Drawing.Point(719, 535);
            this.button127.Margin = new System.Windows.Forms.Padding(0);
            this.button127.Name = "button127";
            this.button127.Size = new System.Drawing.Size(30, 33);
            this.button127.TabIndex = 117;
            this.button127.UseVisualStyleBackColor = true;
            this.button127.Click += new System.EventHandler(this.button127_Click);
            // 
            // button128
            // 
            this.button128.Location = new System.Drawing.Point(749, 535);
            this.button128.Margin = new System.Windows.Forms.Padding(0);
            this.button128.Name = "button128";
            this.button128.Size = new System.Drawing.Size(30, 33);
            this.button128.TabIndex = 116;
            this.button128.UseVisualStyleBackColor = true;
            this.button128.Click += new System.EventHandler(this.button128_Click);
            // 
            // button129
            // 
            this.button129.Location = new System.Drawing.Point(539, 568);
            this.button129.Margin = new System.Windows.Forms.Padding(0);
            this.button129.Name = "button129";
            this.button129.Size = new System.Drawing.Size(30, 33);
            this.button129.TabIndex = 115;
            this.button129.UseVisualStyleBackColor = true;
            this.button129.Click += new System.EventHandler(this.button129_Click);
            // 
            // button130
            // 
            this.button130.Location = new System.Drawing.Point(569, 568);
            this.button130.Margin = new System.Windows.Forms.Padding(0);
            this.button130.Name = "button130";
            this.button130.Size = new System.Drawing.Size(30, 33);
            this.button130.TabIndex = 114;
            this.button130.UseVisualStyleBackColor = true;
            this.button130.Click += new System.EventHandler(this.button130_Click);
            // 
            // button131
            // 
            this.button131.Location = new System.Drawing.Point(599, 568);
            this.button131.Margin = new System.Windows.Forms.Padding(0);
            this.button131.Name = "button131";
            this.button131.Size = new System.Drawing.Size(30, 33);
            this.button131.TabIndex = 113;
            this.button131.UseVisualStyleBackColor = true;
            this.button131.Click += new System.EventHandler(this.button131_Click);
            // 
            // button132
            // 
            this.button132.Location = new System.Drawing.Point(629, 568);
            this.button132.Margin = new System.Windows.Forms.Padding(0);
            this.button132.Name = "button132";
            this.button132.Size = new System.Drawing.Size(30, 33);
            this.button132.TabIndex = 112;
            this.button132.UseVisualStyleBackColor = true;
            this.button132.Click += new System.EventHandler(this.button132_Click);
            // 
            // button133
            // 
            this.button133.Location = new System.Drawing.Point(659, 568);
            this.button133.Margin = new System.Windows.Forms.Padding(0);
            this.button133.Name = "button133";
            this.button133.Size = new System.Drawing.Size(30, 33);
            this.button133.TabIndex = 111;
            this.button133.UseVisualStyleBackColor = true;
            this.button133.Click += new System.EventHandler(this.button133_Click);
            // 
            // button134
            // 
            this.button134.Location = new System.Drawing.Point(689, 568);
            this.button134.Margin = new System.Windows.Forms.Padding(0);
            this.button134.Name = "button134";
            this.button134.Size = new System.Drawing.Size(30, 33);
            this.button134.TabIndex = 110;
            this.button134.UseVisualStyleBackColor = true;
            this.button134.Click += new System.EventHandler(this.button134_Click);
            // 
            // button135
            // 
            this.button135.Location = new System.Drawing.Point(719, 568);
            this.button135.Margin = new System.Windows.Forms.Padding(0);
            this.button135.Name = "button135";
            this.button135.Size = new System.Drawing.Size(30, 33);
            this.button135.TabIndex = 109;
            this.button135.UseVisualStyleBackColor = true;
            this.button135.Click += new System.EventHandler(this.button135_Click);
            // 
            // button136
            // 
            this.button136.Location = new System.Drawing.Point(749, 568);
            this.button136.Margin = new System.Windows.Forms.Padding(0);
            this.button136.Name = "button136";
            this.button136.Size = new System.Drawing.Size(30, 33);
            this.button136.TabIndex = 108;
            this.button136.UseVisualStyleBackColor = true;
            this.button136.Click += new System.EventHandler(this.button136_Click);
            // 
            // button137
            // 
            this.button137.Location = new System.Drawing.Point(539, 601);
            this.button137.Margin = new System.Windows.Forms.Padding(0);
            this.button137.Name = "button137";
            this.button137.Size = new System.Drawing.Size(30, 33);
            this.button137.TabIndex = 107;
            this.button137.UseVisualStyleBackColor = true;
            this.button137.Click += new System.EventHandler(this.button137_Click);
            // 
            // button138
            // 
            this.button138.Location = new System.Drawing.Point(569, 601);
            this.button138.Margin = new System.Windows.Forms.Padding(0);
            this.button138.Name = "button138";
            this.button138.Size = new System.Drawing.Size(30, 33);
            this.button138.TabIndex = 106;
            this.button138.UseVisualStyleBackColor = true;
            this.button138.Click += new System.EventHandler(this.button138_Click);
            // 
            // button139
            // 
            this.button139.Location = new System.Drawing.Point(599, 601);
            this.button139.Margin = new System.Windows.Forms.Padding(0);
            this.button139.Name = "button139";
            this.button139.Size = new System.Drawing.Size(30, 33);
            this.button139.TabIndex = 105;
            this.button139.UseVisualStyleBackColor = true;
            this.button139.Click += new System.EventHandler(this.button139_Click);
            // 
            // button140
            // 
            this.button140.Location = new System.Drawing.Point(629, 601);
            this.button140.Margin = new System.Windows.Forms.Padding(0);
            this.button140.Name = "button140";
            this.button140.Size = new System.Drawing.Size(30, 33);
            this.button140.TabIndex = 104;
            this.button140.UseVisualStyleBackColor = true;
            this.button140.Click += new System.EventHandler(this.button140_Click);
            // 
            // button141
            // 
            this.button141.Location = new System.Drawing.Point(659, 601);
            this.button141.Margin = new System.Windows.Forms.Padding(0);
            this.button141.Name = "button141";
            this.button141.Size = new System.Drawing.Size(30, 33);
            this.button141.TabIndex = 103;
            this.button141.UseVisualStyleBackColor = true;
            this.button141.Click += new System.EventHandler(this.button141_Click);
            // 
            // button142
            // 
            this.button142.Location = new System.Drawing.Point(689, 601);
            this.button142.Margin = new System.Windows.Forms.Padding(0);
            this.button142.Name = "button142";
            this.button142.Size = new System.Drawing.Size(30, 33);
            this.button142.TabIndex = 102;
            this.button142.UseVisualStyleBackColor = true;
            this.button142.Click += new System.EventHandler(this.button142_Click);
            // 
            // button143
            // 
            this.button143.Location = new System.Drawing.Point(719, 601);
            this.button143.Margin = new System.Windows.Forms.Padding(0);
            this.button143.Name = "button143";
            this.button143.Size = new System.Drawing.Size(30, 33);
            this.button143.TabIndex = 101;
            this.button143.UseVisualStyleBackColor = true;
            this.button143.Click += new System.EventHandler(this.button143_Click);
            // 
            // button144
            // 
            this.button144.Location = new System.Drawing.Point(749, 601);
            this.button144.Margin = new System.Windows.Forms.Padding(0);
            this.button144.Name = "button144";
            this.button144.Size = new System.Drawing.Size(30, 33);
            this.button144.TabIndex = 100;
            this.button144.UseVisualStyleBackColor = true;
            this.button144.Click += new System.EventHandler(this.button144_Click);
            // 
            // button145
            // 
            this.button145.Location = new System.Drawing.Point(539, 644);
            this.button145.Margin = new System.Windows.Forms.Padding(0);
            this.button145.Name = "button145";
            this.button145.Size = new System.Drawing.Size(30, 33);
            this.button145.TabIndex = 195;
            this.button145.UseVisualStyleBackColor = true;
            this.button145.Click += new System.EventHandler(this.button145_Click);
            // 
            // button146
            // 
            this.button146.Location = new System.Drawing.Point(569, 644);
            this.button146.Margin = new System.Windows.Forms.Padding(0);
            this.button146.Name = "button146";
            this.button146.Size = new System.Drawing.Size(30, 33);
            this.button146.TabIndex = 194;
            this.button146.UseVisualStyleBackColor = true;
            this.button146.Click += new System.EventHandler(this.button146_Click);
            // 
            // button147
            // 
            this.button147.Location = new System.Drawing.Point(599, 644);
            this.button147.Margin = new System.Windows.Forms.Padding(0);
            this.button147.Name = "button147";
            this.button147.Size = new System.Drawing.Size(30, 33);
            this.button147.TabIndex = 193;
            this.button147.UseVisualStyleBackColor = true;
            this.button147.Click += new System.EventHandler(this.button147_Click);
            // 
            // button148
            // 
            this.button148.Location = new System.Drawing.Point(629, 644);
            this.button148.Margin = new System.Windows.Forms.Padding(0);
            this.button148.Name = "button148";
            this.button148.Size = new System.Drawing.Size(30, 33);
            this.button148.TabIndex = 192;
            this.button148.UseVisualStyleBackColor = true;
            this.button148.Click += new System.EventHandler(this.button148_Click);
            // 
            // button149
            // 
            this.button149.Location = new System.Drawing.Point(659, 644);
            this.button149.Margin = new System.Windows.Forms.Padding(0);
            this.button149.Name = "button149";
            this.button149.Size = new System.Drawing.Size(30, 33);
            this.button149.TabIndex = 191;
            this.button149.UseVisualStyleBackColor = true;
            this.button149.Click += new System.EventHandler(this.button149_Click);
            // 
            // button150
            // 
            this.button150.Location = new System.Drawing.Point(689, 644);
            this.button150.Margin = new System.Windows.Forms.Padding(0);
            this.button150.Name = "button150";
            this.button150.Size = new System.Drawing.Size(30, 33);
            this.button150.TabIndex = 190;
            this.button150.UseVisualStyleBackColor = true;
            this.button150.Click += new System.EventHandler(this.button150_Click);
            // 
            // button151
            // 
            this.button151.Location = new System.Drawing.Point(719, 644);
            this.button151.Margin = new System.Windows.Forms.Padding(0);
            this.button151.Name = "button151";
            this.button151.Size = new System.Drawing.Size(30, 33);
            this.button151.TabIndex = 189;
            this.button151.UseVisualStyleBackColor = true;
            this.button151.Click += new System.EventHandler(this.button151_Click);
            // 
            // button152
            // 
            this.button152.Location = new System.Drawing.Point(749, 644);
            this.button152.Margin = new System.Windows.Forms.Padding(0);
            this.button152.Name = "button152";
            this.button152.Size = new System.Drawing.Size(30, 33);
            this.button152.TabIndex = 188;
            this.button152.UseVisualStyleBackColor = true;
            this.button152.Click += new System.EventHandler(this.button152_Click);
            // 
            // button153
            // 
            this.button153.Location = new System.Drawing.Point(539, 677);
            this.button153.Margin = new System.Windows.Forms.Padding(0);
            this.button153.Name = "button153";
            this.button153.Size = new System.Drawing.Size(30, 33);
            this.button153.TabIndex = 187;
            this.button153.UseVisualStyleBackColor = true;
            this.button153.Click += new System.EventHandler(this.button153_Click);
            // 
            // button154
            // 
            this.button154.Location = new System.Drawing.Point(569, 677);
            this.button154.Margin = new System.Windows.Forms.Padding(0);
            this.button154.Name = "button154";
            this.button154.Size = new System.Drawing.Size(30, 33);
            this.button154.TabIndex = 186;
            this.button154.UseVisualStyleBackColor = true;
            this.button154.Click += new System.EventHandler(this.button154_Click);
            // 
            // button155
            // 
            this.button155.Location = new System.Drawing.Point(599, 677);
            this.button155.Margin = new System.Windows.Forms.Padding(0);
            this.button155.Name = "button155";
            this.button155.Size = new System.Drawing.Size(30, 33);
            this.button155.TabIndex = 185;
            this.button155.UseVisualStyleBackColor = true;
            this.button155.Click += new System.EventHandler(this.button155_Click);
            // 
            // button156
            // 
            this.button156.Location = new System.Drawing.Point(629, 677);
            this.button156.Margin = new System.Windows.Forms.Padding(0);
            this.button156.Name = "button156";
            this.button156.Size = new System.Drawing.Size(30, 33);
            this.button156.TabIndex = 184;
            this.button156.UseVisualStyleBackColor = true;
            this.button156.Click += new System.EventHandler(this.button156_Click);
            // 
            // button157
            // 
            this.button157.Location = new System.Drawing.Point(659, 677);
            this.button157.Margin = new System.Windows.Forms.Padding(0);
            this.button157.Name = "button157";
            this.button157.Size = new System.Drawing.Size(30, 33);
            this.button157.TabIndex = 183;
            this.button157.UseVisualStyleBackColor = true;
            this.button157.Click += new System.EventHandler(this.button157_Click);
            // 
            // button158
            // 
            this.button158.Location = new System.Drawing.Point(689, 677);
            this.button158.Margin = new System.Windows.Forms.Padding(0);
            this.button158.Name = "button158";
            this.button158.Size = new System.Drawing.Size(30, 33);
            this.button158.TabIndex = 182;
            this.button158.UseVisualStyleBackColor = true;
            this.button158.Click += new System.EventHandler(this.button158_Click);
            // 
            // button159
            // 
            this.button159.Location = new System.Drawing.Point(719, 677);
            this.button159.Margin = new System.Windows.Forms.Padding(0);
            this.button159.Name = "button159";
            this.button159.Size = new System.Drawing.Size(30, 33);
            this.button159.TabIndex = 181;
            this.button159.UseVisualStyleBackColor = true;
            this.button159.Click += new System.EventHandler(this.button159_Click);
            // 
            // button160
            // 
            this.button160.Location = new System.Drawing.Point(749, 677);
            this.button160.Margin = new System.Windows.Forms.Padding(0);
            this.button160.Name = "button160";
            this.button160.Size = new System.Drawing.Size(30, 33);
            this.button160.TabIndex = 180;
            this.button160.UseVisualStyleBackColor = true;
            this.button160.Click += new System.EventHandler(this.button160_Click);
            // 
            // button161
            // 
            this.button161.Location = new System.Drawing.Point(539, 710);
            this.button161.Margin = new System.Windows.Forms.Padding(0);
            this.button161.Name = "button161";
            this.button161.Size = new System.Drawing.Size(30, 33);
            this.button161.TabIndex = 179;
            this.button161.UseVisualStyleBackColor = true;
            this.button161.Click += new System.EventHandler(this.button161_Click);
            // 
            // button162
            // 
            this.button162.Location = new System.Drawing.Point(569, 710);
            this.button162.Margin = new System.Windows.Forms.Padding(0);
            this.button162.Name = "button162";
            this.button162.Size = new System.Drawing.Size(30, 33);
            this.button162.TabIndex = 178;
            this.button162.UseVisualStyleBackColor = true;
            this.button162.Click += new System.EventHandler(this.button162_Click);
            // 
            // button163
            // 
            this.button163.Location = new System.Drawing.Point(599, 710);
            this.button163.Margin = new System.Windows.Forms.Padding(0);
            this.button163.Name = "button163";
            this.button163.Size = new System.Drawing.Size(30, 33);
            this.button163.TabIndex = 177;
            this.button163.UseVisualStyleBackColor = true;
            this.button163.Click += new System.EventHandler(this.button163_Click);
            // 
            // button164
            // 
            this.button164.Location = new System.Drawing.Point(629, 710);
            this.button164.Margin = new System.Windows.Forms.Padding(0);
            this.button164.Name = "button164";
            this.button164.Size = new System.Drawing.Size(30, 33);
            this.button164.TabIndex = 176;
            this.button164.UseVisualStyleBackColor = true;
            this.button164.Click += new System.EventHandler(this.button164_Click);
            // 
            // button165
            // 
            this.button165.Location = new System.Drawing.Point(659, 710);
            this.button165.Margin = new System.Windows.Forms.Padding(0);
            this.button165.Name = "button165";
            this.button165.Size = new System.Drawing.Size(30, 33);
            this.button165.TabIndex = 175;
            this.button165.UseVisualStyleBackColor = true;
            this.button165.Click += new System.EventHandler(this.button165_Click);
            // 
            // button166
            // 
            this.button166.Location = new System.Drawing.Point(689, 710);
            this.button166.Margin = new System.Windows.Forms.Padding(0);
            this.button166.Name = "button166";
            this.button166.Size = new System.Drawing.Size(30, 33);
            this.button166.TabIndex = 174;
            this.button166.UseVisualStyleBackColor = true;
            this.button166.Click += new System.EventHandler(this.button166_Click);
            // 
            // button167
            // 
            this.button167.Location = new System.Drawing.Point(719, 710);
            this.button167.Margin = new System.Windows.Forms.Padding(0);
            this.button167.Name = "button167";
            this.button167.Size = new System.Drawing.Size(30, 33);
            this.button167.TabIndex = 173;
            this.button167.UseVisualStyleBackColor = true;
            this.button167.Click += new System.EventHandler(this.button167_Click);
            // 
            // button168
            // 
            this.button168.Location = new System.Drawing.Point(749, 710);
            this.button168.Margin = new System.Windows.Forms.Padding(0);
            this.button168.Name = "button168";
            this.button168.Size = new System.Drawing.Size(30, 33);
            this.button168.TabIndex = 172;
            this.button168.UseVisualStyleBackColor = true;
            this.button168.Click += new System.EventHandler(this.button168_Click);
            // 
            // button169
            // 
            this.button169.Location = new System.Drawing.Point(539, 743);
            this.button169.Margin = new System.Windows.Forms.Padding(0);
            this.button169.Name = "button169";
            this.button169.Size = new System.Drawing.Size(30, 33);
            this.button169.TabIndex = 171;
            this.button169.UseVisualStyleBackColor = true;
            this.button169.Click += new System.EventHandler(this.button169_Click);
            // 
            // button170
            // 
            this.button170.Location = new System.Drawing.Point(569, 743);
            this.button170.Margin = new System.Windows.Forms.Padding(0);
            this.button170.Name = "button170";
            this.button170.Size = new System.Drawing.Size(30, 33);
            this.button170.TabIndex = 170;
            this.button170.UseVisualStyleBackColor = true;
            this.button170.Click += new System.EventHandler(this.button170_Click);
            // 
            // button171
            // 
            this.button171.Location = new System.Drawing.Point(599, 743);
            this.button171.Margin = new System.Windows.Forms.Padding(0);
            this.button171.Name = "button171";
            this.button171.Size = new System.Drawing.Size(30, 33);
            this.button171.TabIndex = 169;
            this.button171.UseVisualStyleBackColor = true;
            this.button171.Click += new System.EventHandler(this.button171_Click);
            // 
            // button172
            // 
            this.button172.Location = new System.Drawing.Point(629, 743);
            this.button172.Margin = new System.Windows.Forms.Padding(0);
            this.button172.Name = "button172";
            this.button172.Size = new System.Drawing.Size(30, 33);
            this.button172.TabIndex = 168;
            this.button172.UseVisualStyleBackColor = true;
            this.button172.Click += new System.EventHandler(this.button172_Click);
            // 
            // button173
            // 
            this.button173.Location = new System.Drawing.Point(659, 743);
            this.button173.Margin = new System.Windows.Forms.Padding(0);
            this.button173.Name = "button173";
            this.button173.Size = new System.Drawing.Size(30, 33);
            this.button173.TabIndex = 167;
            this.button173.UseVisualStyleBackColor = true;
            this.button173.Click += new System.EventHandler(this.button173_Click);
            // 
            // button174
            // 
            this.button174.Location = new System.Drawing.Point(689, 743);
            this.button174.Margin = new System.Windows.Forms.Padding(0);
            this.button174.Name = "button174";
            this.button174.Size = new System.Drawing.Size(30, 33);
            this.button174.TabIndex = 166;
            this.button174.UseVisualStyleBackColor = true;
            this.button174.Click += new System.EventHandler(this.button174_Click);
            // 
            // button175
            // 
            this.button175.Location = new System.Drawing.Point(719, 743);
            this.button175.Margin = new System.Windows.Forms.Padding(0);
            this.button175.Name = "button175";
            this.button175.Size = new System.Drawing.Size(30, 33);
            this.button175.TabIndex = 165;
            this.button175.UseVisualStyleBackColor = true;
            this.button175.Click += new System.EventHandler(this.button175_Click);
            // 
            // button176
            // 
            this.button176.Location = new System.Drawing.Point(749, 743);
            this.button176.Margin = new System.Windows.Forms.Padding(0);
            this.button176.Name = "button176";
            this.button176.Size = new System.Drawing.Size(30, 33);
            this.button176.TabIndex = 164;
            this.button176.UseVisualStyleBackColor = true;
            this.button176.Click += new System.EventHandler(this.button176_Click);
            // 
            // button177
            // 
            this.button177.Location = new System.Drawing.Point(539, 776);
            this.button177.Margin = new System.Windows.Forms.Padding(0);
            this.button177.Name = "button177";
            this.button177.Size = new System.Drawing.Size(30, 33);
            this.button177.TabIndex = 163;
            this.button177.UseVisualStyleBackColor = true;
            this.button177.Click += new System.EventHandler(this.button177_Click);
            // 
            // button178
            // 
            this.button178.Location = new System.Drawing.Point(569, 776);
            this.button178.Margin = new System.Windows.Forms.Padding(0);
            this.button178.Name = "button178";
            this.button178.Size = new System.Drawing.Size(30, 33);
            this.button178.TabIndex = 162;
            this.button178.UseVisualStyleBackColor = true;
            this.button178.Click += new System.EventHandler(this.button178_Click);
            // 
            // button179
            // 
            this.button179.Location = new System.Drawing.Point(599, 776);
            this.button179.Margin = new System.Windows.Forms.Padding(0);
            this.button179.Name = "button179";
            this.button179.Size = new System.Drawing.Size(30, 33);
            this.button179.TabIndex = 161;
            this.button179.UseVisualStyleBackColor = true;
            this.button179.Click += new System.EventHandler(this.button179_Click);
            // 
            // button180
            // 
            this.button180.Location = new System.Drawing.Point(629, 776);
            this.button180.Margin = new System.Windows.Forms.Padding(0);
            this.button180.Name = "button180";
            this.button180.Size = new System.Drawing.Size(30, 33);
            this.button180.TabIndex = 160;
            this.button180.UseVisualStyleBackColor = true;
            this.button180.Click += new System.EventHandler(this.button180_Click);
            // 
            // button181
            // 
            this.button181.Location = new System.Drawing.Point(659, 776);
            this.button181.Margin = new System.Windows.Forms.Padding(0);
            this.button181.Name = "button181";
            this.button181.Size = new System.Drawing.Size(30, 33);
            this.button181.TabIndex = 159;
            this.button181.UseVisualStyleBackColor = true;
            this.button181.Click += new System.EventHandler(this.button181_Click);
            // 
            // button182
            // 
            this.button182.Location = new System.Drawing.Point(689, 776);
            this.button182.Margin = new System.Windows.Forms.Padding(0);
            this.button182.Name = "button182";
            this.button182.Size = new System.Drawing.Size(30, 33);
            this.button182.TabIndex = 158;
            this.button182.UseVisualStyleBackColor = true;
            this.button182.Click += new System.EventHandler(this.button182_Click);
            // 
            // button183
            // 
            this.button183.Location = new System.Drawing.Point(719, 776);
            this.button183.Margin = new System.Windows.Forms.Padding(0);
            this.button183.Name = "button183";
            this.button183.Size = new System.Drawing.Size(30, 33);
            this.button183.TabIndex = 157;
            this.button183.UseVisualStyleBackColor = true;
            this.button183.Click += new System.EventHandler(this.button183_Click);
            // 
            // button184
            // 
            this.button184.Location = new System.Drawing.Point(749, 776);
            this.button184.Margin = new System.Windows.Forms.Padding(0);
            this.button184.Name = "button184";
            this.button184.Size = new System.Drawing.Size(30, 33);
            this.button184.TabIndex = 156;
            this.button184.UseVisualStyleBackColor = true;
            this.button184.Click += new System.EventHandler(this.button184_Click);
            // 
            // button185
            // 
            this.button185.Location = new System.Drawing.Point(539, 809);
            this.button185.Margin = new System.Windows.Forms.Padding(0);
            this.button185.Name = "button185";
            this.button185.Size = new System.Drawing.Size(30, 33);
            this.button185.TabIndex = 155;
            this.button185.UseVisualStyleBackColor = true;
            this.button185.Click += new System.EventHandler(this.button185_Click);
            // 
            // button186
            // 
            this.button186.Location = new System.Drawing.Point(569, 809);
            this.button186.Margin = new System.Windows.Forms.Padding(0);
            this.button186.Name = "button186";
            this.button186.Size = new System.Drawing.Size(30, 33);
            this.button186.TabIndex = 154;
            this.button186.UseVisualStyleBackColor = true;
            this.button186.Click += new System.EventHandler(this.button186_Click);
            // 
            // button187
            // 
            this.button187.Location = new System.Drawing.Point(599, 809);
            this.button187.Margin = new System.Windows.Forms.Padding(0);
            this.button187.Name = "button187";
            this.button187.Size = new System.Drawing.Size(30, 33);
            this.button187.TabIndex = 153;
            this.button187.UseVisualStyleBackColor = true;
            this.button187.Click += new System.EventHandler(this.button187_Click);
            // 
            // button188
            // 
            this.button188.Location = new System.Drawing.Point(629, 809);
            this.button188.Margin = new System.Windows.Forms.Padding(0);
            this.button188.Name = "button188";
            this.button188.Size = new System.Drawing.Size(30, 33);
            this.button188.TabIndex = 152;
            this.button188.UseVisualStyleBackColor = true;
            this.button188.Click += new System.EventHandler(this.button188_Click);
            // 
            // button189
            // 
            this.button189.Location = new System.Drawing.Point(659, 809);
            this.button189.Margin = new System.Windows.Forms.Padding(0);
            this.button189.Name = "button189";
            this.button189.Size = new System.Drawing.Size(30, 33);
            this.button189.TabIndex = 151;
            this.button189.UseVisualStyleBackColor = true;
            this.button189.Click += new System.EventHandler(this.button189_Click);
            // 
            // button190
            // 
            this.button190.Location = new System.Drawing.Point(689, 809);
            this.button190.Margin = new System.Windows.Forms.Padding(0);
            this.button190.Name = "button190";
            this.button190.Size = new System.Drawing.Size(30, 33);
            this.button190.TabIndex = 150;
            this.button190.UseVisualStyleBackColor = true;
            this.button190.Click += new System.EventHandler(this.button190_Click);
            // 
            // button191
            // 
            this.button191.Location = new System.Drawing.Point(719, 809);
            this.button191.Margin = new System.Windows.Forms.Padding(0);
            this.button191.Name = "button191";
            this.button191.Size = new System.Drawing.Size(30, 33);
            this.button191.TabIndex = 149;
            this.button191.UseVisualStyleBackColor = true;
            this.button191.Click += new System.EventHandler(this.button191_Click);
            // 
            // button192
            // 
            this.button192.Location = new System.Drawing.Point(749, 809);
            this.button192.Margin = new System.Windows.Forms.Padding(0);
            this.button192.Name = "button192";
            this.button192.Size = new System.Drawing.Size(30, 33);
            this.button192.TabIndex = 148;
            this.button192.UseVisualStyleBackColor = true;
            this.button192.Click += new System.EventHandler(this.button192_Click);
            // 
            // button193
            // 
            this.button193.Location = new System.Drawing.Point(539, 854);
            this.button193.Margin = new System.Windows.Forms.Padding(0);
            this.button193.Name = "button193";
            this.button193.Size = new System.Drawing.Size(30, 33);
            this.button193.TabIndex = 243;
            this.button193.UseVisualStyleBackColor = true;
            this.button193.Click += new System.EventHandler(this.button193_Click);
            // 
            // button194
            // 
            this.button194.Location = new System.Drawing.Point(569, 854);
            this.button194.Margin = new System.Windows.Forms.Padding(0);
            this.button194.Name = "button194";
            this.button194.Size = new System.Drawing.Size(30, 33);
            this.button194.TabIndex = 242;
            this.button194.UseVisualStyleBackColor = true;
            this.button194.Click += new System.EventHandler(this.button194_Click);
            // 
            // button195
            // 
            this.button195.Location = new System.Drawing.Point(599, 854);
            this.button195.Margin = new System.Windows.Forms.Padding(0);
            this.button195.Name = "button195";
            this.button195.Size = new System.Drawing.Size(30, 33);
            this.button195.TabIndex = 241;
            this.button195.UseVisualStyleBackColor = true;
            this.button195.Click += new System.EventHandler(this.button195_Click);
            // 
            // button196
            // 
            this.button196.Location = new System.Drawing.Point(629, 854);
            this.button196.Margin = new System.Windows.Forms.Padding(0);
            this.button196.Name = "button196";
            this.button196.Size = new System.Drawing.Size(30, 33);
            this.button196.TabIndex = 240;
            this.button196.UseVisualStyleBackColor = true;
            this.button196.Click += new System.EventHandler(this.button196_Click);
            // 
            // button197
            // 
            this.button197.Location = new System.Drawing.Point(659, 854);
            this.button197.Margin = new System.Windows.Forms.Padding(0);
            this.button197.Name = "button197";
            this.button197.Size = new System.Drawing.Size(30, 33);
            this.button197.TabIndex = 239;
            this.button197.UseVisualStyleBackColor = true;
            this.button197.Click += new System.EventHandler(this.button197_Click);
            // 
            // button198
            // 
            this.button198.Location = new System.Drawing.Point(689, 854);
            this.button198.Margin = new System.Windows.Forms.Padding(0);
            this.button198.Name = "button198";
            this.button198.Size = new System.Drawing.Size(30, 33);
            this.button198.TabIndex = 238;
            this.button198.UseVisualStyleBackColor = true;
            this.button198.Click += new System.EventHandler(this.button198_Click);
            // 
            // button199
            // 
            this.button199.Location = new System.Drawing.Point(719, 854);
            this.button199.Margin = new System.Windows.Forms.Padding(0);
            this.button199.Name = "button199";
            this.button199.Size = new System.Drawing.Size(30, 33);
            this.button199.TabIndex = 237;
            this.button199.UseVisualStyleBackColor = true;
            this.button199.Click += new System.EventHandler(this.button199_Click);
            // 
            // button200
            // 
            this.button200.Location = new System.Drawing.Point(749, 854);
            this.button200.Margin = new System.Windows.Forms.Padding(0);
            this.button200.Name = "button200";
            this.button200.Size = new System.Drawing.Size(30, 33);
            this.button200.TabIndex = 236;
            this.button200.UseVisualStyleBackColor = true;
            this.button200.Click += new System.EventHandler(this.button200_Click);
            // 
            // button201
            // 
            this.button201.Location = new System.Drawing.Point(539, 887);
            this.button201.Margin = new System.Windows.Forms.Padding(0);
            this.button201.Name = "button201";
            this.button201.Size = new System.Drawing.Size(30, 33);
            this.button201.TabIndex = 235;
            this.button201.UseVisualStyleBackColor = true;
            this.button201.Click += new System.EventHandler(this.button201_Click);
            // 
            // button202
            // 
            this.button202.Location = new System.Drawing.Point(569, 887);
            this.button202.Margin = new System.Windows.Forms.Padding(0);
            this.button202.Name = "button202";
            this.button202.Size = new System.Drawing.Size(30, 33);
            this.button202.TabIndex = 234;
            this.button202.UseVisualStyleBackColor = true;
            this.button202.Click += new System.EventHandler(this.button202_Click);
            // 
            // button203
            // 
            this.button203.Location = new System.Drawing.Point(599, 887);
            this.button203.Margin = new System.Windows.Forms.Padding(0);
            this.button203.Name = "button203";
            this.button203.Size = new System.Drawing.Size(30, 33);
            this.button203.TabIndex = 233;
            this.button203.UseVisualStyleBackColor = true;
            this.button203.Click += new System.EventHandler(this.button203_Click);
            // 
            // button204
            // 
            this.button204.Location = new System.Drawing.Point(629, 887);
            this.button204.Margin = new System.Windows.Forms.Padding(0);
            this.button204.Name = "button204";
            this.button204.Size = new System.Drawing.Size(30, 33);
            this.button204.TabIndex = 232;
            this.button204.UseVisualStyleBackColor = true;
            this.button204.Click += new System.EventHandler(this.button204_Click);
            // 
            // button205
            // 
            this.button205.Location = new System.Drawing.Point(659, 887);
            this.button205.Margin = new System.Windows.Forms.Padding(0);
            this.button205.Name = "button205";
            this.button205.Size = new System.Drawing.Size(30, 33);
            this.button205.TabIndex = 231;
            this.button205.UseVisualStyleBackColor = true;
            this.button205.Click += new System.EventHandler(this.button205_Click);
            // 
            // button206
            // 
            this.button206.Location = new System.Drawing.Point(689, 887);
            this.button206.Margin = new System.Windows.Forms.Padding(0);
            this.button206.Name = "button206";
            this.button206.Size = new System.Drawing.Size(30, 33);
            this.button206.TabIndex = 230;
            this.button206.UseVisualStyleBackColor = true;
            this.button206.Click += new System.EventHandler(this.button206_Click);
            // 
            // button207
            // 
            this.button207.Location = new System.Drawing.Point(719, 887);
            this.button207.Margin = new System.Windows.Forms.Padding(0);
            this.button207.Name = "button207";
            this.button207.Size = new System.Drawing.Size(30, 33);
            this.button207.TabIndex = 229;
            this.button207.UseVisualStyleBackColor = true;
            this.button207.Click += new System.EventHandler(this.button207_Click);
            // 
            // button208
            // 
            this.button208.Location = new System.Drawing.Point(749, 887);
            this.button208.Margin = new System.Windows.Forms.Padding(0);
            this.button208.Name = "button208";
            this.button208.Size = new System.Drawing.Size(30, 33);
            this.button208.TabIndex = 228;
            this.button208.UseVisualStyleBackColor = true;
            this.button208.Click += new System.EventHandler(this.button208_Click);
            // 
            // button209
            // 
            this.button209.Location = new System.Drawing.Point(539, 920);
            this.button209.Margin = new System.Windows.Forms.Padding(0);
            this.button209.Name = "button209";
            this.button209.Size = new System.Drawing.Size(30, 33);
            this.button209.TabIndex = 227;
            this.button209.UseVisualStyleBackColor = true;
            this.button209.Click += new System.EventHandler(this.button209_Click);
            // 
            // button210
            // 
            this.button210.Location = new System.Drawing.Point(569, 920);
            this.button210.Margin = new System.Windows.Forms.Padding(0);
            this.button210.Name = "button210";
            this.button210.Size = new System.Drawing.Size(30, 33);
            this.button210.TabIndex = 226;
            this.button210.UseVisualStyleBackColor = true;
            this.button210.Click += new System.EventHandler(this.button210_Click);
            // 
            // button211
            // 
            this.button211.Location = new System.Drawing.Point(599, 920);
            this.button211.Margin = new System.Windows.Forms.Padding(0);
            this.button211.Name = "button211";
            this.button211.Size = new System.Drawing.Size(30, 33);
            this.button211.TabIndex = 225;
            this.button211.UseVisualStyleBackColor = true;
            this.button211.Click += new System.EventHandler(this.button211_Click);
            // 
            // button212
            // 
            this.button212.Location = new System.Drawing.Point(629, 920);
            this.button212.Margin = new System.Windows.Forms.Padding(0);
            this.button212.Name = "button212";
            this.button212.Size = new System.Drawing.Size(30, 33);
            this.button212.TabIndex = 224;
            this.button212.UseVisualStyleBackColor = true;
            this.button212.Click += new System.EventHandler(this.button212_Click);
            // 
            // button213
            // 
            this.button213.Location = new System.Drawing.Point(659, 920);
            this.button213.Margin = new System.Windows.Forms.Padding(0);
            this.button213.Name = "button213";
            this.button213.Size = new System.Drawing.Size(30, 33);
            this.button213.TabIndex = 223;
            this.button213.UseVisualStyleBackColor = true;
            this.button213.Click += new System.EventHandler(this.button213_Click);
            // 
            // button214
            // 
            this.button214.Location = new System.Drawing.Point(689, 920);
            this.button214.Margin = new System.Windows.Forms.Padding(0);
            this.button214.Name = "button214";
            this.button214.Size = new System.Drawing.Size(30, 33);
            this.button214.TabIndex = 222;
            this.button214.UseVisualStyleBackColor = true;
            this.button214.Click += new System.EventHandler(this.button214_Click);
            // 
            // button215
            // 
            this.button215.Location = new System.Drawing.Point(719, 920);
            this.button215.Margin = new System.Windows.Forms.Padding(0);
            this.button215.Name = "button215";
            this.button215.Size = new System.Drawing.Size(30, 33);
            this.button215.TabIndex = 221;
            this.button215.UseVisualStyleBackColor = true;
            this.button215.Click += new System.EventHandler(this.button215_Click);
            // 
            // button216
            // 
            this.button216.Location = new System.Drawing.Point(749, 920);
            this.button216.Margin = new System.Windows.Forms.Padding(0);
            this.button216.Name = "button216";
            this.button216.Size = new System.Drawing.Size(30, 33);
            this.button216.TabIndex = 220;
            this.button216.UseVisualStyleBackColor = true;
            this.button216.Click += new System.EventHandler(this.button216_Click);
            // 
            // button217
            // 
            this.button217.Location = new System.Drawing.Point(539, 953);
            this.button217.Margin = new System.Windows.Forms.Padding(0);
            this.button217.Name = "button217";
            this.button217.Size = new System.Drawing.Size(30, 33);
            this.button217.TabIndex = 219;
            this.button217.UseVisualStyleBackColor = true;
            this.button217.Click += new System.EventHandler(this.button217_Click);
            // 
            // button218
            // 
            this.button218.Location = new System.Drawing.Point(569, 953);
            this.button218.Margin = new System.Windows.Forms.Padding(0);
            this.button218.Name = "button218";
            this.button218.Size = new System.Drawing.Size(30, 33);
            this.button218.TabIndex = 218;
            this.button218.UseVisualStyleBackColor = true;
            this.button218.Click += new System.EventHandler(this.button218_Click);
            // 
            // button219
            // 
            this.button219.Location = new System.Drawing.Point(599, 953);
            this.button219.Margin = new System.Windows.Forms.Padding(0);
            this.button219.Name = "button219";
            this.button219.Size = new System.Drawing.Size(30, 33);
            this.button219.TabIndex = 217;
            this.button219.UseVisualStyleBackColor = true;
            this.button219.Click += new System.EventHandler(this.button219_Click);
            // 
            // button220
            // 
            this.button220.Location = new System.Drawing.Point(629, 953);
            this.button220.Margin = new System.Windows.Forms.Padding(0);
            this.button220.Name = "button220";
            this.button220.Size = new System.Drawing.Size(30, 33);
            this.button220.TabIndex = 216;
            this.button220.UseVisualStyleBackColor = true;
            this.button220.Click += new System.EventHandler(this.button220_Click);
            // 
            // button221
            // 
            this.button221.Location = new System.Drawing.Point(659, 953);
            this.button221.Margin = new System.Windows.Forms.Padding(0);
            this.button221.Name = "button221";
            this.button221.Size = new System.Drawing.Size(30, 33);
            this.button221.TabIndex = 215;
            this.button221.UseVisualStyleBackColor = true;
            this.button221.Click += new System.EventHandler(this.button221_Click);
            // 
            // button222
            // 
            this.button222.Location = new System.Drawing.Point(689, 953);
            this.button222.Margin = new System.Windows.Forms.Padding(0);
            this.button222.Name = "button222";
            this.button222.Size = new System.Drawing.Size(30, 33);
            this.button222.TabIndex = 214;
            this.button222.UseVisualStyleBackColor = true;
            this.button222.Click += new System.EventHandler(this.button222_Click);
            // 
            // button223
            // 
            this.button223.Location = new System.Drawing.Point(719, 953);
            this.button223.Margin = new System.Windows.Forms.Padding(0);
            this.button223.Name = "button223";
            this.button223.Size = new System.Drawing.Size(30, 33);
            this.button223.TabIndex = 213;
            this.button223.UseVisualStyleBackColor = true;
            this.button223.Click += new System.EventHandler(this.button223_Click);
            // 
            // button224
            // 
            this.button224.Location = new System.Drawing.Point(749, 953);
            this.button224.Margin = new System.Windows.Forms.Padding(0);
            this.button224.Name = "button224";
            this.button224.Size = new System.Drawing.Size(30, 33);
            this.button224.TabIndex = 212;
            this.button224.UseVisualStyleBackColor = true;
            this.button224.Click += new System.EventHandler(this.button224_Click);
            // 
            // button225
            // 
            this.button225.Location = new System.Drawing.Point(539, 986);
            this.button225.Margin = new System.Windows.Forms.Padding(0);
            this.button225.Name = "button225";
            this.button225.Size = new System.Drawing.Size(30, 33);
            this.button225.TabIndex = 211;
            this.button225.UseVisualStyleBackColor = true;
            this.button225.Click += new System.EventHandler(this.button225_Click);
            // 
            // button226
            // 
            this.button226.Location = new System.Drawing.Point(569, 986);
            this.button226.Margin = new System.Windows.Forms.Padding(0);
            this.button226.Name = "button226";
            this.button226.Size = new System.Drawing.Size(30, 33);
            this.button226.TabIndex = 210;
            this.button226.UseVisualStyleBackColor = true;
            this.button226.Click += new System.EventHandler(this.button226_Click);
            // 
            // button227
            // 
            this.button227.Location = new System.Drawing.Point(599, 986);
            this.button227.Margin = new System.Windows.Forms.Padding(0);
            this.button227.Name = "button227";
            this.button227.Size = new System.Drawing.Size(30, 33);
            this.button227.TabIndex = 209;
            this.button227.UseVisualStyleBackColor = true;
            this.button227.Click += new System.EventHandler(this.button227_Click);
            // 
            // button228
            // 
            this.button228.Location = new System.Drawing.Point(629, 986);
            this.button228.Margin = new System.Windows.Forms.Padding(0);
            this.button228.Name = "button228";
            this.button228.Size = new System.Drawing.Size(30, 33);
            this.button228.TabIndex = 208;
            this.button228.UseVisualStyleBackColor = true;
            this.button228.Click += new System.EventHandler(this.button228_Click);
            // 
            // button229
            // 
            this.button229.Location = new System.Drawing.Point(659, 986);
            this.button229.Margin = new System.Windows.Forms.Padding(0);
            this.button229.Name = "button229";
            this.button229.Size = new System.Drawing.Size(30, 33);
            this.button229.TabIndex = 207;
            this.button229.UseVisualStyleBackColor = true;
            this.button229.Click += new System.EventHandler(this.button229_Click);
            // 
            // button230
            // 
            this.button230.Location = new System.Drawing.Point(689, 986);
            this.button230.Margin = new System.Windows.Forms.Padding(0);
            this.button230.Name = "button230";
            this.button230.Size = new System.Drawing.Size(30, 33);
            this.button230.TabIndex = 206;
            this.button230.UseVisualStyleBackColor = true;
            this.button230.Click += new System.EventHandler(this.button230_Click);
            // 
            // button231
            // 
            this.button231.Location = new System.Drawing.Point(719, 986);
            this.button231.Margin = new System.Windows.Forms.Padding(0);
            this.button231.Name = "button231";
            this.button231.Size = new System.Drawing.Size(30, 33);
            this.button231.TabIndex = 205;
            this.button231.UseVisualStyleBackColor = true;
            this.button231.Click += new System.EventHandler(this.button231_Click);
            // 
            // button232
            // 
            this.button232.Location = new System.Drawing.Point(749, 986);
            this.button232.Margin = new System.Windows.Forms.Padding(0);
            this.button232.Name = "button232";
            this.button232.Size = new System.Drawing.Size(30, 33);
            this.button232.TabIndex = 204;
            this.button232.UseVisualStyleBackColor = true;
            this.button232.Click += new System.EventHandler(this.button232_Click);
            // 
            // button233
            // 
            this.button233.Location = new System.Drawing.Point(539, 1019);
            this.button233.Margin = new System.Windows.Forms.Padding(0);
            this.button233.Name = "button233";
            this.button233.Size = new System.Drawing.Size(30, 33);
            this.button233.TabIndex = 203;
            this.button233.UseVisualStyleBackColor = true;
            this.button233.Click += new System.EventHandler(this.button233_Click);
            // 
            // button234
            // 
            this.button234.Location = new System.Drawing.Point(569, 1019);
            this.button234.Margin = new System.Windows.Forms.Padding(0);
            this.button234.Name = "button234";
            this.button234.Size = new System.Drawing.Size(30, 33);
            this.button234.TabIndex = 202;
            this.button234.UseVisualStyleBackColor = true;
            this.button234.Click += new System.EventHandler(this.button234_Click);
            // 
            // button235
            // 
            this.button235.Location = new System.Drawing.Point(599, 1019);
            this.button235.Margin = new System.Windows.Forms.Padding(0);
            this.button235.Name = "button235";
            this.button235.Size = new System.Drawing.Size(30, 33);
            this.button235.TabIndex = 201;
            this.button235.UseVisualStyleBackColor = true;
            this.button235.Click += new System.EventHandler(this.button235_Click);
            // 
            // button236
            // 
            this.button236.Location = new System.Drawing.Point(629, 1019);
            this.button236.Margin = new System.Windows.Forms.Padding(0);
            this.button236.Name = "button236";
            this.button236.Size = new System.Drawing.Size(30, 33);
            this.button236.TabIndex = 200;
            this.button236.UseVisualStyleBackColor = true;
            this.button236.Click += new System.EventHandler(this.button236_Click);
            // 
            // button237
            // 
            this.button237.Location = new System.Drawing.Point(659, 1019);
            this.button237.Margin = new System.Windows.Forms.Padding(0);
            this.button237.Name = "button237";
            this.button237.Size = new System.Drawing.Size(30, 33);
            this.button237.TabIndex = 199;
            this.button237.UseVisualStyleBackColor = true;
            this.button237.Click += new System.EventHandler(this.button237_Click);
            // 
            // button238
            // 
            this.button238.Location = new System.Drawing.Point(689, 1019);
            this.button238.Margin = new System.Windows.Forms.Padding(0);
            this.button238.Name = "button238";
            this.button238.Size = new System.Drawing.Size(30, 33);
            this.button238.TabIndex = 198;
            this.button238.UseVisualStyleBackColor = true;
            this.button238.Click += new System.EventHandler(this.button238_Click);
            // 
            // button239
            // 
            this.button239.Location = new System.Drawing.Point(719, 1019);
            this.button239.Margin = new System.Windows.Forms.Padding(0);
            this.button239.Name = "button239";
            this.button239.Size = new System.Drawing.Size(30, 33);
            this.button239.TabIndex = 197;
            this.button239.UseVisualStyleBackColor = true;
            this.button239.Click += new System.EventHandler(this.button239_Click);
            // 
            // button240
            // 
            this.button240.Location = new System.Drawing.Point(749, 1019);
            this.button240.Margin = new System.Windows.Forms.Padding(0);
            this.button240.Name = "button240";
            this.button240.Size = new System.Drawing.Size(30, 33);
            this.button240.TabIndex = 196;
            this.button240.UseVisualStyleBackColor = true;
            this.button240.Click += new System.EventHandler(this.button240_Click);
            // 
            // button241
            // 
            this.button241.Location = new System.Drawing.Point(287, 436);
            this.button241.Margin = new System.Windows.Forms.Padding(0);
            this.button241.Name = "button241";
            this.button241.Size = new System.Drawing.Size(30, 33);
            this.button241.TabIndex = 291;
            this.button241.UseVisualStyleBackColor = true;
            this.button241.Click += new System.EventHandler(this.button241_Click);
            // 
            // button242
            // 
            this.button242.Location = new System.Drawing.Point(317, 436);
            this.button242.Margin = new System.Windows.Forms.Padding(0);
            this.button242.Name = "button242";
            this.button242.Size = new System.Drawing.Size(30, 33);
            this.button242.TabIndex = 290;
            this.button242.UseVisualStyleBackColor = true;
            this.button242.Click += new System.EventHandler(this.button242_Click);
            // 
            // button243
            // 
            this.button243.Location = new System.Drawing.Point(347, 436);
            this.button243.Margin = new System.Windows.Forms.Padding(0);
            this.button243.Name = "button243";
            this.button243.Size = new System.Drawing.Size(30, 33);
            this.button243.TabIndex = 289;
            this.button243.UseVisualStyleBackColor = true;
            this.button243.Click += new System.EventHandler(this.button243_Click);
            // 
            // button244
            // 
            this.button244.Location = new System.Drawing.Point(377, 436);
            this.button244.Margin = new System.Windows.Forms.Padding(0);
            this.button244.Name = "button244";
            this.button244.Size = new System.Drawing.Size(30, 33);
            this.button244.TabIndex = 288;
            this.button244.UseVisualStyleBackColor = true;
            this.button244.Click += new System.EventHandler(this.button244_Click);
            // 
            // button245
            // 
            this.button245.Location = new System.Drawing.Point(407, 436);
            this.button245.Margin = new System.Windows.Forms.Padding(0);
            this.button245.Name = "button245";
            this.button245.Size = new System.Drawing.Size(30, 33);
            this.button245.TabIndex = 287;
            this.button245.UseVisualStyleBackColor = true;
            this.button245.Click += new System.EventHandler(this.button245_Click);
            // 
            // button246
            // 
            this.button246.Location = new System.Drawing.Point(437, 436);
            this.button246.Margin = new System.Windows.Forms.Padding(0);
            this.button246.Name = "button246";
            this.button246.Size = new System.Drawing.Size(30, 33);
            this.button246.TabIndex = 286;
            this.button246.UseVisualStyleBackColor = true;
            this.button246.Click += new System.EventHandler(this.button246_Click);
            // 
            // button247
            // 
            this.button247.Location = new System.Drawing.Point(467, 436);
            this.button247.Margin = new System.Windows.Forms.Padding(0);
            this.button247.Name = "button247";
            this.button247.Size = new System.Drawing.Size(30, 33);
            this.button247.TabIndex = 285;
            this.button247.UseVisualStyleBackColor = true;
            this.button247.Click += new System.EventHandler(this.button247_Click);
            // 
            // button248
            // 
            this.button248.Location = new System.Drawing.Point(497, 436);
            this.button248.Margin = new System.Windows.Forms.Padding(0);
            this.button248.Name = "button248";
            this.button248.Size = new System.Drawing.Size(30, 33);
            this.button248.TabIndex = 284;
            this.button248.UseVisualStyleBackColor = true;
            this.button248.Click += new System.EventHandler(this.button248_Click);
            // 
            // button249
            // 
            this.button249.Location = new System.Drawing.Point(287, 469);
            this.button249.Margin = new System.Windows.Forms.Padding(0);
            this.button249.Name = "button249";
            this.button249.Size = new System.Drawing.Size(30, 33);
            this.button249.TabIndex = 283;
            this.button249.UseVisualStyleBackColor = true;
            this.button249.Click += new System.EventHandler(this.button249_Click);
            // 
            // button250
            // 
            this.button250.Location = new System.Drawing.Point(317, 469);
            this.button250.Margin = new System.Windows.Forms.Padding(0);
            this.button250.Name = "button250";
            this.button250.Size = new System.Drawing.Size(30, 33);
            this.button250.TabIndex = 282;
            this.button250.UseVisualStyleBackColor = true;
            this.button250.Click += new System.EventHandler(this.button250_Click);
            // 
            // button251
            // 
            this.button251.Location = new System.Drawing.Point(347, 469);
            this.button251.Margin = new System.Windows.Forms.Padding(0);
            this.button251.Name = "button251";
            this.button251.Size = new System.Drawing.Size(30, 33);
            this.button251.TabIndex = 281;
            this.button251.UseVisualStyleBackColor = true;
            this.button251.Click += new System.EventHandler(this.button251_Click);
            // 
            // button252
            // 
            this.button252.Location = new System.Drawing.Point(377, 469);
            this.button252.Margin = new System.Windows.Forms.Padding(0);
            this.button252.Name = "button252";
            this.button252.Size = new System.Drawing.Size(30, 33);
            this.button252.TabIndex = 280;
            this.button252.UseVisualStyleBackColor = true;
            this.button252.Click += new System.EventHandler(this.button252_Click);
            // 
            // button253
            // 
            this.button253.Location = new System.Drawing.Point(407, 469);
            this.button253.Margin = new System.Windows.Forms.Padding(0);
            this.button253.Name = "button253";
            this.button253.Size = new System.Drawing.Size(30, 33);
            this.button253.TabIndex = 279;
            this.button253.UseVisualStyleBackColor = true;
            this.button253.Click += new System.EventHandler(this.button253_Click);
            // 
            // button254
            // 
            this.button254.Location = new System.Drawing.Point(437, 469);
            this.button254.Margin = new System.Windows.Forms.Padding(0);
            this.button254.Name = "button254";
            this.button254.Size = new System.Drawing.Size(30, 33);
            this.button254.TabIndex = 278;
            this.button254.UseVisualStyleBackColor = true;
            this.button254.Click += new System.EventHandler(this.button254_Click);
            // 
            // button255
            // 
            this.button255.Location = new System.Drawing.Point(467, 469);
            this.button255.Margin = new System.Windows.Forms.Padding(0);
            this.button255.Name = "button255";
            this.button255.Size = new System.Drawing.Size(30, 33);
            this.button255.TabIndex = 277;
            this.button255.UseVisualStyleBackColor = true;
            this.button255.Click += new System.EventHandler(this.button255_Click);
            // 
            // button256
            // 
            this.button256.Location = new System.Drawing.Point(497, 469);
            this.button256.Margin = new System.Windows.Forms.Padding(0);
            this.button256.Name = "button256";
            this.button256.Size = new System.Drawing.Size(30, 33);
            this.button256.TabIndex = 276;
            this.button256.UseVisualStyleBackColor = true;
            this.button256.Click += new System.EventHandler(this.button256_Click);
            // 
            // button257
            // 
            this.button257.Location = new System.Drawing.Point(287, 502);
            this.button257.Margin = new System.Windows.Forms.Padding(0);
            this.button257.Name = "button257";
            this.button257.Size = new System.Drawing.Size(30, 33);
            this.button257.TabIndex = 275;
            this.button257.UseVisualStyleBackColor = true;
            this.button257.Click += new System.EventHandler(this.button257_Click);
            // 
            // button258
            // 
            this.button258.Location = new System.Drawing.Point(317, 502);
            this.button258.Margin = new System.Windows.Forms.Padding(0);
            this.button258.Name = "button258";
            this.button258.Size = new System.Drawing.Size(30, 33);
            this.button258.TabIndex = 274;
            this.button258.UseVisualStyleBackColor = true;
            this.button258.Click += new System.EventHandler(this.button258_Click);
            // 
            // button259
            // 
            this.button259.Location = new System.Drawing.Point(347, 502);
            this.button259.Margin = new System.Windows.Forms.Padding(0);
            this.button259.Name = "button259";
            this.button259.Size = new System.Drawing.Size(30, 33);
            this.button259.TabIndex = 273;
            this.button259.UseVisualStyleBackColor = true;
            this.button259.Click += new System.EventHandler(this.button259_Click);
            // 
            // button260
            // 
            this.button260.Location = new System.Drawing.Point(377, 502);
            this.button260.Margin = new System.Windows.Forms.Padding(0);
            this.button260.Name = "button260";
            this.button260.Size = new System.Drawing.Size(30, 33);
            this.button260.TabIndex = 272;
            this.button260.UseVisualStyleBackColor = true;
            this.button260.Click += new System.EventHandler(this.button260_Click);
            // 
            // button261
            // 
            this.button261.Location = new System.Drawing.Point(407, 502);
            this.button261.Margin = new System.Windows.Forms.Padding(0);
            this.button261.Name = "button261";
            this.button261.Size = new System.Drawing.Size(30, 33);
            this.button261.TabIndex = 271;
            this.button261.UseVisualStyleBackColor = true;
            this.button261.Click += new System.EventHandler(this.button261_Click);
            // 
            // button262
            // 
            this.button262.Location = new System.Drawing.Point(437, 502);
            this.button262.Margin = new System.Windows.Forms.Padding(0);
            this.button262.Name = "button262";
            this.button262.Size = new System.Drawing.Size(30, 33);
            this.button262.TabIndex = 270;
            this.button262.UseVisualStyleBackColor = true;
            this.button262.Click += new System.EventHandler(this.button262_Click);
            // 
            // button263
            // 
            this.button263.Location = new System.Drawing.Point(467, 502);
            this.button263.Margin = new System.Windows.Forms.Padding(0);
            this.button263.Name = "button263";
            this.button263.Size = new System.Drawing.Size(30, 33);
            this.button263.TabIndex = 269;
            this.button263.UseVisualStyleBackColor = true;
            this.button263.Click += new System.EventHandler(this.button263_Click);
            // 
            // button264
            // 
            this.button264.Location = new System.Drawing.Point(497, 502);
            this.button264.Margin = new System.Windows.Forms.Padding(0);
            this.button264.Name = "button264";
            this.button264.Size = new System.Drawing.Size(30, 33);
            this.button264.TabIndex = 268;
            this.button264.UseVisualStyleBackColor = true;
            this.button264.Click += new System.EventHandler(this.button264_Click);
            // 
            // button265
            // 
            this.button265.Location = new System.Drawing.Point(287, 535);
            this.button265.Margin = new System.Windows.Forms.Padding(0);
            this.button265.Name = "button265";
            this.button265.Size = new System.Drawing.Size(30, 33);
            this.button265.TabIndex = 267;
            this.button265.UseVisualStyleBackColor = true;
            this.button265.Click += new System.EventHandler(this.button265_Click);
            // 
            // button266
            // 
            this.button266.Location = new System.Drawing.Point(317, 535);
            this.button266.Margin = new System.Windows.Forms.Padding(0);
            this.button266.Name = "button266";
            this.button266.Size = new System.Drawing.Size(30, 33);
            this.button266.TabIndex = 266;
            this.button266.UseVisualStyleBackColor = true;
            this.button266.Click += new System.EventHandler(this.button266_Click);
            // 
            // button267
            // 
            this.button267.Location = new System.Drawing.Point(347, 535);
            this.button267.Margin = new System.Windows.Forms.Padding(0);
            this.button267.Name = "button267";
            this.button267.Size = new System.Drawing.Size(30, 33);
            this.button267.TabIndex = 265;
            this.button267.UseVisualStyleBackColor = true;
            this.button267.Click += new System.EventHandler(this.button267_Click);
            // 
            // button268
            // 
            this.button268.Location = new System.Drawing.Point(377, 535);
            this.button268.Margin = new System.Windows.Forms.Padding(0);
            this.button268.Name = "button268";
            this.button268.Size = new System.Drawing.Size(30, 33);
            this.button268.TabIndex = 264;
            this.button268.UseVisualStyleBackColor = true;
            this.button268.Click += new System.EventHandler(this.button268_Click);
            // 
            // button269
            // 
            this.button269.Location = new System.Drawing.Point(407, 535);
            this.button269.Margin = new System.Windows.Forms.Padding(0);
            this.button269.Name = "button269";
            this.button269.Size = new System.Drawing.Size(30, 33);
            this.button269.TabIndex = 263;
            this.button269.UseVisualStyleBackColor = true;
            this.button269.Click += new System.EventHandler(this.button269_Click);
            // 
            // button270
            // 
            this.button270.Location = new System.Drawing.Point(437, 535);
            this.button270.Margin = new System.Windows.Forms.Padding(0);
            this.button270.Name = "button270";
            this.button270.Size = new System.Drawing.Size(30, 33);
            this.button270.TabIndex = 262;
            this.button270.UseVisualStyleBackColor = true;
            this.button270.Click += new System.EventHandler(this.button270_Click);
            // 
            // button271
            // 
            this.button271.Location = new System.Drawing.Point(467, 535);
            this.button271.Margin = new System.Windows.Forms.Padding(0);
            this.button271.Name = "button271";
            this.button271.Size = new System.Drawing.Size(30, 33);
            this.button271.TabIndex = 261;
            this.button271.UseVisualStyleBackColor = true;
            this.button271.Click += new System.EventHandler(this.button271_Click);
            // 
            // button272
            // 
            this.button272.Location = new System.Drawing.Point(497, 535);
            this.button272.Margin = new System.Windows.Forms.Padding(0);
            this.button272.Name = "button272";
            this.button272.Size = new System.Drawing.Size(30, 33);
            this.button272.TabIndex = 260;
            this.button272.UseVisualStyleBackColor = true;
            this.button272.Click += new System.EventHandler(this.button272_Click);
            // 
            // button273
            // 
            this.button273.Location = new System.Drawing.Point(287, 568);
            this.button273.Margin = new System.Windows.Forms.Padding(0);
            this.button273.Name = "button273";
            this.button273.Size = new System.Drawing.Size(30, 33);
            this.button273.TabIndex = 259;
            this.button273.UseVisualStyleBackColor = true;
            this.button273.Click += new System.EventHandler(this.button273_Click);
            // 
            // button274
            // 
            this.button274.Location = new System.Drawing.Point(317, 568);
            this.button274.Margin = new System.Windows.Forms.Padding(0);
            this.button274.Name = "button274";
            this.button274.Size = new System.Drawing.Size(30, 33);
            this.button274.TabIndex = 258;
            this.button274.UseVisualStyleBackColor = true;
            this.button274.Click += new System.EventHandler(this.button274_Click);
            // 
            // button275
            // 
            this.button275.Location = new System.Drawing.Point(347, 568);
            this.button275.Margin = new System.Windows.Forms.Padding(0);
            this.button275.Name = "button275";
            this.button275.Size = new System.Drawing.Size(30, 33);
            this.button275.TabIndex = 257;
            this.button275.UseVisualStyleBackColor = true;
            this.button275.Click += new System.EventHandler(this.button275_Click);
            // 
            // button276
            // 
            this.button276.Location = new System.Drawing.Point(377, 568);
            this.button276.Margin = new System.Windows.Forms.Padding(0);
            this.button276.Name = "button276";
            this.button276.Size = new System.Drawing.Size(30, 33);
            this.button276.TabIndex = 256;
            this.button276.UseVisualStyleBackColor = true;
            this.button276.Click += new System.EventHandler(this.button276_Click);
            // 
            // button277
            // 
            this.button277.Location = new System.Drawing.Point(407, 568);
            this.button277.Margin = new System.Windows.Forms.Padding(0);
            this.button277.Name = "button277";
            this.button277.Size = new System.Drawing.Size(30, 33);
            this.button277.TabIndex = 255;
            this.button277.UseVisualStyleBackColor = true;
            this.button277.Click += new System.EventHandler(this.button277_Click);
            // 
            // button278
            // 
            this.button278.Location = new System.Drawing.Point(437, 568);
            this.button278.Margin = new System.Windows.Forms.Padding(0);
            this.button278.Name = "button278";
            this.button278.Size = new System.Drawing.Size(30, 33);
            this.button278.TabIndex = 254;
            this.button278.UseVisualStyleBackColor = true;
            this.button278.Click += new System.EventHandler(this.button278_Click);
            // 
            // button279
            // 
            this.button279.Location = new System.Drawing.Point(467, 568);
            this.button279.Margin = new System.Windows.Forms.Padding(0);
            this.button279.Name = "button279";
            this.button279.Size = new System.Drawing.Size(30, 33);
            this.button279.TabIndex = 253;
            this.button279.UseVisualStyleBackColor = true;
            this.button279.Click += new System.EventHandler(this.button279_Click);
            // 
            // button280
            // 
            this.button280.Location = new System.Drawing.Point(497, 568);
            this.button280.Margin = new System.Windows.Forms.Padding(0);
            this.button280.Name = "button280";
            this.button280.Size = new System.Drawing.Size(30, 33);
            this.button280.TabIndex = 252;
            this.button280.UseVisualStyleBackColor = true;
            this.button280.Click += new System.EventHandler(this.button280_Click);
            // 
            // button281
            // 
            this.button281.Location = new System.Drawing.Point(287, 601);
            this.button281.Margin = new System.Windows.Forms.Padding(0);
            this.button281.Name = "button281";
            this.button281.Size = new System.Drawing.Size(30, 33);
            this.button281.TabIndex = 251;
            this.button281.UseVisualStyleBackColor = true;
            this.button281.Click += new System.EventHandler(this.button281_Click);
            // 
            // button282
            // 
            this.button282.Location = new System.Drawing.Point(317, 601);
            this.button282.Margin = new System.Windows.Forms.Padding(0);
            this.button282.Name = "button282";
            this.button282.Size = new System.Drawing.Size(30, 33);
            this.button282.TabIndex = 250;
            this.button282.UseVisualStyleBackColor = true;
            this.button282.Click += new System.EventHandler(this.button282_Click);
            // 
            // button283
            // 
            this.button283.Location = new System.Drawing.Point(347, 601);
            this.button283.Margin = new System.Windows.Forms.Padding(0);
            this.button283.Name = "button283";
            this.button283.Size = new System.Drawing.Size(30, 33);
            this.button283.TabIndex = 249;
            this.button283.UseVisualStyleBackColor = true;
            this.button283.Click += new System.EventHandler(this.button283_Click);
            // 
            // button284
            // 
            this.button284.Location = new System.Drawing.Point(377, 601);
            this.button284.Margin = new System.Windows.Forms.Padding(0);
            this.button284.Name = "button284";
            this.button284.Size = new System.Drawing.Size(30, 33);
            this.button284.TabIndex = 248;
            this.button284.UseVisualStyleBackColor = true;
            this.button284.Click += new System.EventHandler(this.button284_Click);
            // 
            // button285
            // 
            this.button285.Location = new System.Drawing.Point(407, 601);
            this.button285.Margin = new System.Windows.Forms.Padding(0);
            this.button285.Name = "button285";
            this.button285.Size = new System.Drawing.Size(30, 33);
            this.button285.TabIndex = 247;
            this.button285.UseVisualStyleBackColor = true;
            this.button285.Click += new System.EventHandler(this.button285_Click);
            // 
            // button286
            // 
            this.button286.Location = new System.Drawing.Point(437, 601);
            this.button286.Margin = new System.Windows.Forms.Padding(0);
            this.button286.Name = "button286";
            this.button286.Size = new System.Drawing.Size(30, 33);
            this.button286.TabIndex = 246;
            this.button286.UseVisualStyleBackColor = true;
            this.button286.Click += new System.EventHandler(this.button286_Click);
            // 
            // button287
            // 
            this.button287.Location = new System.Drawing.Point(467, 601);
            this.button287.Margin = new System.Windows.Forms.Padding(0);
            this.button287.Name = "button287";
            this.button287.Size = new System.Drawing.Size(30, 33);
            this.button287.TabIndex = 245;
            this.button287.UseVisualStyleBackColor = true;
            this.button287.Click += new System.EventHandler(this.button287_Click);
            // 
            // button288
            // 
            this.button288.Location = new System.Drawing.Point(497, 601);
            this.button288.Margin = new System.Windows.Forms.Padding(0);
            this.button288.Name = "button288";
            this.button288.Size = new System.Drawing.Size(30, 33);
            this.button288.TabIndex = 244;
            this.button288.UseVisualStyleBackColor = true;
            this.button288.Click += new System.EventHandler(this.button288_Click);
            // 
            // button289
            // 
            this.button289.Location = new System.Drawing.Point(26, 436);
            this.button289.Margin = new System.Windows.Forms.Padding(0);
            this.button289.Name = "button289";
            this.button289.Size = new System.Drawing.Size(30, 33);
            this.button289.TabIndex = 339;
            this.button289.UseVisualStyleBackColor = true;
            this.button289.Click += new System.EventHandler(this.button289_Click);
            // 
            // button290
            // 
            this.button290.Location = new System.Drawing.Point(56, 436);
            this.button290.Margin = new System.Windows.Forms.Padding(0);
            this.button290.Name = "button290";
            this.button290.Size = new System.Drawing.Size(30, 33);
            this.button290.TabIndex = 338;
            this.button290.UseVisualStyleBackColor = true;
            this.button290.Click += new System.EventHandler(this.button290_Click);
            // 
            // button291
            // 
            this.button291.Location = new System.Drawing.Point(86, 436);
            this.button291.Margin = new System.Windows.Forms.Padding(0);
            this.button291.Name = "button291";
            this.button291.Size = new System.Drawing.Size(30, 33);
            this.button291.TabIndex = 337;
            this.button291.UseVisualStyleBackColor = true;
            this.button291.Click += new System.EventHandler(this.button291_Click);
            // 
            // button292
            // 
            this.button292.Location = new System.Drawing.Point(116, 436);
            this.button292.Margin = new System.Windows.Forms.Padding(0);
            this.button292.Name = "button292";
            this.button292.Size = new System.Drawing.Size(30, 33);
            this.button292.TabIndex = 336;
            this.button292.UseVisualStyleBackColor = true;
            this.button292.Click += new System.EventHandler(this.button292_Click);
            // 
            // button293
            // 
            this.button293.Location = new System.Drawing.Point(146, 436);
            this.button293.Margin = new System.Windows.Forms.Padding(0);
            this.button293.Name = "button293";
            this.button293.Size = new System.Drawing.Size(30, 33);
            this.button293.TabIndex = 335;
            this.button293.UseVisualStyleBackColor = true;
            this.button293.Click += new System.EventHandler(this.button293_Click);
            // 
            // button294
            // 
            this.button294.Location = new System.Drawing.Point(176, 436);
            this.button294.Margin = new System.Windows.Forms.Padding(0);
            this.button294.Name = "button294";
            this.button294.Size = new System.Drawing.Size(30, 33);
            this.button294.TabIndex = 334;
            this.button294.UseVisualStyleBackColor = true;
            this.button294.Click += new System.EventHandler(this.button294_Click);
            // 
            // button295
            // 
            this.button295.Location = new System.Drawing.Point(206, 436);
            this.button295.Margin = new System.Windows.Forms.Padding(0);
            this.button295.Name = "button295";
            this.button295.Size = new System.Drawing.Size(30, 33);
            this.button295.TabIndex = 333;
            this.button295.UseVisualStyleBackColor = true;
            this.button295.Click += new System.EventHandler(this.button295_Click);
            // 
            // button296
            // 
            this.button296.Location = new System.Drawing.Point(236, 436);
            this.button296.Margin = new System.Windows.Forms.Padding(0);
            this.button296.Name = "button296";
            this.button296.Size = new System.Drawing.Size(30, 33);
            this.button296.TabIndex = 332;
            this.button296.UseVisualStyleBackColor = true;
            this.button296.Click += new System.EventHandler(this.button296_Click);
            // 
            // button297
            // 
            this.button297.Location = new System.Drawing.Point(26, 469);
            this.button297.Margin = new System.Windows.Forms.Padding(0);
            this.button297.Name = "button297";
            this.button297.Size = new System.Drawing.Size(30, 33);
            this.button297.TabIndex = 331;
            this.button297.UseVisualStyleBackColor = true;
            this.button297.Click += new System.EventHandler(this.button297_Click);
            // 
            // button298
            // 
            this.button298.Location = new System.Drawing.Point(56, 469);
            this.button298.Margin = new System.Windows.Forms.Padding(0);
            this.button298.Name = "button298";
            this.button298.Size = new System.Drawing.Size(30, 33);
            this.button298.TabIndex = 330;
            this.button298.UseVisualStyleBackColor = true;
            this.button298.Click += new System.EventHandler(this.button298_Click);
            // 
            // button299
            // 
            this.button299.Location = new System.Drawing.Point(86, 469);
            this.button299.Margin = new System.Windows.Forms.Padding(0);
            this.button299.Name = "button299";
            this.button299.Size = new System.Drawing.Size(30, 33);
            this.button299.TabIndex = 329;
            this.button299.UseVisualStyleBackColor = true;
            this.button299.Click += new System.EventHandler(this.button299_Click);
            // 
            // button300
            // 
            this.button300.Location = new System.Drawing.Point(116, 469);
            this.button300.Margin = new System.Windows.Forms.Padding(0);
            this.button300.Name = "button300";
            this.button300.Size = new System.Drawing.Size(30, 33);
            this.button300.TabIndex = 328;
            this.button300.UseVisualStyleBackColor = true;
            this.button300.Click += new System.EventHandler(this.button300_Click);
            // 
            // button301
            // 
            this.button301.Location = new System.Drawing.Point(146, 469);
            this.button301.Margin = new System.Windows.Forms.Padding(0);
            this.button301.Name = "button301";
            this.button301.Size = new System.Drawing.Size(30, 33);
            this.button301.TabIndex = 327;
            this.button301.UseVisualStyleBackColor = true;
            this.button301.Click += new System.EventHandler(this.button301_Click);
            // 
            // button302
            // 
            this.button302.Location = new System.Drawing.Point(176, 469);
            this.button302.Margin = new System.Windows.Forms.Padding(0);
            this.button302.Name = "button302";
            this.button302.Size = new System.Drawing.Size(30, 33);
            this.button302.TabIndex = 326;
            this.button302.UseVisualStyleBackColor = true;
            this.button302.Click += new System.EventHandler(this.button302_Click);
            // 
            // button303
            // 
            this.button303.Location = new System.Drawing.Point(206, 469);
            this.button303.Margin = new System.Windows.Forms.Padding(0);
            this.button303.Name = "button303";
            this.button303.Size = new System.Drawing.Size(30, 33);
            this.button303.TabIndex = 325;
            this.button303.UseVisualStyleBackColor = true;
            this.button303.Click += new System.EventHandler(this.button303_Click);
            // 
            // button304
            // 
            this.button304.Location = new System.Drawing.Point(236, 469);
            this.button304.Margin = new System.Windows.Forms.Padding(0);
            this.button304.Name = "button304";
            this.button304.Size = new System.Drawing.Size(30, 33);
            this.button304.TabIndex = 324;
            this.button304.UseVisualStyleBackColor = true;
            this.button304.Click += new System.EventHandler(this.button304_Click);
            // 
            // button305
            // 
            this.button305.Location = new System.Drawing.Point(26, 502);
            this.button305.Margin = new System.Windows.Forms.Padding(0);
            this.button305.Name = "button305";
            this.button305.Size = new System.Drawing.Size(30, 33);
            this.button305.TabIndex = 323;
            this.button305.UseVisualStyleBackColor = true;
            this.button305.Click += new System.EventHandler(this.button305_Click);
            // 
            // button306
            // 
            this.button306.Location = new System.Drawing.Point(56, 502);
            this.button306.Margin = new System.Windows.Forms.Padding(0);
            this.button306.Name = "button306";
            this.button306.Size = new System.Drawing.Size(30, 33);
            this.button306.TabIndex = 322;
            this.button306.UseVisualStyleBackColor = true;
            this.button306.Click += new System.EventHandler(this.button306_Click);
            // 
            // button307
            // 
            this.button307.Location = new System.Drawing.Point(86, 502);
            this.button307.Margin = new System.Windows.Forms.Padding(0);
            this.button307.Name = "button307";
            this.button307.Size = new System.Drawing.Size(30, 33);
            this.button307.TabIndex = 321;
            this.button307.UseVisualStyleBackColor = true;
            this.button307.Click += new System.EventHandler(this.button307_Click);
            // 
            // button308
            // 
            this.button308.Location = new System.Drawing.Point(116, 502);
            this.button308.Margin = new System.Windows.Forms.Padding(0);
            this.button308.Name = "button308";
            this.button308.Size = new System.Drawing.Size(30, 33);
            this.button308.TabIndex = 320;
            this.button308.UseVisualStyleBackColor = true;
            this.button308.Click += new System.EventHandler(this.button308_Click);
            // 
            // button309
            // 
            this.button309.Location = new System.Drawing.Point(146, 502);
            this.button309.Margin = new System.Windows.Forms.Padding(0);
            this.button309.Name = "button309";
            this.button309.Size = new System.Drawing.Size(30, 33);
            this.button309.TabIndex = 319;
            this.button309.UseVisualStyleBackColor = true;
            this.button309.Click += new System.EventHandler(this.button309_Click);
            // 
            // button310
            // 
            this.button310.Location = new System.Drawing.Point(176, 502);
            this.button310.Margin = new System.Windows.Forms.Padding(0);
            this.button310.Name = "button310";
            this.button310.Size = new System.Drawing.Size(30, 33);
            this.button310.TabIndex = 318;
            this.button310.UseVisualStyleBackColor = true;
            this.button310.Click += new System.EventHandler(this.button310_Click);
            // 
            // button311
            // 
            this.button311.Location = new System.Drawing.Point(206, 502);
            this.button311.Margin = new System.Windows.Forms.Padding(0);
            this.button311.Name = "button311";
            this.button311.Size = new System.Drawing.Size(30, 33);
            this.button311.TabIndex = 317;
            this.button311.UseVisualStyleBackColor = true;
            this.button311.Click += new System.EventHandler(this.button311_Click);
            // 
            // button312
            // 
            this.button312.Location = new System.Drawing.Point(236, 502);
            this.button312.Margin = new System.Windows.Forms.Padding(0);
            this.button312.Name = "button312";
            this.button312.Size = new System.Drawing.Size(30, 33);
            this.button312.TabIndex = 316;
            this.button312.UseVisualStyleBackColor = true;
            this.button312.Click += new System.EventHandler(this.button312_Click);
            // 
            // button313
            // 
            this.button313.Location = new System.Drawing.Point(26, 535);
            this.button313.Margin = new System.Windows.Forms.Padding(0);
            this.button313.Name = "button313";
            this.button313.Size = new System.Drawing.Size(30, 33);
            this.button313.TabIndex = 315;
            this.button313.UseVisualStyleBackColor = true;
            this.button313.Click += new System.EventHandler(this.button313_Click);
            // 
            // button314
            // 
            this.button314.Location = new System.Drawing.Point(56, 535);
            this.button314.Margin = new System.Windows.Forms.Padding(0);
            this.button314.Name = "button314";
            this.button314.Size = new System.Drawing.Size(30, 33);
            this.button314.TabIndex = 314;
            this.button314.UseVisualStyleBackColor = true;
            this.button314.Click += new System.EventHandler(this.button314_Click);
            // 
            // button315
            // 
            this.button315.Location = new System.Drawing.Point(86, 535);
            this.button315.Margin = new System.Windows.Forms.Padding(0);
            this.button315.Name = "button315";
            this.button315.Size = new System.Drawing.Size(30, 33);
            this.button315.TabIndex = 313;
            this.button315.UseVisualStyleBackColor = true;
            this.button315.Click += new System.EventHandler(this.button315_Click);
            // 
            // button316
            // 
            this.button316.Location = new System.Drawing.Point(116, 535);
            this.button316.Margin = new System.Windows.Forms.Padding(0);
            this.button316.Name = "button316";
            this.button316.Size = new System.Drawing.Size(30, 33);
            this.button316.TabIndex = 312;
            this.button316.UseVisualStyleBackColor = true;
            this.button316.Click += new System.EventHandler(this.button316_Click);
            // 
            // button317
            // 
            this.button317.Location = new System.Drawing.Point(146, 535);
            this.button317.Margin = new System.Windows.Forms.Padding(0);
            this.button317.Name = "button317";
            this.button317.Size = new System.Drawing.Size(30, 33);
            this.button317.TabIndex = 311;
            this.button317.UseVisualStyleBackColor = true;
            this.button317.Click += new System.EventHandler(this.button317_Click);
            // 
            // button318
            // 
            this.button318.Location = new System.Drawing.Point(176, 535);
            this.button318.Margin = new System.Windows.Forms.Padding(0);
            this.button318.Name = "button318";
            this.button318.Size = new System.Drawing.Size(30, 33);
            this.button318.TabIndex = 310;
            this.button318.UseVisualStyleBackColor = true;
            this.button318.Click += new System.EventHandler(this.button318_Click);
            // 
            // button319
            // 
            this.button319.Location = new System.Drawing.Point(206, 535);
            this.button319.Margin = new System.Windows.Forms.Padding(0);
            this.button319.Name = "button319";
            this.button319.Size = new System.Drawing.Size(30, 33);
            this.button319.TabIndex = 309;
            this.button319.UseVisualStyleBackColor = true;
            this.button319.Click += new System.EventHandler(this.button319_Click);
            // 
            // button320
            // 
            this.button320.Location = new System.Drawing.Point(236, 535);
            this.button320.Margin = new System.Windows.Forms.Padding(0);
            this.button320.Name = "button320";
            this.button320.Size = new System.Drawing.Size(30, 33);
            this.button320.TabIndex = 308;
            this.button320.UseVisualStyleBackColor = true;
            this.button320.Click += new System.EventHandler(this.button320_Click);
            // 
            // button321
            // 
            this.button321.Location = new System.Drawing.Point(26, 568);
            this.button321.Margin = new System.Windows.Forms.Padding(0);
            this.button321.Name = "button321";
            this.button321.Size = new System.Drawing.Size(30, 33);
            this.button321.TabIndex = 307;
            this.button321.UseVisualStyleBackColor = true;
            this.button321.Click += new System.EventHandler(this.button321_Click);
            // 
            // button322
            // 
            this.button322.Location = new System.Drawing.Point(56, 568);
            this.button322.Margin = new System.Windows.Forms.Padding(0);
            this.button322.Name = "button322";
            this.button322.Size = new System.Drawing.Size(30, 33);
            this.button322.TabIndex = 306;
            this.button322.UseVisualStyleBackColor = true;
            this.button322.Click += new System.EventHandler(this.button322_Click);
            // 
            // button323
            // 
            this.button323.Location = new System.Drawing.Point(86, 568);
            this.button323.Margin = new System.Windows.Forms.Padding(0);
            this.button323.Name = "button323";
            this.button323.Size = new System.Drawing.Size(30, 33);
            this.button323.TabIndex = 305;
            this.button323.UseVisualStyleBackColor = true;
            this.button323.Click += new System.EventHandler(this.button323_Click);
            // 
            // button324
            // 
            this.button324.Location = new System.Drawing.Point(116, 568);
            this.button324.Margin = new System.Windows.Forms.Padding(0);
            this.button324.Name = "button324";
            this.button324.Size = new System.Drawing.Size(30, 33);
            this.button324.TabIndex = 304;
            this.button324.UseVisualStyleBackColor = true;
            this.button324.Click += new System.EventHandler(this.button324_Click);
            // 
            // button325
            // 
            this.button325.Location = new System.Drawing.Point(146, 568);
            this.button325.Margin = new System.Windows.Forms.Padding(0);
            this.button325.Name = "button325";
            this.button325.Size = new System.Drawing.Size(30, 33);
            this.button325.TabIndex = 303;
            this.button325.UseVisualStyleBackColor = true;
            this.button325.Click += new System.EventHandler(this.button325_Click);
            // 
            // button326
            // 
            this.button326.Location = new System.Drawing.Point(176, 568);
            this.button326.Margin = new System.Windows.Forms.Padding(0);
            this.button326.Name = "button326";
            this.button326.Size = new System.Drawing.Size(30, 33);
            this.button326.TabIndex = 302;
            this.button326.UseVisualStyleBackColor = true;
            this.button326.Click += new System.EventHandler(this.button326_Click);
            // 
            // button327
            // 
            this.button327.Location = new System.Drawing.Point(206, 568);
            this.button327.Margin = new System.Windows.Forms.Padding(0);
            this.button327.Name = "button327";
            this.button327.Size = new System.Drawing.Size(30, 33);
            this.button327.TabIndex = 301;
            this.button327.UseVisualStyleBackColor = true;
            this.button327.Click += new System.EventHandler(this.button327_Click);
            // 
            // button328
            // 
            this.button328.Location = new System.Drawing.Point(236, 568);
            this.button328.Margin = new System.Windows.Forms.Padding(0);
            this.button328.Name = "button328";
            this.button328.Size = new System.Drawing.Size(30, 33);
            this.button328.TabIndex = 300;
            this.button328.UseVisualStyleBackColor = true;
            this.button328.Click += new System.EventHandler(this.button328_Click);
            // 
            // button329
            // 
            this.button329.Location = new System.Drawing.Point(26, 601);
            this.button329.Margin = new System.Windows.Forms.Padding(0);
            this.button329.Name = "button329";
            this.button329.Size = new System.Drawing.Size(30, 33);
            this.button329.TabIndex = 299;
            this.button329.UseVisualStyleBackColor = true;
            this.button329.Click += new System.EventHandler(this.button329_Click);
            // 
            // button330
            // 
            this.button330.Location = new System.Drawing.Point(56, 601);
            this.button330.Margin = new System.Windows.Forms.Padding(0);
            this.button330.Name = "button330";
            this.button330.Size = new System.Drawing.Size(30, 33);
            this.button330.TabIndex = 298;
            this.button330.UseVisualStyleBackColor = true;
            this.button330.Click += new System.EventHandler(this.button330_Click);
            // 
            // button331
            // 
            this.button331.Location = new System.Drawing.Point(86, 601);
            this.button331.Margin = new System.Windows.Forms.Padding(0);
            this.button331.Name = "button331";
            this.button331.Size = new System.Drawing.Size(30, 33);
            this.button331.TabIndex = 297;
            this.button331.UseVisualStyleBackColor = true;
            this.button331.Click += new System.EventHandler(this.button331_Click);
            // 
            // button332
            // 
            this.button332.Location = new System.Drawing.Point(116, 601);
            this.button332.Margin = new System.Windows.Forms.Padding(0);
            this.button332.Name = "button332";
            this.button332.Size = new System.Drawing.Size(30, 33);
            this.button332.TabIndex = 296;
            this.button332.UseVisualStyleBackColor = true;
            this.button332.Click += new System.EventHandler(this.button332_Click);
            // 
            // button333
            // 
            this.button333.Location = new System.Drawing.Point(146, 601);
            this.button333.Margin = new System.Windows.Forms.Padding(0);
            this.button333.Name = "button333";
            this.button333.Size = new System.Drawing.Size(30, 33);
            this.button333.TabIndex = 295;
            this.button333.UseVisualStyleBackColor = true;
            this.button333.Click += new System.EventHandler(this.button333_Click);
            // 
            // button334
            // 
            this.button334.Location = new System.Drawing.Point(176, 601);
            this.button334.Margin = new System.Windows.Forms.Padding(0);
            this.button334.Name = "button334";
            this.button334.Size = new System.Drawing.Size(30, 33);
            this.button334.TabIndex = 294;
            this.button334.UseVisualStyleBackColor = true;
            this.button334.Click += new System.EventHandler(this.button334_Click);
            // 
            // button335
            // 
            this.button335.Location = new System.Drawing.Point(206, 601);
            this.button335.Margin = new System.Windows.Forms.Padding(0);
            this.button335.Name = "button335";
            this.button335.Size = new System.Drawing.Size(30, 33);
            this.button335.TabIndex = 293;
            this.button335.UseVisualStyleBackColor = true;
            this.button335.Click += new System.EventHandler(this.button335_Click);
            // 
            // button336
            // 
            this.button336.Location = new System.Drawing.Point(236, 601);
            this.button336.Margin = new System.Windows.Forms.Padding(0);
            this.button336.Name = "button336";
            this.button336.Size = new System.Drawing.Size(30, 33);
            this.button336.TabIndex = 292;
            this.button336.UseVisualStyleBackColor = true;
            this.button336.Click += new System.EventHandler(this.button336_Click);
            // 
            // button337
            // 
            this.button337.Location = new System.Drawing.Point(791, 436);
            this.button337.Margin = new System.Windows.Forms.Padding(0);
            this.button337.Name = "button337";
            this.button337.Size = new System.Drawing.Size(30, 33);
            this.button337.TabIndex = 387;
            this.button337.UseVisualStyleBackColor = true;
            this.button337.Click += new System.EventHandler(this.button337_Click);
            // 
            // button338
            // 
            this.button338.Location = new System.Drawing.Point(821, 436);
            this.button338.Margin = new System.Windows.Forms.Padding(0);
            this.button338.Name = "button338";
            this.button338.Size = new System.Drawing.Size(30, 33);
            this.button338.TabIndex = 386;
            this.button338.UseVisualStyleBackColor = true;
            this.button338.Click += new System.EventHandler(this.button338_Click);
            // 
            // button339
            // 
            this.button339.Location = new System.Drawing.Point(851, 436);
            this.button339.Margin = new System.Windows.Forms.Padding(0);
            this.button339.Name = "button339";
            this.button339.Size = new System.Drawing.Size(30, 33);
            this.button339.TabIndex = 385;
            this.button339.UseVisualStyleBackColor = true;
            this.button339.Click += new System.EventHandler(this.button339_Click);
            // 
            // button340
            // 
            this.button340.Location = new System.Drawing.Point(881, 436);
            this.button340.Margin = new System.Windows.Forms.Padding(0);
            this.button340.Name = "button340";
            this.button340.Size = new System.Drawing.Size(30, 33);
            this.button340.TabIndex = 384;
            this.button340.UseVisualStyleBackColor = true;
            this.button340.Click += new System.EventHandler(this.button340_Click);
            // 
            // button341
            // 
            this.button341.Location = new System.Drawing.Point(911, 436);
            this.button341.Margin = new System.Windows.Forms.Padding(0);
            this.button341.Name = "button341";
            this.button341.Size = new System.Drawing.Size(30, 33);
            this.button341.TabIndex = 383;
            this.button341.UseVisualStyleBackColor = true;
            this.button341.Click += new System.EventHandler(this.button341_Click);
            // 
            // button342
            // 
            this.button342.Location = new System.Drawing.Point(941, 436);
            this.button342.Margin = new System.Windows.Forms.Padding(0);
            this.button342.Name = "button342";
            this.button342.Size = new System.Drawing.Size(30, 33);
            this.button342.TabIndex = 382;
            this.button342.UseVisualStyleBackColor = true;
            this.button342.Click += new System.EventHandler(this.button342_Click);
            // 
            // button343
            // 
            this.button343.Location = new System.Drawing.Point(971, 436);
            this.button343.Margin = new System.Windows.Forms.Padding(0);
            this.button343.Name = "button343";
            this.button343.Size = new System.Drawing.Size(30, 33);
            this.button343.TabIndex = 381;
            this.button343.UseVisualStyleBackColor = true;
            this.button343.Click += new System.EventHandler(this.button343_Click);
            // 
            // button344
            // 
            this.button344.Location = new System.Drawing.Point(1001, 436);
            this.button344.Margin = new System.Windows.Forms.Padding(0);
            this.button344.Name = "button344";
            this.button344.Size = new System.Drawing.Size(30, 33);
            this.button344.TabIndex = 380;
            this.button344.UseVisualStyleBackColor = true;
            this.button344.Click += new System.EventHandler(this.button344_Click);
            // 
            // button345
            // 
            this.button345.Location = new System.Drawing.Point(791, 469);
            this.button345.Margin = new System.Windows.Forms.Padding(0);
            this.button345.Name = "button345";
            this.button345.Size = new System.Drawing.Size(30, 33);
            this.button345.TabIndex = 379;
            this.button345.UseVisualStyleBackColor = true;
            this.button345.Click += new System.EventHandler(this.button345_Click);
            // 
            // button346
            // 
            this.button346.Location = new System.Drawing.Point(821, 469);
            this.button346.Margin = new System.Windows.Forms.Padding(0);
            this.button346.Name = "button346";
            this.button346.Size = new System.Drawing.Size(30, 33);
            this.button346.TabIndex = 378;
            this.button346.UseVisualStyleBackColor = true;
            this.button346.Click += new System.EventHandler(this.button346_Click);
            // 
            // button347
            // 
            this.button347.Location = new System.Drawing.Point(851, 469);
            this.button347.Margin = new System.Windows.Forms.Padding(0);
            this.button347.Name = "button347";
            this.button347.Size = new System.Drawing.Size(30, 33);
            this.button347.TabIndex = 377;
            this.button347.UseVisualStyleBackColor = true;
            this.button347.Click += new System.EventHandler(this.button347_Click);
            // 
            // button348
            // 
            this.button348.Location = new System.Drawing.Point(881, 469);
            this.button348.Margin = new System.Windows.Forms.Padding(0);
            this.button348.Name = "button348";
            this.button348.Size = new System.Drawing.Size(30, 33);
            this.button348.TabIndex = 376;
            this.button348.UseVisualStyleBackColor = true;
            this.button348.Click += new System.EventHandler(this.button348_Click);
            // 
            // button349
            // 
            this.button349.Location = new System.Drawing.Point(911, 469);
            this.button349.Margin = new System.Windows.Forms.Padding(0);
            this.button349.Name = "button349";
            this.button349.Size = new System.Drawing.Size(30, 33);
            this.button349.TabIndex = 375;
            this.button349.UseVisualStyleBackColor = true;
            this.button349.Click += new System.EventHandler(this.button349_Click);
            // 
            // button350
            // 
            this.button350.Location = new System.Drawing.Point(941, 469);
            this.button350.Margin = new System.Windows.Forms.Padding(0);
            this.button350.Name = "button350";
            this.button350.Size = new System.Drawing.Size(30, 33);
            this.button350.TabIndex = 374;
            this.button350.UseVisualStyleBackColor = true;
            this.button350.Click += new System.EventHandler(this.button350_Click);
            // 
            // button351
            // 
            this.button351.Location = new System.Drawing.Point(971, 469);
            this.button351.Margin = new System.Windows.Forms.Padding(0);
            this.button351.Name = "button351";
            this.button351.Size = new System.Drawing.Size(30, 33);
            this.button351.TabIndex = 373;
            this.button351.UseVisualStyleBackColor = true;
            this.button351.Click += new System.EventHandler(this.button351_Click);
            // 
            // button352
            // 
            this.button352.Location = new System.Drawing.Point(1001, 469);
            this.button352.Margin = new System.Windows.Forms.Padding(0);
            this.button352.Name = "button352";
            this.button352.Size = new System.Drawing.Size(30, 33);
            this.button352.TabIndex = 372;
            this.button352.UseVisualStyleBackColor = true;
            this.button352.Click += new System.EventHandler(this.button352_Click);
            // 
            // button353
            // 
            this.button353.Location = new System.Drawing.Point(791, 502);
            this.button353.Margin = new System.Windows.Forms.Padding(0);
            this.button353.Name = "button353";
            this.button353.Size = new System.Drawing.Size(30, 33);
            this.button353.TabIndex = 371;
            this.button353.UseVisualStyleBackColor = true;
            this.button353.Click += new System.EventHandler(this.button353_Click);
            // 
            // button354
            // 
            this.button354.Location = new System.Drawing.Point(821, 502);
            this.button354.Margin = new System.Windows.Forms.Padding(0);
            this.button354.Name = "button354";
            this.button354.Size = new System.Drawing.Size(30, 33);
            this.button354.TabIndex = 370;
            this.button354.UseVisualStyleBackColor = true;
            this.button354.Click += new System.EventHandler(this.button354_Click);
            // 
            // button355
            // 
            this.button355.Location = new System.Drawing.Point(851, 502);
            this.button355.Margin = new System.Windows.Forms.Padding(0);
            this.button355.Name = "button355";
            this.button355.Size = new System.Drawing.Size(30, 33);
            this.button355.TabIndex = 369;
            this.button355.UseVisualStyleBackColor = true;
            this.button355.Click += new System.EventHandler(this.button355_Click);
            // 
            // button356
            // 
            this.button356.Location = new System.Drawing.Point(881, 502);
            this.button356.Margin = new System.Windows.Forms.Padding(0);
            this.button356.Name = "button356";
            this.button356.Size = new System.Drawing.Size(30, 33);
            this.button356.TabIndex = 368;
            this.button356.UseVisualStyleBackColor = true;
            this.button356.Click += new System.EventHandler(this.button356_Click);
            // 
            // button357
            // 
            this.button357.Location = new System.Drawing.Point(911, 502);
            this.button357.Margin = new System.Windows.Forms.Padding(0);
            this.button357.Name = "button357";
            this.button357.Size = new System.Drawing.Size(30, 33);
            this.button357.TabIndex = 367;
            this.button357.UseVisualStyleBackColor = true;
            this.button357.Click += new System.EventHandler(this.button357_Click);
            // 
            // button358
            // 
            this.button358.Location = new System.Drawing.Point(941, 502);
            this.button358.Margin = new System.Windows.Forms.Padding(0);
            this.button358.Name = "button358";
            this.button358.Size = new System.Drawing.Size(30, 33);
            this.button358.TabIndex = 366;
            this.button358.UseVisualStyleBackColor = true;
            this.button358.Click += new System.EventHandler(this.button358_Click);
            // 
            // button359
            // 
            this.button359.Location = new System.Drawing.Point(971, 502);
            this.button359.Margin = new System.Windows.Forms.Padding(0);
            this.button359.Name = "button359";
            this.button359.Size = new System.Drawing.Size(30, 33);
            this.button359.TabIndex = 365;
            this.button359.UseVisualStyleBackColor = true;
            this.button359.Click += new System.EventHandler(this.button359_Click);
            // 
            // button360
            // 
            this.button360.Location = new System.Drawing.Point(1001, 502);
            this.button360.Margin = new System.Windows.Forms.Padding(0);
            this.button360.Name = "button360";
            this.button360.Size = new System.Drawing.Size(30, 33);
            this.button360.TabIndex = 364;
            this.button360.UseVisualStyleBackColor = true;
            this.button360.Click += new System.EventHandler(this.button360_Click);
            // 
            // button361
            // 
            this.button361.Location = new System.Drawing.Point(791, 535);
            this.button361.Margin = new System.Windows.Forms.Padding(0);
            this.button361.Name = "button361";
            this.button361.Size = new System.Drawing.Size(30, 33);
            this.button361.TabIndex = 363;
            this.button361.UseVisualStyleBackColor = true;
            this.button361.Click += new System.EventHandler(this.button361_Click);
            // 
            // button362
            // 
            this.button362.Location = new System.Drawing.Point(821, 535);
            this.button362.Margin = new System.Windows.Forms.Padding(0);
            this.button362.Name = "button362";
            this.button362.Size = new System.Drawing.Size(30, 33);
            this.button362.TabIndex = 362;
            this.button362.UseVisualStyleBackColor = true;
            this.button362.Click += new System.EventHandler(this.button362_Click);
            // 
            // button363
            // 
            this.button363.Location = new System.Drawing.Point(851, 535);
            this.button363.Margin = new System.Windows.Forms.Padding(0);
            this.button363.Name = "button363";
            this.button363.Size = new System.Drawing.Size(30, 33);
            this.button363.TabIndex = 361;
            this.button363.UseVisualStyleBackColor = true;
            this.button363.Click += new System.EventHandler(this.button363_Click);
            // 
            // button364
            // 
            this.button364.Location = new System.Drawing.Point(881, 535);
            this.button364.Margin = new System.Windows.Forms.Padding(0);
            this.button364.Name = "button364";
            this.button364.Size = new System.Drawing.Size(30, 33);
            this.button364.TabIndex = 360;
            this.button364.UseVisualStyleBackColor = true;
            this.button364.Click += new System.EventHandler(this.button364_Click);
            // 
            // button365
            // 
            this.button365.Location = new System.Drawing.Point(911, 535);
            this.button365.Margin = new System.Windows.Forms.Padding(0);
            this.button365.Name = "button365";
            this.button365.Size = new System.Drawing.Size(30, 33);
            this.button365.TabIndex = 359;
            this.button365.UseVisualStyleBackColor = true;
            this.button365.Click += new System.EventHandler(this.button365_Click);
            // 
            // button366
            // 
            this.button366.Location = new System.Drawing.Point(941, 535);
            this.button366.Margin = new System.Windows.Forms.Padding(0);
            this.button366.Name = "button366";
            this.button366.Size = new System.Drawing.Size(30, 33);
            this.button366.TabIndex = 358;
            this.button366.UseVisualStyleBackColor = true;
            this.button366.Click += new System.EventHandler(this.button366_Click);
            // 
            // button367
            // 
            this.button367.Location = new System.Drawing.Point(971, 535);
            this.button367.Margin = new System.Windows.Forms.Padding(0);
            this.button367.Name = "button367";
            this.button367.Size = new System.Drawing.Size(30, 33);
            this.button367.TabIndex = 357;
            this.button367.UseVisualStyleBackColor = true;
            this.button367.Click += new System.EventHandler(this.button367_Click);
            // 
            // button368
            // 
            this.button368.Location = new System.Drawing.Point(1001, 535);
            this.button368.Margin = new System.Windows.Forms.Padding(0);
            this.button368.Name = "button368";
            this.button368.Size = new System.Drawing.Size(30, 33);
            this.button368.TabIndex = 356;
            this.button368.UseVisualStyleBackColor = true;
            this.button368.Click += new System.EventHandler(this.button368_Click);
            // 
            // button369
            // 
            this.button369.Location = new System.Drawing.Point(791, 568);
            this.button369.Margin = new System.Windows.Forms.Padding(0);
            this.button369.Name = "button369";
            this.button369.Size = new System.Drawing.Size(30, 33);
            this.button369.TabIndex = 355;
            this.button369.UseVisualStyleBackColor = true;
            this.button369.Click += new System.EventHandler(this.button369_Click);
            // 
            // button370
            // 
            this.button370.Location = new System.Drawing.Point(821, 568);
            this.button370.Margin = new System.Windows.Forms.Padding(0);
            this.button370.Name = "button370";
            this.button370.Size = new System.Drawing.Size(30, 33);
            this.button370.TabIndex = 354;
            this.button370.UseVisualStyleBackColor = true;
            this.button370.Click += new System.EventHandler(this.button370_Click);
            // 
            // button371
            // 
            this.button371.Location = new System.Drawing.Point(851, 568);
            this.button371.Margin = new System.Windows.Forms.Padding(0);
            this.button371.Name = "button371";
            this.button371.Size = new System.Drawing.Size(30, 33);
            this.button371.TabIndex = 353;
            this.button371.UseVisualStyleBackColor = true;
            this.button371.Click += new System.EventHandler(this.button371_Click);
            // 
            // button372
            // 
            this.button372.Location = new System.Drawing.Point(881, 568);
            this.button372.Margin = new System.Windows.Forms.Padding(0);
            this.button372.Name = "button372";
            this.button372.Size = new System.Drawing.Size(30, 33);
            this.button372.TabIndex = 352;
            this.button372.UseVisualStyleBackColor = true;
            this.button372.Click += new System.EventHandler(this.button372_Click);
            // 
            // button373
            // 
            this.button373.Location = new System.Drawing.Point(911, 568);
            this.button373.Margin = new System.Windows.Forms.Padding(0);
            this.button373.Name = "button373";
            this.button373.Size = new System.Drawing.Size(30, 33);
            this.button373.TabIndex = 351;
            this.button373.UseVisualStyleBackColor = true;
            this.button373.Click += new System.EventHandler(this.button373_Click);
            // 
            // button374
            // 
            this.button374.Location = new System.Drawing.Point(941, 568);
            this.button374.Margin = new System.Windows.Forms.Padding(0);
            this.button374.Name = "button374";
            this.button374.Size = new System.Drawing.Size(30, 33);
            this.button374.TabIndex = 350;
            this.button374.UseVisualStyleBackColor = true;
            this.button374.Click += new System.EventHandler(this.button374_Click);
            // 
            // button375
            // 
            this.button375.Location = new System.Drawing.Point(971, 568);
            this.button375.Margin = new System.Windows.Forms.Padding(0);
            this.button375.Name = "button375";
            this.button375.Size = new System.Drawing.Size(30, 33);
            this.button375.TabIndex = 349;
            this.button375.UseVisualStyleBackColor = true;
            this.button375.Click += new System.EventHandler(this.button375_Click);
            // 
            // button376
            // 
            this.button376.Location = new System.Drawing.Point(1001, 568);
            this.button376.Margin = new System.Windows.Forms.Padding(0);
            this.button376.Name = "button376";
            this.button376.Size = new System.Drawing.Size(30, 33);
            this.button376.TabIndex = 348;
            this.button376.UseVisualStyleBackColor = true;
            this.button376.Click += new System.EventHandler(this.button376_Click);
            // 
            // button377
            // 
            this.button377.Location = new System.Drawing.Point(791, 601);
            this.button377.Margin = new System.Windows.Forms.Padding(0);
            this.button377.Name = "button377";
            this.button377.Size = new System.Drawing.Size(30, 33);
            this.button377.TabIndex = 347;
            this.button377.UseVisualStyleBackColor = true;
            this.button377.Click += new System.EventHandler(this.button377_Click);
            // 
            // button378
            // 
            this.button378.Location = new System.Drawing.Point(821, 601);
            this.button378.Margin = new System.Windows.Forms.Padding(0);
            this.button378.Name = "button378";
            this.button378.Size = new System.Drawing.Size(30, 33);
            this.button378.TabIndex = 346;
            this.button378.UseVisualStyleBackColor = true;
            this.button378.Click += new System.EventHandler(this.button378_Click);
            // 
            // button379
            // 
            this.button379.Location = new System.Drawing.Point(851, 601);
            this.button379.Margin = new System.Windows.Forms.Padding(0);
            this.button379.Name = "button379";
            this.button379.Size = new System.Drawing.Size(30, 33);
            this.button379.TabIndex = 345;
            this.button379.UseVisualStyleBackColor = true;
            this.button379.Click += new System.EventHandler(this.button379_Click);
            // 
            // button380
            // 
            this.button380.Location = new System.Drawing.Point(881, 601);
            this.button380.Margin = new System.Windows.Forms.Padding(0);
            this.button380.Name = "button380";
            this.button380.Size = new System.Drawing.Size(30, 33);
            this.button380.TabIndex = 344;
            this.button380.UseVisualStyleBackColor = true;
            this.button380.Click += new System.EventHandler(this.button380_Click);
            // 
            // button381
            // 
            this.button381.Location = new System.Drawing.Point(911, 601);
            this.button381.Margin = new System.Windows.Forms.Padding(0);
            this.button381.Name = "button381";
            this.button381.Size = new System.Drawing.Size(30, 33);
            this.button381.TabIndex = 343;
            this.button381.UseVisualStyleBackColor = true;
            this.button381.Click += new System.EventHandler(this.button381_Click);
            // 
            // button382
            // 
            this.button382.Location = new System.Drawing.Point(941, 601);
            this.button382.Margin = new System.Windows.Forms.Padding(0);
            this.button382.Name = "button382";
            this.button382.Size = new System.Drawing.Size(30, 33);
            this.button382.TabIndex = 342;
            this.button382.UseVisualStyleBackColor = true;
            this.button382.Click += new System.EventHandler(this.button382_Click);
            // 
            // button383
            // 
            this.button383.Location = new System.Drawing.Point(971, 601);
            this.button383.Margin = new System.Windows.Forms.Padding(0);
            this.button383.Name = "button383";
            this.button383.Size = new System.Drawing.Size(30, 33);
            this.button383.TabIndex = 341;
            this.button383.UseVisualStyleBackColor = true;
            this.button383.Click += new System.EventHandler(this.button383_Click);
            // 
            // button384
            // 
            this.button384.Location = new System.Drawing.Point(1001, 601);
            this.button384.Margin = new System.Windows.Forms.Padding(0);
            this.button384.Name = "button384";
            this.button384.Size = new System.Drawing.Size(30, 33);
            this.button384.TabIndex = 340;
            this.button384.UseVisualStyleBackColor = true;
            this.button384.Click += new System.EventHandler(this.button384_Click);
            // 
            // button385
            // 
            this.button385.Location = new System.Drawing.Point(1048, 436);
            this.button385.Margin = new System.Windows.Forms.Padding(0);
            this.button385.Name = "button385";
            this.button385.Size = new System.Drawing.Size(30, 33);
            this.button385.TabIndex = 435;
            this.button385.UseVisualStyleBackColor = true;
            this.button385.Click += new System.EventHandler(this.button385_Click);
            // 
            // button386
            // 
            this.button386.Location = new System.Drawing.Point(1078, 436);
            this.button386.Margin = new System.Windows.Forms.Padding(0);
            this.button386.Name = "button386";
            this.button386.Size = new System.Drawing.Size(30, 33);
            this.button386.TabIndex = 434;
            this.button386.UseVisualStyleBackColor = true;
            this.button386.Click += new System.EventHandler(this.button386_Click);
            // 
            // button387
            // 
            this.button387.Location = new System.Drawing.Point(1108, 436);
            this.button387.Margin = new System.Windows.Forms.Padding(0);
            this.button387.Name = "button387";
            this.button387.Size = new System.Drawing.Size(30, 33);
            this.button387.TabIndex = 433;
            this.button387.UseVisualStyleBackColor = true;
            this.button387.Click += new System.EventHandler(this.button387_Click);
            // 
            // button388
            // 
            this.button388.Location = new System.Drawing.Point(1138, 436);
            this.button388.Margin = new System.Windows.Forms.Padding(0);
            this.button388.Name = "button388";
            this.button388.Size = new System.Drawing.Size(30, 33);
            this.button388.TabIndex = 432;
            this.button388.UseVisualStyleBackColor = true;
            this.button388.Click += new System.EventHandler(this.button388_Click);
            // 
            // button389
            // 
            this.button389.Location = new System.Drawing.Point(1168, 436);
            this.button389.Margin = new System.Windows.Forms.Padding(0);
            this.button389.Name = "button389";
            this.button389.Size = new System.Drawing.Size(30, 33);
            this.button389.TabIndex = 431;
            this.button389.UseVisualStyleBackColor = true;
            this.button389.Click += new System.EventHandler(this.button389_Click);
            // 
            // button390
            // 
            this.button390.Location = new System.Drawing.Point(1198, 436);
            this.button390.Margin = new System.Windows.Forms.Padding(0);
            this.button390.Name = "button390";
            this.button390.Size = new System.Drawing.Size(30, 33);
            this.button390.TabIndex = 430;
            this.button390.UseVisualStyleBackColor = true;
            this.button390.Click += new System.EventHandler(this.button390_Click);
            // 
            // button391
            // 
            this.button391.Location = new System.Drawing.Point(1228, 436);
            this.button391.Margin = new System.Windows.Forms.Padding(0);
            this.button391.Name = "button391";
            this.button391.Size = new System.Drawing.Size(30, 33);
            this.button391.TabIndex = 429;
            this.button391.UseVisualStyleBackColor = true;
            this.button391.Click += new System.EventHandler(this.button391_Click);
            // 
            // button392
            // 
            this.button392.Location = new System.Drawing.Point(1258, 436);
            this.button392.Margin = new System.Windows.Forms.Padding(0);
            this.button392.Name = "button392";
            this.button392.Size = new System.Drawing.Size(30, 33);
            this.button392.TabIndex = 428;
            this.button392.UseVisualStyleBackColor = true;
            this.button392.Click += new System.EventHandler(this.button392_Click);
            // 
            // button393
            // 
            this.button393.Location = new System.Drawing.Point(1048, 469);
            this.button393.Margin = new System.Windows.Forms.Padding(0);
            this.button393.Name = "button393";
            this.button393.Size = new System.Drawing.Size(30, 33);
            this.button393.TabIndex = 427;
            this.button393.UseVisualStyleBackColor = true;
            this.button393.Click += new System.EventHandler(this.button393_Click);
            // 
            // button394
            // 
            this.button394.Location = new System.Drawing.Point(1078, 469);
            this.button394.Margin = new System.Windows.Forms.Padding(0);
            this.button394.Name = "button394";
            this.button394.Size = new System.Drawing.Size(30, 33);
            this.button394.TabIndex = 426;
            this.button394.UseVisualStyleBackColor = true;
            this.button394.Click += new System.EventHandler(this.button394_Click);
            // 
            // button395
            // 
            this.button395.Location = new System.Drawing.Point(1108, 469);
            this.button395.Margin = new System.Windows.Forms.Padding(0);
            this.button395.Name = "button395";
            this.button395.Size = new System.Drawing.Size(30, 33);
            this.button395.TabIndex = 425;
            this.button395.UseVisualStyleBackColor = true;
            this.button395.Click += new System.EventHandler(this.button395_Click);
            // 
            // button396
            // 
            this.button396.Location = new System.Drawing.Point(1138, 469);
            this.button396.Margin = new System.Windows.Forms.Padding(0);
            this.button396.Name = "button396";
            this.button396.Size = new System.Drawing.Size(30, 33);
            this.button396.TabIndex = 424;
            this.button396.UseVisualStyleBackColor = true;
            this.button396.Click += new System.EventHandler(this.button396_Click);
            // 
            // button397
            // 
            this.button397.Location = new System.Drawing.Point(1168, 469);
            this.button397.Margin = new System.Windows.Forms.Padding(0);
            this.button397.Name = "button397";
            this.button397.Size = new System.Drawing.Size(30, 33);
            this.button397.TabIndex = 423;
            this.button397.UseVisualStyleBackColor = true;
            this.button397.Click += new System.EventHandler(this.button397_Click);
            // 
            // button398
            // 
            this.button398.Location = new System.Drawing.Point(1198, 469);
            this.button398.Margin = new System.Windows.Forms.Padding(0);
            this.button398.Name = "button398";
            this.button398.Size = new System.Drawing.Size(30, 33);
            this.button398.TabIndex = 422;
            this.button398.UseVisualStyleBackColor = true;
            this.button398.Click += new System.EventHandler(this.button398_Click);
            // 
            // button399
            // 
            this.button399.Location = new System.Drawing.Point(1228, 469);
            this.button399.Margin = new System.Windows.Forms.Padding(0);
            this.button399.Name = "button399";
            this.button399.Size = new System.Drawing.Size(30, 33);
            this.button399.TabIndex = 421;
            this.button399.UseVisualStyleBackColor = true;
            this.button399.Click += new System.EventHandler(this.button399_Click);
            // 
            // button400
            // 
            this.button400.Location = new System.Drawing.Point(1258, 469);
            this.button400.Margin = new System.Windows.Forms.Padding(0);
            this.button400.Name = "button400";
            this.button400.Size = new System.Drawing.Size(30, 33);
            this.button400.TabIndex = 420;
            this.button400.UseVisualStyleBackColor = true;
            this.button400.Click += new System.EventHandler(this.button400_Click);
            // 
            // button401
            // 
            this.button401.Location = new System.Drawing.Point(1048, 502);
            this.button401.Margin = new System.Windows.Forms.Padding(0);
            this.button401.Name = "button401";
            this.button401.Size = new System.Drawing.Size(30, 33);
            this.button401.TabIndex = 419;
            this.button401.UseVisualStyleBackColor = true;
            this.button401.Click += new System.EventHandler(this.button401_Click);
            // 
            // button402
            // 
            this.button402.Location = new System.Drawing.Point(1078, 502);
            this.button402.Margin = new System.Windows.Forms.Padding(0);
            this.button402.Name = "button402";
            this.button402.Size = new System.Drawing.Size(30, 33);
            this.button402.TabIndex = 418;
            this.button402.UseVisualStyleBackColor = true;
            this.button402.Click += new System.EventHandler(this.button402_Click);
            // 
            // button403
            // 
            this.button403.Location = new System.Drawing.Point(1108, 502);
            this.button403.Margin = new System.Windows.Forms.Padding(0);
            this.button403.Name = "button403";
            this.button403.Size = new System.Drawing.Size(30, 33);
            this.button403.TabIndex = 417;
            this.button403.UseVisualStyleBackColor = true;
            this.button403.Click += new System.EventHandler(this.button403_Click);
            // 
            // button404
            // 
            this.button404.Location = new System.Drawing.Point(1138, 502);
            this.button404.Margin = new System.Windows.Forms.Padding(0);
            this.button404.Name = "button404";
            this.button404.Size = new System.Drawing.Size(30, 33);
            this.button404.TabIndex = 416;
            this.button404.UseVisualStyleBackColor = true;
            this.button404.Click += new System.EventHandler(this.button404_Click);
            // 
            // button405
            // 
            this.button405.Location = new System.Drawing.Point(1168, 502);
            this.button405.Margin = new System.Windows.Forms.Padding(0);
            this.button405.Name = "button405";
            this.button405.Size = new System.Drawing.Size(30, 33);
            this.button405.TabIndex = 415;
            this.button405.UseVisualStyleBackColor = true;
            this.button405.Click += new System.EventHandler(this.button405_Click);
            // 
            // button406
            // 
            this.button406.Location = new System.Drawing.Point(1198, 502);
            this.button406.Margin = new System.Windows.Forms.Padding(0);
            this.button406.Name = "button406";
            this.button406.Size = new System.Drawing.Size(30, 33);
            this.button406.TabIndex = 414;
            this.button406.UseVisualStyleBackColor = true;
            this.button406.Click += new System.EventHandler(this.button406_Click);
            // 
            // button407
            // 
            this.button407.Location = new System.Drawing.Point(1228, 502);
            this.button407.Margin = new System.Windows.Forms.Padding(0);
            this.button407.Name = "button407";
            this.button407.Size = new System.Drawing.Size(30, 33);
            this.button407.TabIndex = 413;
            this.button407.UseVisualStyleBackColor = true;
            this.button407.Click += new System.EventHandler(this.button407_Click);
            // 
            // button408
            // 
            this.button408.Location = new System.Drawing.Point(1258, 502);
            this.button408.Margin = new System.Windows.Forms.Padding(0);
            this.button408.Name = "button408";
            this.button408.Size = new System.Drawing.Size(30, 33);
            this.button408.TabIndex = 412;
            this.button408.UseVisualStyleBackColor = true;
            this.button408.Click += new System.EventHandler(this.button408_Click);
            // 
            // button409
            // 
            this.button409.Location = new System.Drawing.Point(1048, 535);
            this.button409.Margin = new System.Windows.Forms.Padding(0);
            this.button409.Name = "button409";
            this.button409.Size = new System.Drawing.Size(30, 33);
            this.button409.TabIndex = 411;
            this.button409.UseVisualStyleBackColor = true;
            this.button409.Click += new System.EventHandler(this.button409_Click);
            // 
            // button410
            // 
            this.button410.Location = new System.Drawing.Point(1078, 535);
            this.button410.Margin = new System.Windows.Forms.Padding(0);
            this.button410.Name = "button410";
            this.button410.Size = new System.Drawing.Size(30, 33);
            this.button410.TabIndex = 410;
            this.button410.UseVisualStyleBackColor = true;
            this.button410.Click += new System.EventHandler(this.button410_Click);
            // 
            // button411
            // 
            this.button411.Location = new System.Drawing.Point(1108, 535);
            this.button411.Margin = new System.Windows.Forms.Padding(0);
            this.button411.Name = "button411";
            this.button411.Size = new System.Drawing.Size(30, 33);
            this.button411.TabIndex = 409;
            this.button411.UseVisualStyleBackColor = true;
            this.button411.Click += new System.EventHandler(this.button411_Click);
            // 
            // button412
            // 
            this.button412.Location = new System.Drawing.Point(1138, 535);
            this.button412.Margin = new System.Windows.Forms.Padding(0);
            this.button412.Name = "button412";
            this.button412.Size = new System.Drawing.Size(30, 33);
            this.button412.TabIndex = 408;
            this.button412.UseVisualStyleBackColor = true;
            this.button412.Click += new System.EventHandler(this.button412_Click);
            // 
            // button413
            // 
            this.button413.Location = new System.Drawing.Point(1168, 535);
            this.button413.Margin = new System.Windows.Forms.Padding(0);
            this.button413.Name = "button413";
            this.button413.Size = new System.Drawing.Size(30, 33);
            this.button413.TabIndex = 407;
            this.button413.UseVisualStyleBackColor = true;
            this.button413.Click += new System.EventHandler(this.button413_Click);
            // 
            // button414
            // 
            this.button414.Location = new System.Drawing.Point(1198, 535);
            this.button414.Margin = new System.Windows.Forms.Padding(0);
            this.button414.Name = "button414";
            this.button414.Size = new System.Drawing.Size(30, 33);
            this.button414.TabIndex = 406;
            this.button414.UseVisualStyleBackColor = true;
            this.button414.Click += new System.EventHandler(this.button414_Click);
            // 
            // button415
            // 
            this.button415.Location = new System.Drawing.Point(1228, 535);
            this.button415.Margin = new System.Windows.Forms.Padding(0);
            this.button415.Name = "button415";
            this.button415.Size = new System.Drawing.Size(30, 33);
            this.button415.TabIndex = 405;
            this.button415.UseVisualStyleBackColor = true;
            this.button415.Click += new System.EventHandler(this.button415_Click);
            // 
            // button416
            // 
            this.button416.Location = new System.Drawing.Point(1258, 535);
            this.button416.Margin = new System.Windows.Forms.Padding(0);
            this.button416.Name = "button416";
            this.button416.Size = new System.Drawing.Size(30, 33);
            this.button416.TabIndex = 404;
            this.button416.UseVisualStyleBackColor = true;
            this.button416.Click += new System.EventHandler(this.button416_Click);
            // 
            // button417
            // 
            this.button417.Location = new System.Drawing.Point(1048, 568);
            this.button417.Margin = new System.Windows.Forms.Padding(0);
            this.button417.Name = "button417";
            this.button417.Size = new System.Drawing.Size(30, 33);
            this.button417.TabIndex = 403;
            this.button417.UseVisualStyleBackColor = true;
            this.button417.Click += new System.EventHandler(this.button417_Click);
            // 
            // button418
            // 
            this.button418.Location = new System.Drawing.Point(1078, 568);
            this.button418.Margin = new System.Windows.Forms.Padding(0);
            this.button418.Name = "button418";
            this.button418.Size = new System.Drawing.Size(30, 33);
            this.button418.TabIndex = 402;
            this.button418.UseVisualStyleBackColor = true;
            this.button418.Click += new System.EventHandler(this.button418_Click);
            // 
            // button419
            // 
            this.button419.Location = new System.Drawing.Point(1108, 568);
            this.button419.Margin = new System.Windows.Forms.Padding(0);
            this.button419.Name = "button419";
            this.button419.Size = new System.Drawing.Size(30, 33);
            this.button419.TabIndex = 401;
            this.button419.UseVisualStyleBackColor = true;
            this.button419.Click += new System.EventHandler(this.button419_Click);
            // 
            // button420
            // 
            this.button420.Location = new System.Drawing.Point(1138, 568);
            this.button420.Margin = new System.Windows.Forms.Padding(0);
            this.button420.Name = "button420";
            this.button420.Size = new System.Drawing.Size(30, 33);
            this.button420.TabIndex = 400;
            this.button420.UseVisualStyleBackColor = true;
            this.button420.Click += new System.EventHandler(this.button420_Click);
            // 
            // button421
            // 
            this.button421.Location = new System.Drawing.Point(1168, 568);
            this.button421.Margin = new System.Windows.Forms.Padding(0);
            this.button421.Name = "button421";
            this.button421.Size = new System.Drawing.Size(30, 33);
            this.button421.TabIndex = 399;
            this.button421.UseVisualStyleBackColor = true;
            this.button421.Click += new System.EventHandler(this.button421_Click);
            // 
            // button422
            // 
            this.button422.Location = new System.Drawing.Point(1198, 568);
            this.button422.Margin = new System.Windows.Forms.Padding(0);
            this.button422.Name = "button422";
            this.button422.Size = new System.Drawing.Size(30, 33);
            this.button422.TabIndex = 398;
            this.button422.UseVisualStyleBackColor = true;
            this.button422.Click += new System.EventHandler(this.button422_Click);
            // 
            // button423
            // 
            this.button423.Location = new System.Drawing.Point(1228, 568);
            this.button423.Margin = new System.Windows.Forms.Padding(0);
            this.button423.Name = "button423";
            this.button423.Size = new System.Drawing.Size(30, 33);
            this.button423.TabIndex = 397;
            this.button423.UseVisualStyleBackColor = true;
            this.button423.Click += new System.EventHandler(this.button423_Click);
            // 
            // button424
            // 
            this.button424.Location = new System.Drawing.Point(1258, 568);
            this.button424.Margin = new System.Windows.Forms.Padding(0);
            this.button424.Name = "button424";
            this.button424.Size = new System.Drawing.Size(30, 33);
            this.button424.TabIndex = 396;
            this.button424.UseVisualStyleBackColor = true;
            this.button424.Click += new System.EventHandler(this.button424_Click);
            // 
            // button425
            // 
            this.button425.Location = new System.Drawing.Point(1048, 601);
            this.button425.Margin = new System.Windows.Forms.Padding(0);
            this.button425.Name = "button425";
            this.button425.Size = new System.Drawing.Size(30, 33);
            this.button425.TabIndex = 395;
            this.button425.UseVisualStyleBackColor = true;
            this.button425.Click += new System.EventHandler(this.button425_Click);
            // 
            // button426
            // 
            this.button426.Location = new System.Drawing.Point(1078, 601);
            this.button426.Margin = new System.Windows.Forms.Padding(0);
            this.button426.Name = "button426";
            this.button426.Size = new System.Drawing.Size(30, 33);
            this.button426.TabIndex = 394;
            this.button426.UseVisualStyleBackColor = true;
            this.button426.Click += new System.EventHandler(this.button426_Click);
            // 
            // button427
            // 
            this.button427.Location = new System.Drawing.Point(1108, 601);
            this.button427.Margin = new System.Windows.Forms.Padding(0);
            this.button427.Name = "button427";
            this.button427.Size = new System.Drawing.Size(30, 33);
            this.button427.TabIndex = 393;
            this.button427.UseVisualStyleBackColor = true;
            this.button427.Click += new System.EventHandler(this.button427_Click);
            // 
            // button428
            // 
            this.button428.Location = new System.Drawing.Point(1138, 601);
            this.button428.Margin = new System.Windows.Forms.Padding(0);
            this.button428.Name = "button428";
            this.button428.Size = new System.Drawing.Size(30, 33);
            this.button428.TabIndex = 392;
            this.button428.UseVisualStyleBackColor = true;
            this.button428.Click += new System.EventHandler(this.button428_Click);
            // 
            // button429
            // 
            this.button429.Location = new System.Drawing.Point(1168, 601);
            this.button429.Margin = new System.Windows.Forms.Padding(0);
            this.button429.Name = "button429";
            this.button429.Size = new System.Drawing.Size(30, 33);
            this.button429.TabIndex = 391;
            this.button429.UseVisualStyleBackColor = true;
            this.button429.Click += new System.EventHandler(this.button429_Click);
            // 
            // button430
            // 
            this.button430.Location = new System.Drawing.Point(1198, 601);
            this.button430.Margin = new System.Windows.Forms.Padding(0);
            this.button430.Name = "button430";
            this.button430.Size = new System.Drawing.Size(30, 33);
            this.button430.TabIndex = 390;
            this.button430.UseVisualStyleBackColor = true;
            this.button430.Click += new System.EventHandler(this.button430_Click);
            // 
            // button431
            // 
            this.button431.Location = new System.Drawing.Point(1228, 601);
            this.button431.Margin = new System.Windows.Forms.Padding(0);
            this.button431.Name = "button431";
            this.button431.Size = new System.Drawing.Size(30, 33);
            this.button431.TabIndex = 389;
            this.button431.UseVisualStyleBackColor = true;
            this.button431.Click += new System.EventHandler(this.button431_Click);
            // 
            // button432
            // 
            this.button432.Location = new System.Drawing.Point(1258, 601);
            this.button432.Margin = new System.Windows.Forms.Padding(0);
            this.button432.Name = "button432";
            this.button432.Size = new System.Drawing.Size(30, 33);
            this.button432.TabIndex = 388;
            this.button432.UseVisualStyleBackColor = true;
            this.button432.Click += new System.EventHandler(this.button432_Click);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(8, 115);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(47, 17);
            this.radioButton5.TabIndex = 772;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Hole";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(8, 138);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(56, 17);
            this.radioButton6.TabIndex = 773;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "Crystal";
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(8, 243);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(96, 54);
            this.clearButton.TabIndex = 774;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1461, 1061);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.radioButton6);
            this.Controls.Add(this.radioButton5);
            this.Controls.Add(this.button385);
            this.Controls.Add(this.button386);
            this.Controls.Add(this.button387);
            this.Controls.Add(this.button388);
            this.Controls.Add(this.button389);
            this.Controls.Add(this.button390);
            this.Controls.Add(this.button391);
            this.Controls.Add(this.button392);
            this.Controls.Add(this.button393);
            this.Controls.Add(this.button394);
            this.Controls.Add(this.button395);
            this.Controls.Add(this.button396);
            this.Controls.Add(this.button397);
            this.Controls.Add(this.button398);
            this.Controls.Add(this.button399);
            this.Controls.Add(this.button400);
            this.Controls.Add(this.button401);
            this.Controls.Add(this.button402);
            this.Controls.Add(this.button403);
            this.Controls.Add(this.button404);
            this.Controls.Add(this.button405);
            this.Controls.Add(this.button406);
            this.Controls.Add(this.button407);
            this.Controls.Add(this.button408);
            this.Controls.Add(this.button409);
            this.Controls.Add(this.button410);
            this.Controls.Add(this.button411);
            this.Controls.Add(this.button412);
            this.Controls.Add(this.button413);
            this.Controls.Add(this.button414);
            this.Controls.Add(this.button415);
            this.Controls.Add(this.button416);
            this.Controls.Add(this.button417);
            this.Controls.Add(this.button418);
            this.Controls.Add(this.button419);
            this.Controls.Add(this.button420);
            this.Controls.Add(this.button421);
            this.Controls.Add(this.button422);
            this.Controls.Add(this.button423);
            this.Controls.Add(this.button424);
            this.Controls.Add(this.button425);
            this.Controls.Add(this.button426);
            this.Controls.Add(this.button427);
            this.Controls.Add(this.button428);
            this.Controls.Add(this.button429);
            this.Controls.Add(this.button430);
            this.Controls.Add(this.button431);
            this.Controls.Add(this.button432);
            this.Controls.Add(this.button337);
            this.Controls.Add(this.button338);
            this.Controls.Add(this.button339);
            this.Controls.Add(this.button340);
            this.Controls.Add(this.button341);
            this.Controls.Add(this.button342);
            this.Controls.Add(this.button343);
            this.Controls.Add(this.button344);
            this.Controls.Add(this.button345);
            this.Controls.Add(this.button346);
            this.Controls.Add(this.button347);
            this.Controls.Add(this.button348);
            this.Controls.Add(this.button349);
            this.Controls.Add(this.button350);
            this.Controls.Add(this.button351);
            this.Controls.Add(this.button352);
            this.Controls.Add(this.button353);
            this.Controls.Add(this.button354);
            this.Controls.Add(this.button355);
            this.Controls.Add(this.button356);
            this.Controls.Add(this.button357);
            this.Controls.Add(this.button358);
            this.Controls.Add(this.button359);
            this.Controls.Add(this.button360);
            this.Controls.Add(this.button361);
            this.Controls.Add(this.button362);
            this.Controls.Add(this.button363);
            this.Controls.Add(this.button364);
            this.Controls.Add(this.button365);
            this.Controls.Add(this.button366);
            this.Controls.Add(this.button367);
            this.Controls.Add(this.button368);
            this.Controls.Add(this.button369);
            this.Controls.Add(this.button370);
            this.Controls.Add(this.button371);
            this.Controls.Add(this.button372);
            this.Controls.Add(this.button373);
            this.Controls.Add(this.button374);
            this.Controls.Add(this.button375);
            this.Controls.Add(this.button376);
            this.Controls.Add(this.button377);
            this.Controls.Add(this.button378);
            this.Controls.Add(this.button379);
            this.Controls.Add(this.button380);
            this.Controls.Add(this.button381);
            this.Controls.Add(this.button382);
            this.Controls.Add(this.button383);
            this.Controls.Add(this.button384);
            this.Controls.Add(this.button289);
            this.Controls.Add(this.button290);
            this.Controls.Add(this.button291);
            this.Controls.Add(this.button292);
            this.Controls.Add(this.button293);
            this.Controls.Add(this.button294);
            this.Controls.Add(this.button295);
            this.Controls.Add(this.button296);
            this.Controls.Add(this.button297);
            this.Controls.Add(this.button298);
            this.Controls.Add(this.button299);
            this.Controls.Add(this.button300);
            this.Controls.Add(this.button301);
            this.Controls.Add(this.button302);
            this.Controls.Add(this.button303);
            this.Controls.Add(this.button304);
            this.Controls.Add(this.button305);
            this.Controls.Add(this.button306);
            this.Controls.Add(this.button307);
            this.Controls.Add(this.button308);
            this.Controls.Add(this.button309);
            this.Controls.Add(this.button310);
            this.Controls.Add(this.button311);
            this.Controls.Add(this.button312);
            this.Controls.Add(this.button313);
            this.Controls.Add(this.button314);
            this.Controls.Add(this.button315);
            this.Controls.Add(this.button316);
            this.Controls.Add(this.button317);
            this.Controls.Add(this.button318);
            this.Controls.Add(this.button319);
            this.Controls.Add(this.button320);
            this.Controls.Add(this.button321);
            this.Controls.Add(this.button322);
            this.Controls.Add(this.button323);
            this.Controls.Add(this.button324);
            this.Controls.Add(this.button325);
            this.Controls.Add(this.button326);
            this.Controls.Add(this.button327);
            this.Controls.Add(this.button328);
            this.Controls.Add(this.button329);
            this.Controls.Add(this.button330);
            this.Controls.Add(this.button331);
            this.Controls.Add(this.button332);
            this.Controls.Add(this.button333);
            this.Controls.Add(this.button334);
            this.Controls.Add(this.button335);
            this.Controls.Add(this.button336);
            this.Controls.Add(this.button241);
            this.Controls.Add(this.button242);
            this.Controls.Add(this.button243);
            this.Controls.Add(this.button244);
            this.Controls.Add(this.button245);
            this.Controls.Add(this.button246);
            this.Controls.Add(this.button247);
            this.Controls.Add(this.button248);
            this.Controls.Add(this.button249);
            this.Controls.Add(this.button250);
            this.Controls.Add(this.button251);
            this.Controls.Add(this.button252);
            this.Controls.Add(this.button253);
            this.Controls.Add(this.button254);
            this.Controls.Add(this.button255);
            this.Controls.Add(this.button256);
            this.Controls.Add(this.button257);
            this.Controls.Add(this.button258);
            this.Controls.Add(this.button259);
            this.Controls.Add(this.button260);
            this.Controls.Add(this.button261);
            this.Controls.Add(this.button262);
            this.Controls.Add(this.button263);
            this.Controls.Add(this.button264);
            this.Controls.Add(this.button265);
            this.Controls.Add(this.button266);
            this.Controls.Add(this.button267);
            this.Controls.Add(this.button268);
            this.Controls.Add(this.button269);
            this.Controls.Add(this.button270);
            this.Controls.Add(this.button271);
            this.Controls.Add(this.button272);
            this.Controls.Add(this.button273);
            this.Controls.Add(this.button274);
            this.Controls.Add(this.button275);
            this.Controls.Add(this.button276);
            this.Controls.Add(this.button277);
            this.Controls.Add(this.button278);
            this.Controls.Add(this.button279);
            this.Controls.Add(this.button280);
            this.Controls.Add(this.button281);
            this.Controls.Add(this.button282);
            this.Controls.Add(this.button283);
            this.Controls.Add(this.button284);
            this.Controls.Add(this.button285);
            this.Controls.Add(this.button286);
            this.Controls.Add(this.button287);
            this.Controls.Add(this.button288);
            this.Controls.Add(this.button193);
            this.Controls.Add(this.button194);
            this.Controls.Add(this.button195);
            this.Controls.Add(this.button196);
            this.Controls.Add(this.button197);
            this.Controls.Add(this.button198);
            this.Controls.Add(this.button199);
            this.Controls.Add(this.button200);
            this.Controls.Add(this.button201);
            this.Controls.Add(this.button202);
            this.Controls.Add(this.button203);
            this.Controls.Add(this.button204);
            this.Controls.Add(this.button205);
            this.Controls.Add(this.button206);
            this.Controls.Add(this.button207);
            this.Controls.Add(this.button208);
            this.Controls.Add(this.button209);
            this.Controls.Add(this.button210);
            this.Controls.Add(this.button211);
            this.Controls.Add(this.button212);
            this.Controls.Add(this.button213);
            this.Controls.Add(this.button214);
            this.Controls.Add(this.button215);
            this.Controls.Add(this.button216);
            this.Controls.Add(this.button217);
            this.Controls.Add(this.button218);
            this.Controls.Add(this.button219);
            this.Controls.Add(this.button220);
            this.Controls.Add(this.button221);
            this.Controls.Add(this.button222);
            this.Controls.Add(this.button223);
            this.Controls.Add(this.button224);
            this.Controls.Add(this.button225);
            this.Controls.Add(this.button226);
            this.Controls.Add(this.button227);
            this.Controls.Add(this.button228);
            this.Controls.Add(this.button229);
            this.Controls.Add(this.button230);
            this.Controls.Add(this.button231);
            this.Controls.Add(this.button232);
            this.Controls.Add(this.button233);
            this.Controls.Add(this.button234);
            this.Controls.Add(this.button235);
            this.Controls.Add(this.button236);
            this.Controls.Add(this.button237);
            this.Controls.Add(this.button238);
            this.Controls.Add(this.button239);
            this.Controls.Add(this.button240);
            this.Controls.Add(this.button145);
            this.Controls.Add(this.button146);
            this.Controls.Add(this.button147);
            this.Controls.Add(this.button148);
            this.Controls.Add(this.button149);
            this.Controls.Add(this.button150);
            this.Controls.Add(this.button151);
            this.Controls.Add(this.button152);
            this.Controls.Add(this.button153);
            this.Controls.Add(this.button154);
            this.Controls.Add(this.button155);
            this.Controls.Add(this.button156);
            this.Controls.Add(this.button157);
            this.Controls.Add(this.button158);
            this.Controls.Add(this.button159);
            this.Controls.Add(this.button160);
            this.Controls.Add(this.button161);
            this.Controls.Add(this.button162);
            this.Controls.Add(this.button163);
            this.Controls.Add(this.button164);
            this.Controls.Add(this.button165);
            this.Controls.Add(this.button166);
            this.Controls.Add(this.button167);
            this.Controls.Add(this.button168);
            this.Controls.Add(this.button169);
            this.Controls.Add(this.button170);
            this.Controls.Add(this.button171);
            this.Controls.Add(this.button172);
            this.Controls.Add(this.button173);
            this.Controls.Add(this.button174);
            this.Controls.Add(this.button175);
            this.Controls.Add(this.button176);
            this.Controls.Add(this.button177);
            this.Controls.Add(this.button178);
            this.Controls.Add(this.button179);
            this.Controls.Add(this.button180);
            this.Controls.Add(this.button181);
            this.Controls.Add(this.button182);
            this.Controls.Add(this.button183);
            this.Controls.Add(this.button184);
            this.Controls.Add(this.button185);
            this.Controls.Add(this.button186);
            this.Controls.Add(this.button187);
            this.Controls.Add(this.button188);
            this.Controls.Add(this.button189);
            this.Controls.Add(this.button190);
            this.Controls.Add(this.button191);
            this.Controls.Add(this.button192);
            this.Controls.Add(this.button97);
            this.Controls.Add(this.button98);
            this.Controls.Add(this.button99);
            this.Controls.Add(this.button100);
            this.Controls.Add(this.button101);
            this.Controls.Add(this.button102);
            this.Controls.Add(this.button103);
            this.Controls.Add(this.button104);
            this.Controls.Add(this.button105);
            this.Controls.Add(this.button106);
            this.Controls.Add(this.button107);
            this.Controls.Add(this.button108);
            this.Controls.Add(this.button109);
            this.Controls.Add(this.button110);
            this.Controls.Add(this.button111);
            this.Controls.Add(this.button112);
            this.Controls.Add(this.button113);
            this.Controls.Add(this.button114);
            this.Controls.Add(this.button115);
            this.Controls.Add(this.button116);
            this.Controls.Add(this.button117);
            this.Controls.Add(this.button118);
            this.Controls.Add(this.button119);
            this.Controls.Add(this.button120);
            this.Controls.Add(this.button121);
            this.Controls.Add(this.button122);
            this.Controls.Add(this.button123);
            this.Controls.Add(this.button124);
            this.Controls.Add(this.button125);
            this.Controls.Add(this.button126);
            this.Controls.Add(this.button127);
            this.Controls.Add(this.button128);
            this.Controls.Add(this.button129);
            this.Controls.Add(this.button130);
            this.Controls.Add(this.button131);
            this.Controls.Add(this.button132);
            this.Controls.Add(this.button133);
            this.Controls.Add(this.button134);
            this.Controls.Add(this.button135);
            this.Controls.Add(this.button136);
            this.Controls.Add(this.button137);
            this.Controls.Add(this.button138);
            this.Controls.Add(this.button139);
            this.Controls.Add(this.button140);
            this.Controls.Add(this.button141);
            this.Controls.Add(this.button142);
            this.Controls.Add(this.button143);
            this.Controls.Add(this.button144);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button52);
            this.Controls.Add(this.button53);
            this.Controls.Add(this.button54);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button59);
            this.Controls.Add(this.button60);
            this.Controls.Add(this.button61);
            this.Controls.Add(this.button62);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button64);
            this.Controls.Add(this.button65);
            this.Controls.Add(this.button66);
            this.Controls.Add(this.button67);
            this.Controls.Add(this.button68);
            this.Controls.Add(this.button69);
            this.Controls.Add(this.button70);
            this.Controls.Add(this.button71);
            this.Controls.Add(this.button72);
            this.Controls.Add(this.button73);
            this.Controls.Add(this.button74);
            this.Controls.Add(this.button75);
            this.Controls.Add(this.button76);
            this.Controls.Add(this.button77);
            this.Controls.Add(this.button78);
            this.Controls.Add(this.button79);
            this.Controls.Add(this.button80);
            this.Controls.Add(this.button81);
            this.Controls.Add(this.button82);
            this.Controls.Add(this.button83);
            this.Controls.Add(this.button84);
            this.Controls.Add(this.button85);
            this.Controls.Add(this.button86);
            this.Controls.Add(this.button87);
            this.Controls.Add(this.button88);
            this.Controls.Add(this.button89);
            this.Controls.Add(this.button90);
            this.Controls.Add(this.button91);
            this.Controls.Add(this.button92);
            this.Controls.Add(this.button93);
            this.Controls.Add(this.button94);
            this.Controls.Add(this.button95);
            this.Controls.Add(this.button96);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.Button button111;
        private System.Windows.Forms.Button button112;
        private System.Windows.Forms.Button button113;
        private System.Windows.Forms.Button button114;
        private System.Windows.Forms.Button button115;
        private System.Windows.Forms.Button button116;
        private System.Windows.Forms.Button button117;
        private System.Windows.Forms.Button button118;
        private System.Windows.Forms.Button button119;
        private System.Windows.Forms.Button button120;
        private System.Windows.Forms.Button button121;
        private System.Windows.Forms.Button button122;
        private System.Windows.Forms.Button button123;
        private System.Windows.Forms.Button button124;
        private System.Windows.Forms.Button button125;
        private System.Windows.Forms.Button button126;
        private System.Windows.Forms.Button button127;
        private System.Windows.Forms.Button button128;
        private System.Windows.Forms.Button button129;
        private System.Windows.Forms.Button button130;
        private System.Windows.Forms.Button button131;
        private System.Windows.Forms.Button button132;
        private System.Windows.Forms.Button button133;
        private System.Windows.Forms.Button button134;
        private System.Windows.Forms.Button button135;
        private System.Windows.Forms.Button button136;
        private System.Windows.Forms.Button button137;
        private System.Windows.Forms.Button button138;
        private System.Windows.Forms.Button button139;
        private System.Windows.Forms.Button button140;
        private System.Windows.Forms.Button button141;
        private System.Windows.Forms.Button button142;
        private System.Windows.Forms.Button button143;
        private System.Windows.Forms.Button button144;
        private System.Windows.Forms.Button button145;
        private System.Windows.Forms.Button button146;
        private System.Windows.Forms.Button button147;
        private System.Windows.Forms.Button button148;
        private System.Windows.Forms.Button button149;
        private System.Windows.Forms.Button button150;
        private System.Windows.Forms.Button button151;
        private System.Windows.Forms.Button button152;
        private System.Windows.Forms.Button button153;
        private System.Windows.Forms.Button button154;
        private System.Windows.Forms.Button button155;
        private System.Windows.Forms.Button button156;
        private System.Windows.Forms.Button button157;
        private System.Windows.Forms.Button button158;
        private System.Windows.Forms.Button button159;
        private System.Windows.Forms.Button button160;
        private System.Windows.Forms.Button button161;
        private System.Windows.Forms.Button button162;
        private System.Windows.Forms.Button button163;
        private System.Windows.Forms.Button button164;
        private System.Windows.Forms.Button button165;
        private System.Windows.Forms.Button button166;
        private System.Windows.Forms.Button button167;
        private System.Windows.Forms.Button button168;
        private System.Windows.Forms.Button button169;
        private System.Windows.Forms.Button button170;
        private System.Windows.Forms.Button button171;
        private System.Windows.Forms.Button button172;
        private System.Windows.Forms.Button button173;
        private System.Windows.Forms.Button button174;
        private System.Windows.Forms.Button button175;
        private System.Windows.Forms.Button button176;
        private System.Windows.Forms.Button button177;
        private System.Windows.Forms.Button button178;
        private System.Windows.Forms.Button button179;
        private System.Windows.Forms.Button button180;
        private System.Windows.Forms.Button button181;
        private System.Windows.Forms.Button button182;
        private System.Windows.Forms.Button button183;
        private System.Windows.Forms.Button button184;
        private System.Windows.Forms.Button button185;
        private System.Windows.Forms.Button button186;
        private System.Windows.Forms.Button button187;
        private System.Windows.Forms.Button button188;
        private System.Windows.Forms.Button button189;
        private System.Windows.Forms.Button button190;
        private System.Windows.Forms.Button button191;
        private System.Windows.Forms.Button button192;
        private System.Windows.Forms.Button button193;
        private System.Windows.Forms.Button button194;
        private System.Windows.Forms.Button button195;
        private System.Windows.Forms.Button button196;
        private System.Windows.Forms.Button button197;
        private System.Windows.Forms.Button button198;
        private System.Windows.Forms.Button button199;
        private System.Windows.Forms.Button button200;
        private System.Windows.Forms.Button button201;
        private System.Windows.Forms.Button button202;
        private System.Windows.Forms.Button button203;
        private System.Windows.Forms.Button button204;
        private System.Windows.Forms.Button button205;
        private System.Windows.Forms.Button button206;
        private System.Windows.Forms.Button button207;
        private System.Windows.Forms.Button button208;
        private System.Windows.Forms.Button button209;
        private System.Windows.Forms.Button button210;
        private System.Windows.Forms.Button button211;
        private System.Windows.Forms.Button button212;
        private System.Windows.Forms.Button button213;
        private System.Windows.Forms.Button button214;
        private System.Windows.Forms.Button button215;
        private System.Windows.Forms.Button button216;
        private System.Windows.Forms.Button button217;
        private System.Windows.Forms.Button button218;
        private System.Windows.Forms.Button button219;
        private System.Windows.Forms.Button button220;
        private System.Windows.Forms.Button button221;
        private System.Windows.Forms.Button button222;
        private System.Windows.Forms.Button button223;
        private System.Windows.Forms.Button button224;
        private System.Windows.Forms.Button button225;
        private System.Windows.Forms.Button button226;
        private System.Windows.Forms.Button button227;
        private System.Windows.Forms.Button button228;
        private System.Windows.Forms.Button button229;
        private System.Windows.Forms.Button button230;
        private System.Windows.Forms.Button button231;
        private System.Windows.Forms.Button button232;
        private System.Windows.Forms.Button button233;
        private System.Windows.Forms.Button button234;
        private System.Windows.Forms.Button button235;
        private System.Windows.Forms.Button button236;
        private System.Windows.Forms.Button button237;
        private System.Windows.Forms.Button button238;
        private System.Windows.Forms.Button button239;
        private System.Windows.Forms.Button button240;
        private System.Windows.Forms.Button button241;
        private System.Windows.Forms.Button button242;
        private System.Windows.Forms.Button button243;
        private System.Windows.Forms.Button button244;
        private System.Windows.Forms.Button button245;
        private System.Windows.Forms.Button button246;
        private System.Windows.Forms.Button button247;
        private System.Windows.Forms.Button button248;
        private System.Windows.Forms.Button button249;
        private System.Windows.Forms.Button button250;
        private System.Windows.Forms.Button button251;
        private System.Windows.Forms.Button button252;
        private System.Windows.Forms.Button button253;
        private System.Windows.Forms.Button button254;
        private System.Windows.Forms.Button button255;
        private System.Windows.Forms.Button button256;
        private System.Windows.Forms.Button button257;
        private System.Windows.Forms.Button button258;
        private System.Windows.Forms.Button button259;
        private System.Windows.Forms.Button button260;
        private System.Windows.Forms.Button button261;
        private System.Windows.Forms.Button button262;
        private System.Windows.Forms.Button button263;
        private System.Windows.Forms.Button button264;
        private System.Windows.Forms.Button button265;
        private System.Windows.Forms.Button button266;
        private System.Windows.Forms.Button button267;
        private System.Windows.Forms.Button button268;
        private System.Windows.Forms.Button button269;
        private System.Windows.Forms.Button button270;
        private System.Windows.Forms.Button button271;
        private System.Windows.Forms.Button button272;
        private System.Windows.Forms.Button button273;
        private System.Windows.Forms.Button button274;
        private System.Windows.Forms.Button button275;
        private System.Windows.Forms.Button button276;
        private System.Windows.Forms.Button button277;
        private System.Windows.Forms.Button button278;
        private System.Windows.Forms.Button button279;
        private System.Windows.Forms.Button button280;
        private System.Windows.Forms.Button button281;
        private System.Windows.Forms.Button button282;
        private System.Windows.Forms.Button button283;
        private System.Windows.Forms.Button button284;
        private System.Windows.Forms.Button button285;
        private System.Windows.Forms.Button button286;
        private System.Windows.Forms.Button button287;
        private System.Windows.Forms.Button button288;
        private System.Windows.Forms.Button button289;
        private System.Windows.Forms.Button button290;
        private System.Windows.Forms.Button button291;
        private System.Windows.Forms.Button button292;
        private System.Windows.Forms.Button button293;
        private System.Windows.Forms.Button button294;
        private System.Windows.Forms.Button button295;
        private System.Windows.Forms.Button button296;
        private System.Windows.Forms.Button button297;
        private System.Windows.Forms.Button button298;
        private System.Windows.Forms.Button button299;
        private System.Windows.Forms.Button button300;
        private System.Windows.Forms.Button button301;
        private System.Windows.Forms.Button button302;
        private System.Windows.Forms.Button button303;
        private System.Windows.Forms.Button button304;
        private System.Windows.Forms.Button button305;
        private System.Windows.Forms.Button button306;
        private System.Windows.Forms.Button button307;
        private System.Windows.Forms.Button button308;
        private System.Windows.Forms.Button button309;
        private System.Windows.Forms.Button button310;
        private System.Windows.Forms.Button button311;
        private System.Windows.Forms.Button button312;
        private System.Windows.Forms.Button button313;
        private System.Windows.Forms.Button button314;
        private System.Windows.Forms.Button button315;
        private System.Windows.Forms.Button button316;
        private System.Windows.Forms.Button button317;
        private System.Windows.Forms.Button button318;
        private System.Windows.Forms.Button button319;
        private System.Windows.Forms.Button button320;
        private System.Windows.Forms.Button button321;
        private System.Windows.Forms.Button button322;
        private System.Windows.Forms.Button button323;
        private System.Windows.Forms.Button button324;
        private System.Windows.Forms.Button button325;
        private System.Windows.Forms.Button button326;
        private System.Windows.Forms.Button button327;
        private System.Windows.Forms.Button button328;
        private System.Windows.Forms.Button button329;
        private System.Windows.Forms.Button button330;
        private System.Windows.Forms.Button button331;
        private System.Windows.Forms.Button button332;
        private System.Windows.Forms.Button button333;
        private System.Windows.Forms.Button button334;
        private System.Windows.Forms.Button button335;
        private System.Windows.Forms.Button button336;
        private System.Windows.Forms.Button button337;
        private System.Windows.Forms.Button button338;
        private System.Windows.Forms.Button button339;
        private System.Windows.Forms.Button button340;
        private System.Windows.Forms.Button button341;
        private System.Windows.Forms.Button button342;
        private System.Windows.Forms.Button button343;
        private System.Windows.Forms.Button button344;
        private System.Windows.Forms.Button button345;
        private System.Windows.Forms.Button button346;
        private System.Windows.Forms.Button button347;
        private System.Windows.Forms.Button button348;
        private System.Windows.Forms.Button button349;
        private System.Windows.Forms.Button button350;
        private System.Windows.Forms.Button button351;
        private System.Windows.Forms.Button button352;
        private System.Windows.Forms.Button button353;
        private System.Windows.Forms.Button button354;
        private System.Windows.Forms.Button button355;
        private System.Windows.Forms.Button button356;
        private System.Windows.Forms.Button button357;
        private System.Windows.Forms.Button button358;
        private System.Windows.Forms.Button button359;
        private System.Windows.Forms.Button button360;
        private System.Windows.Forms.Button button361;
        private System.Windows.Forms.Button button362;
        private System.Windows.Forms.Button button363;
        private System.Windows.Forms.Button button364;
        private System.Windows.Forms.Button button365;
        private System.Windows.Forms.Button button366;
        private System.Windows.Forms.Button button367;
        private System.Windows.Forms.Button button368;
        private System.Windows.Forms.Button button369;
        private System.Windows.Forms.Button button370;
        private System.Windows.Forms.Button button371;
        private System.Windows.Forms.Button button372;
        private System.Windows.Forms.Button button373;
        private System.Windows.Forms.Button button374;
        private System.Windows.Forms.Button button375;
        private System.Windows.Forms.Button button376;
        private System.Windows.Forms.Button button377;
        private System.Windows.Forms.Button button378;
        private System.Windows.Forms.Button button379;
        private System.Windows.Forms.Button button380;
        private System.Windows.Forms.Button button381;
        private System.Windows.Forms.Button button382;
        private System.Windows.Forms.Button button383;
        private System.Windows.Forms.Button button384;
        private System.Windows.Forms.Button button385;
        private System.Windows.Forms.Button button386;
        private System.Windows.Forms.Button button387;
        private System.Windows.Forms.Button button388;
        private System.Windows.Forms.Button button389;
        private System.Windows.Forms.Button button390;
        private System.Windows.Forms.Button button391;
        private System.Windows.Forms.Button button392;
        private System.Windows.Forms.Button button393;
        private System.Windows.Forms.Button button394;
        private System.Windows.Forms.Button button395;
        private System.Windows.Forms.Button button396;
        private System.Windows.Forms.Button button397;
        private System.Windows.Forms.Button button398;
        private System.Windows.Forms.Button button399;
        private System.Windows.Forms.Button button400;
        private System.Windows.Forms.Button button401;
        private System.Windows.Forms.Button button402;
        private System.Windows.Forms.Button button403;
        private System.Windows.Forms.Button button404;
        private System.Windows.Forms.Button button405;
        private System.Windows.Forms.Button button406;
        private System.Windows.Forms.Button button407;
        private System.Windows.Forms.Button button408;
        private System.Windows.Forms.Button button409;
        private System.Windows.Forms.Button button410;
        private System.Windows.Forms.Button button411;
        private System.Windows.Forms.Button button412;
        private System.Windows.Forms.Button button413;
        private System.Windows.Forms.Button button414;
        private System.Windows.Forms.Button button415;
        private System.Windows.Forms.Button button416;
        private System.Windows.Forms.Button button417;
        private System.Windows.Forms.Button button418;
        private System.Windows.Forms.Button button419;
        private System.Windows.Forms.Button button420;
        private System.Windows.Forms.Button button421;
        private System.Windows.Forms.Button button422;
        private System.Windows.Forms.Button button423;
        private System.Windows.Forms.Button button424;
        private System.Windows.Forms.Button button425;
        private System.Windows.Forms.Button button426;
        private System.Windows.Forms.Button button427;
        private System.Windows.Forms.Button button428;
        private System.Windows.Forms.Button button429;
        private System.Windows.Forms.Button button430;
        private System.Windows.Forms.Button button431;
        private System.Windows.Forms.Button button432;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.Button clearButton;
    }
}

